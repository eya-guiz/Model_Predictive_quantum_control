"""Reproducible Section 7.1 paired IPOPT versus GRAPE/L-BFGS-B benchmark.

The script generates an *open-loop MPQC* input trajectory: the state at each
MPC update is simulated from the nominal model rather than measured.  IPOPT
and GRAPE use the same discrete dynamics, objective, input bounds, and initial
control guess at the first update of every paired trial.  Thereafter both use
the same shifted-warm-start rule on their respective preceding solution.

The GRAPE implementation uses an exact forward/backward adjoint gradient;
L-BFGS-B supplies bound handling and line search.  A finite-difference check
is performed before benchmark runs unless --skip-gradient-check is supplied.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import casadi as ca
import matplotlib.pyplot as plt
import numpy as np
from scipy.linalg import expm, expm_frechet
from scipy.optimize import minimize

from mpqc_benchmark.artifacts import RunArtifacts, write_csv, write_json
from mpqc_benchmark.diagnostics import (
    PAULI,
    applied_trajectory_cost,
    exact_density_step,
    input_bound_violation,
    physicality_diagnostics,
    propagator_unitarity_error,
)


plt.switch_backend("Agg")


@dataclass(frozen=True)
class Settings:
    dt: float
    steps: int
    horizon: int
    apply_steps: int
    drift: float
    state_weight: float
    control_weight: float
    terminal_weight: float
    lower: np.ndarray
    upper: np.ndarray
    input_reference: np.ndarray
    ipopt_tolerance: float
    ipopt_max_iterations: int
    lbfgsb_gtol: float
    lbfgsb_ftol: float
    lbfgsb_max_iterations: int


TARGETS = {
    "one": np.array([0.0, 1.0], dtype=np.complex128),
    "plus": np.array([1.0, 1.0], dtype=np.complex128) / math.sqrt(2.0),
    "minus": np.array([1.0, -1.0], dtype=np.complex128) / math.sqrt(2.0),
}


def real_state(psi: np.ndarray) -> np.ndarray:
    return np.concatenate((psi.real, psi.imag))


def complex_state(state: np.ndarray) -> np.ndarray:
    return state[:2] + 1.0j * state[2:]


def target_matrix(target: np.ndarray) -> np.ndarray:
    """Matrix B such that F=||B z||^2 for z=[Re psi, Im psi]."""
    tr, ti = target.real, target.imag
    return np.vstack((np.r_[tr, ti], np.r_[-ti, tr]))


def fidelity(state: np.ndarray, target: np.ndarray) -> float:
    return float(abs(np.vdot(target, complex_state(state))) ** 2)


def hamiltonian(control: np.ndarray, settings: Settings) -> np.ndarray:
    return (
        settings.drift * PAULI["z"]
        + control[0] * PAULI["x"]
        + control[1] * PAULI["y"]
        + control[2] * PAULI["z"]
    )


def step_matrix(control: np.ndarray, settings: Settings) -> tuple[np.ndarray, np.ndarray]:
    unitary = expm(-1.0j * hamiltonian(control, settings) * settings.dt)
    matrix = np.block([[unitary.real, -unitary.imag], [unitary.imag, unitary.real]])
    return matrix, unitary


def step_derivatives(control: np.ndarray, settings: Settings) -> tuple[np.ndarray, list[np.ndarray]]:
    generator = -1.0j * hamiltonian(control, settings) * settings.dt
    unitary = expm(generator)
    matrices: list[np.ndarray] = []
    for axis in ("x", "y", "z"):
        derivative = expm_frechet(
            generator, -1.0j * PAULI[axis] * settings.dt, compute_expm=False
        )
        matrices.append(
            np.block(
                [[derivative.real, -derivative.imag], [derivative.imag, derivative.real]]
            )
        )
    return np.block([[unitary.real, -unitary.imag], [unitary.imag, unitary.real]]), matrices


def rollout_objective_gradient(
    flat_control: np.ndarray, initial: np.ndarray, target: np.ndarray, settings: Settings
) -> tuple[float, np.ndarray]:
    """Exact discrete adjoint (GRAPE) objective and gradient for one MPC update."""
    controls = np.asarray(flat_control, dtype=float).reshape(3, -1, order="F")
    length = controls.shape[1]
    b_matrix = target_matrix(target)
    q_matrix = b_matrix.T @ b_matrix
    states = np.empty((length + 1, 4), dtype=float)
    matrices: list[np.ndarray] = []
    derivatives: list[list[np.ndarray]] = []
    states[0] = initial
    value = 0.0
    for k in range(length):
        value += settings.state_weight * (1.0 - float(states[k] @ q_matrix @ states[k]))
        delta = controls[:, k] - settings.input_reference
        value += settings.control_weight * float(delta @ delta)
        matrix, derivative = step_derivatives(controls[:, k], settings)
        matrices.append(matrix)
        derivatives.append(derivative)
        states[k + 1] = matrix @ states[k]
    value += settings.terminal_weight * (1.0 - float(states[-1] @ q_matrix @ states[-1]))

    gradient = np.zeros_like(controls)
    costate = -2.0 * settings.terminal_weight * (q_matrix @ states[-1])
    for k in range(length - 1, -1, -1):
        delta = controls[:, k] - settings.input_reference
        for control_index in range(3):
            gradient[control_index, k] = (
                2.0 * settings.control_weight * delta[control_index]
                + float(costate @ (derivatives[k][control_index] @ states[k]))
            )
        costate = -2.0 * settings.state_weight * (q_matrix @ states[k]) + matrices[k].T @ costate
    return value, gradient.reshape(-1, order="F")


class CasadiProblemFactory:
    """Caches exact-discrete-dynamics IPOPT problems by prediction length."""

    def __init__(self, settings: Settings, target: np.ndarray) -> None:
        self.settings = settings
        self.target = target
        self.problems: dict[int, tuple[ca.Function, ca.Function]] = {}

    def _casadi_step(self, state: ca.MX, control: ca.MX) -> ca.MX:
        # Closed-form qubit exponential.  The finite Taylor polynomials avoid a
        # removable 0/0 singularity and are accurate far beyond this benchmark.
        hx, hy = control[0], control[1]
        hz = self.settings.drift + control[2]
        radius_squared = hx * hx + hy * hy + hz * hz
        cosine = 0
        sine_over_radius = 0
        for index in range(10):
            cosine += (-1) ** index * (self.settings.dt**2 * radius_squared) ** index / math.factorial(2 * index)
            sine_over_radius += (
                (-1) ** index
                * self.settings.dt ** (2 * index + 1)
                * radius_squared**index
                / math.factorial(2 * index + 1)
            )
        # U = cos(r dt)I - i sin(r dt)/r H, represented on [Re psi; Im psi].
        ur = ca.vertcat(
            ca.horzcat(cosine, -sine_over_radius * hy),
            ca.horzcat(sine_over_radius * hy, cosine),
        )
        ui = ca.vertcat(
            ca.horzcat(-sine_over_radius * hz, -sine_over_radius * hx),
            ca.horzcat(-sine_over_radius * hx, sine_over_radius * hz),
        )
        return ca.vertcat(ur @ state[:2] - ui @ state[2:], ui @ state[:2] + ur @ state[2:])

    def problem(self, length: int) -> tuple[ca.Function, ca.Function]:
        if length in self.problems:
            return self.problems[length]
        controls = ca.MX.sym("controls", 3, length)
        initial = ca.MX.sym("initial", 4)
        target = ca.DM(target_matrix(self.target))
        state = initial
        objective = 0
        for k in range(length):
            objective += self.settings.state_weight * (1.0 - ca.sumsqr(target @ state))
            objective += self.settings.control_weight * ca.sumsqr(
                controls[:, k] - ca.DM(self.settings.input_reference)
            )
            state = self._casadi_step(state, controls[:, k])
        objective += self.settings.terminal_weight * (1.0 - ca.sumsqr(target @ state))
        nlp = {"x": ca.vec(controls), "p": initial, "f": objective}
        solver = ca.nlpsol(
            f"ipopt_length_{length}", "ipopt", nlp,
            {"ipopt.print_level": 0, "ipopt.sb": "yes", "ipopt.tol": self.settings.ipopt_tolerance,
             "ipopt.max_iter": self.settings.ipopt_max_iterations, "print_time": 0},
        )
        objective_function = ca.Function("objective", [ca.vec(controls), initial], [objective])
        self.problems[length] = solver, objective_function
        return self.problems[length]


def warm_start(previous: np.ndarray | None, initial: np.ndarray, length: int, apply_steps: int) -> np.ndarray:
    if previous is None:
        return initial[:, :length].copy()
    shifted = previous[:, apply_steps:]
    output = np.empty((3, length), dtype=float)
    count = min(length, shifted.shape[1])
    output[:, :count] = shifted[:, :count]
    output[:, count:] = previous[:, [-1]]
    return output


def solve_ipopt(
    factory: CasadiProblemFactory, state: np.ndarray, guess: np.ndarray, settings: Settings
) -> tuple[np.ndarray, float, int, str]:
    solver, objective = factory.problem(guess.shape[1])
    started = time.perf_counter()
    solution = solver(
        x0=guess.reshape(-1, order="F"), p=state,
        lbx=np.tile(settings.lower, guess.shape[1]), ubx=np.tile(settings.upper, guess.shape[1]),
    )
    elapsed = time.perf_counter() - started
    stats = solver.stats()
    status = str(stats.get("return_status", "unknown"))
    iterations = int(stats.get("iter_count", -1))
    if not bool(stats.get("success", False)):
        raise RuntimeError(f"IPOPT failed: {status}")
    return np.asarray(solution["x"]).reshape(3, -1, order="F"), elapsed, iterations, status


def solve_grape(
    state: np.ndarray, target: np.ndarray, guess: np.ndarray, settings: Settings
) -> tuple[np.ndarray, float, int, str]:
    def objective_and_gradient(vector: np.ndarray) -> tuple[float, np.ndarray]:
        return rollout_objective_gradient(vector, state, target, settings)

    bounds = list(zip(np.tile(settings.lower, guess.shape[1]), np.tile(settings.upper, guess.shape[1])))

    def optimize(starting_point: np.ndarray, maximum_line_searches: int):
        return minimize(
            fun=objective_and_gradient,
            x0=starting_point,
            jac=True,
            method="L-BFGS-B",
            bounds=bounds,
            options={
                "maxiter": settings.lbfgsb_max_iterations,
                "gtol": settings.lbfgsb_gtol,
                "ftol": settings.lbfgsb_ftol,
                "maxls": maximum_line_searches,
            },
        )

    started = time.perf_counter()
    result = optimize(guess.reshape(-1, order="F"), maximum_line_searches=80)
    retried = False
    if not result.success and "LNSRCH" in str(result.message):
        # A fresh L-BFGS memory and a larger line-search budget resolve the
        # occasional line-search failure close to a constrained optimum.
        result = optimize(result.x, maximum_line_searches=200)
        retried = True
    elapsed = time.perf_counter() - started
    if not result.success:
        raise RuntimeError(f"L-BFGS-B failed: {result.message}")
    status = str(result.message)
    if retried:
        status = f"retry_after_line_search; {status}"
    return result.x.reshape(3, -1, order="F"), elapsed, int(result.nit), status


def initial_controls(rng: np.random.Generator, settings: Settings) -> np.ndarray:
    return rng.uniform(settings.lower[:, None], settings.upper[:, None], size=(3, settings.horizon)) * 0.2


def gradient_check(settings: Settings) -> dict[str, float]:
    rng = np.random.default_rng(9173)
    target = TARGETS["plus"]
    state = real_state(np.array([1.0, 0.0], dtype=np.complex128))
    control = initial_controls(rng, settings)[:, :settings.horizon]
    _, analytic = rollout_objective_gradient(control.reshape(-1, order="F"), state, target, settings)
    indices = rng.choice(analytic.size, size=min(8, analytic.size), replace=False)
    epsilon = 1e-6
    errors = []
    for index in indices:
        plus = control.reshape(-1, order="F").copy(); plus[index] += epsilon
        minus = control.reshape(-1, order="F").copy(); minus[index] -= epsilon
        fp = rollout_objective_gradient(plus, state, target, settings)[0]
        fm = rollout_objective_gradient(minus, state, target, settings)[0]
        numerical = (fp - fm) / (2.0 * epsilon)
        errors.append(abs(numerical - analytic[index]) / max(1.0, abs(numerical), abs(analytic[index])))
    return {"gradient_check_max_relative_error": float(max(errors)), "gradient_check_points": float(len(indices))}


def run_one(
    method: str, target_name: str, trial: int, initial_guess: np.ndarray, settings: Settings,
    config: dict[str, Any], output_root: Path, target_override: np.ndarray | None = None,
) -> dict[str, Any]:
    target = TARGETS[target_name] if target_override is None else np.asarray(target_override, dtype=np.complex128)
    artifacts = RunArtifacts(output_root, "s7_1_basic_mpqc_solver_benchmark", config, Path.cwd())
    factory = CasadiProblemFactory(settings, target) if method == "ipopt" else None
    state = real_state(np.array([1.0, 0.0], dtype=np.complex128))
    states = [np.outer(complex_state(state), complex_state(state).conj())]
    controls_applied = np.zeros((3, settings.steps))
    subproblems: list[dict[str, Any]] = []
    predicted_controls: list[np.ndarray] = []
    prior: np.ndarray | None = None
    solve_total = 0.0
    start = time.perf_counter()
    for update, time_index in enumerate(range(0, settings.steps, settings.apply_steps)):
        length = min(settings.horizon, settings.steps - time_index)
        count = min(settings.apply_steps, settings.steps - time_index)
        guess = warm_start(prior, initial_guess, length, settings.apply_steps)
        if method == "ipopt":
            optimum, elapsed, iterations, status = solve_ipopt(factory, state, guess, settings)  # type: ignore[arg-type]
        else:
            optimum, elapsed, iterations, status = solve_grape(state, target, guess, settings)
        solve_total += elapsed
        objective, _ = rollout_objective_gradient(optimum.reshape(-1, order="F"), state, target, settings)
        predicted_controls.append(optimum)
        subproblems.append({
            "update": update, "time_index": time_index, "prediction_horizon": length,
            "solver": method, "solver_return_code": status, "solver_success": True,
            "iterations": iterations, "solve_time_s": elapsed, "objective_value": objective,
            "initialization": "paired_random" if update == 0 else "shifted_warm_start",
            "max_predicted_input_bound_violation": input_bound_violation(optimum, settings.lower, settings.upper),
        })
        for local in range(count):
            control = optimum[:, local]
            controls_applied[:, time_index + local] = control
            matrix, unitary = step_matrix(control, settings)
            state = matrix @ state
            psi = complex_state(state)
            states.append(np.outer(psi, psi.conj()))
        prior = optimum
    end_to_end = time.perf_counter() - start
    target_rho = np.outer(target, target.conj())
    state_costs = applied_trajectory_cost(
        states, controls_applied, target_rho, settings.input_reference, settings.dt,
        settings.state_weight, settings.control_weight, settings.terminal_weight, False,
    )
    fidelities = [
        float(np.clip(np.real(np.trace(target_rho @ rho)), 0.0, 1.0))
        for rho in states
    ]
    max_unitarity = 0.0
    max_trace = max_hermiticity = 0.0
    min_eigenvalue = float("inf")
    max_defect = 0.0
    for index in range(settings.steps):
        propagated, unitary = exact_density_step(states[index], hamiltonian(controls_applied[:, index], settings), settings.dt)
        max_defect = max(max_defect, float(np.linalg.norm(propagated - states[index + 1], ord="fro")))
        max_unitarity = max(max_unitarity, propagator_unitarity_error(unitary))
        physical = physicality_diagnostics(states[index + 1])
        max_trace = max(max_trace, physical.trace_error); max_hermiticity = max(max_hermiticity, physical.hermiticity_error)
        min_eigenvalue = min(min_eigenvalue, physical.min_eigenvalue)
    trajectory = [
        {"time_index": k, "time": k * settings.dt, "fidelity": f, "infidelity": 1.0 - f}
        for k, f in enumerate(fidelities)
    ]
    controls_rows = [
        {"time_index": k, "time": k * settings.dt, **{f"u{j + 1}": controls_applied[j, k] for j in range(3)}}
        for k in range(settings.steps)
    ]
    summary = {
        "run_success": True, "experiment_name": "s7_1_basic_mpqc_solver_benchmark",
        "run_label": f"{target_name}-{method}-trial-{trial:02d}", "target": target_name,
        "method": "CasADi/IPOPT" if method == "ipopt" else "analytic GRAPE/L-BFGS-B",
        "trial": trial, "seed": config["seed"], "dimension": 2, "control_count": 3,
        "dt": settings.dt, "simulation_steps_requested": settings.steps,
        "simulation_steps_completed": settings.steps, "prediction_horizon": settings.horizon,
        "apply_steps": settings.apply_steps, "mpc_updates": len(subproblems),
        "final_fidelity": fidelities[-1], "final_infidelity": 1.0 - fidelities[-1],
        "solver_all_successful": True, "total_iterations": int(sum(r["iterations"] for r in subproblems)),
        "median_iterations_per_update": float(np.median([r["iterations"] for r in subproblems])),
        "max_dynamics_defect": max_defect, "max_input_bound_violation": input_bound_violation(controls_applied, settings.lower, settings.upper),
        "max_predicted_input_bound_violation": max(r["max_predicted_input_bound_violation"] for r in subproblems),
        "max_propagator_unitarity_error": max_unitarity, "max_trace_error": max_trace,
        "max_hermiticity_error": max_hermiticity, "minimum_density_eigenvalue": min_eigenvalue,
        "model_construction_time_s": 0.0, "solve_time_s": solve_total, "end_to_end_time_s": end_to_end,
        **state_costs,
    }
    artifacts.write_success(summary, subproblems, trajectory, controls_rows, {"controls": controls_applied, "fidelity": np.asarray(fidelities)}, False)
    return {**summary, "run_id": artifacts.run_id, "run_directory": str(artifacts.run_directory)}


def aggregate(rows: list[dict[str, Any]], output_root: Path, config: dict[str, Any]) -> Path:
    destination = output_root / f"s7_1_aggregate_{time.strftime('%Y%m%dT%H%M%S')}"
    destination.mkdir(parents=True)
    write_json(destination / "config.json", config)
    write_csv(destination / "paired_runs.csv", rows)
    metrics = ["final_infidelity", "applied_total_cost", "solve_time_s", "total_iterations"]
    summary_rows = []
    targets_present = [target for target in TARGETS if any(row["target"] == target for row in rows)]
    for target in targets_present:
        for method in ("CasADi/IPOPT", "analytic GRAPE/L-BFGS-B"):
            subset = [row for row in rows if row["target"] == target and row["method"] == method]
            record: dict[str, Any] = {"target": target, "method": method, "runs": len(subset)}
            for metric in metrics:
                values = np.array([float(row[metric]) for row in subset])
                record[f"{metric}_median"] = float(np.median(values))
                record[f"{metric}_q25"] = float(np.quantile(values, 0.25))
                record[f"{metric}_q75"] = float(np.quantile(values, 0.75))
            summary_rows.append(record)
    write_csv(destination / "table_7_1_summary.csv", summary_rows)
    with (destination / "table_7_1_summary.tex").open("w", encoding="utf-8") as stream:
        stream.write("% Median [IQR]; runtime is solver time only.\n")
        stream.write(
            "Target & Method & Final infidelity & Total cost & Solver time [s] & Iterations \\\\\n"
        )
        stream.write("\\hline\n")
        for row in summary_rows:
            interval = lambda key: f"{row[key + '_median']:.3g} [{row[key + '_q25']:.3g}, {row[key + '_q75']:.3g}]"
            stream.write(
                f"${row['target']}$ & {row['method']} & {interval('final_infidelity')} & "
                f"{interval('applied_total_cost')} & {interval('solve_time_s')} & "
                f"{interval('total_iterations')} \\\\\n"
            )
    figure, axes = plt.subplots(1, 3, figsize=(11, 3.3), constrained_layout=True)
    for axis, metric, label in zip(axes, metrics[:3], ("Final infidelity", "Applied total cost", "Solver time [s]")):
        positions, values, labels = [], [], []
        for target_index, target in enumerate(targets_present):
            for method_index, method in enumerate(("CasADi/IPOPT", "analytic GRAPE/L-BFGS-B")):
                positions.append(target_index * 3 + method_index); labels.append(f"{target}\n{'IPOPT' if method_index == 0 else 'GRAPE'}")
                current_values = [
                    float(row[metric])
                    for row in rows
                    if row["target"] == target and row["method"] == method
                ]
                if metric == "final_infidelity":
                    current_values = [max(value, 1e-16) for value in current_values]
                values.append(current_values)
        axis.boxplot(values, positions=positions, widths=0.7, showfliers=False)
        axis.set_xticks(positions, labels, fontsize=8); axis.set_ylabel(label); axis.grid(axis="y", alpha=0.3)
        if metric == "final_infidelity": axis.set_yscale("log")
    figure.savefig(destination / "figure_7_1_solver_comparison.pdf", bbox_inches="tight")
    figure.savefig(destination / "figure_7_1_solver_comparison.png", dpi=250, bbox_inches="tight")
    return destination


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/s7_1_solver_benchmark.json")
    parser.add_argument("--trials", type=int, help="Override paired trials (use 1 for a smoke run).")
    parser.add_argument("--targets", nargs="+", choices=tuple(TARGETS), help="Subset of one plus minus.")
    parser.add_argument("--skip-gradient-check", action="store_true")
    arguments = parser.parse_args()
    raw = json.loads(Path(arguments.config).read_text(encoding="utf-8"))
    settings = Settings(
        dt=float(raw["dt"]), steps=int(raw["simulation_steps"]), horizon=int(raw["prediction_horizon"]),
        apply_steps=int(raw["apply_steps"]), drift=float(raw["drift_strength"]),
        state_weight=float(raw["cost"]["state_weight"]), control_weight=float(raw["cost"]["control_weight"]),
        terminal_weight=float(raw["cost"]["terminal_weight"]), lower=np.asarray(raw["bounds"]["lower"], dtype=float),
        upper=np.asarray(raw["bounds"]["upper"], dtype=float), input_reference=np.asarray(raw["cost"]["input_reference"], dtype=float),
        ipopt_tolerance=float(raw["ipopt"]["tolerance"]), ipopt_max_iterations=int(raw["ipopt"]["max_iterations"]),
        lbfgsb_gtol=float(raw["lbfgsb"]["gtol"]), lbfgsb_ftol=float(raw["lbfgsb"]["ftol"]), lbfgsb_max_iterations=int(raw["lbfgsb"]["max_iterations"]),
    )
    if settings.lower.shape != (3,) or settings.upper.shape != (3,) or settings.horizon > settings.steps:
        raise ValueError("Section 7.1 requires three bounds and 0 < L <= N.")
    trials = arguments.trials if arguments.trials is not None else int(raw["paired_trials"])
    if trials <= 0: raise ValueError("--trials must be positive")
    selected_targets = arguments.targets or list(raw["targets"])
    output_root = Path(raw["output_root"]); output_root.mkdir(parents=True, exist_ok=True)
    run_config = {**raw, "paired_trials_effective": trials, "targets_effective": selected_targets}
    if not arguments.skip_gradient_check:
        check = gradient_check(settings)
        print(f"GRAPE gradient check: max relative error = {check['gradient_check_max_relative_error']:.3e}")
        if check["gradient_check_max_relative_error"] > 1e-5:
            raise RuntimeError("GRAPE gradient check failed; do not benchmark this implementation.")
        run_config.update(check)
    rows: list[dict[str, Any]] = []
    for target_index, target in enumerate(selected_targets):
        for trial in range(trials):
            rng = np.random.default_rng(int(raw["seed"]) + 1009 * target_index + trial)
            paired_guess = initial_controls(rng, settings)
            for method in ("ipopt", "grape"):
                print(f"target={target}, trial={trial + 1}/{trials}, method={method}")
                rows.append(run_one(method, target, trial, paired_guess, settings, run_config, output_root))
    aggregate_directory = aggregate(rows, output_root, run_config)
    print(f"Aggregate outputs: {aggregate_directory}")


if __name__ == "__main__":
    main()
