"""Re-render Section 7.1 equatorial-sweep figures from saved CSV data only.

The Bloch panel shows the *target-sweep trajectory* as nu varies, rather than
the physical time trajectory of a single control run. No MPC optimization is
performed by this script.
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from qutip import Bloch


plt.switch_backend("Agg")


def read_rows(path: Path) -> list[dict[str, Any]]:
    with path.open("r", newline="", encoding="utf-8") as stream:
        output = []
        for row in csv.DictReader(stream):
            parsed: dict[str, Any] = {}
            for key, value in row.items():
                try:
                    parsed[key] = float(value)
                except (TypeError, ValueError):
                    parsed[key] = value
            output.append(parsed)
        return output


def render_bloch(nus: np.ndarray, output: Path) -> None:
    """Render the target family only, using QuTiP's standard Bloch sphere."""
    figure = plt.figure(figsize=(5.6, 5.2), constrained_layout=True)
    sphere = figure.add_subplot(111, projection="3d")
    bloch = Bloch(fig=figure, axes=sphere, view=[-36, 22])
    bloch.sphere_color = "#b8c7d9"; bloch.sphere_alpha = .16
    bloch.frame_color = "0.55"; bloch.frame_alpha = .16; bloch.frame_width = .8
    bloch.xlabel = ["", ""]; bloch.ylabel = ["", ""]; bloch.zlabel = ["", ""]
    bloch.render()
    dense_nu = np.linspace(0, 1, 401)
    sweep_x, sweep_y = np.cos(2*np.pi*dense_nu), np.sin(2*np.pi*dense_nu)
    ring_color = "#2a6f8f"
    sphere.plot(sweep_x, sweep_y, np.zeros_like(dense_nu), color=ring_color, linewidth=1.8, zorder=2)
    sphere.scatter(np.cos(2*np.pi*nus), np.sin(2*np.pi*nus), np.zeros_like(nus), color=ring_color, s=34, depthshade=False, zorder=3)
    arrow_nu = .17; dx, dy = -.14*np.sin(2*np.pi*arrow_nu), .14*np.cos(2*np.pi*arrow_nu)
    sphere.quiver(np.cos(2*np.pi*arrow_nu), np.sin(2*np.pi*arrow_nu), 0, dx, dy, 0, color="#303030", arrow_length_ratio=.28, linewidth=1.2)
    sphere.plot([0, 0], [0, 0], [-1.12, 1.12], linestyle="--", color="0.35", linewidth=.9, zorder=1)
    sphere.plot([-1.82, 1.82], [0, 0], [0, 0], linestyle="--", color="0.30", linewidth=1.0, zorder=1)
    sphere.scatter([0], [0], [1], color="black", marker="^", s=28, depthshade=False, zorder=4)
    sphere.scatter([0], [0], [-1], facecolors="white", edgecolors="black", marker="v", s=26, depthshade=False, zorder=4)
    sphere.text(0, 0, 1.16, r"$|0\rangle$", fontsize=11)
    sphere.text(0, 0, -1.25, r"$|1\rangle$", fontsize=11)
    sphere.text(1.98, 0, .12, r"$|+\rangle$", fontsize=12)
    sphere.text(-2.20, 0, .12, r"$|-\rangle$", fontsize=12)
    sphere.set(xlim=(-2.12, 2.12), ylim=(-1.22, 1.22), zlim=(-1.22, 1.22))
    sphere.set_box_aspect((4.24, 2.44, 2.44)); sphere.view_init(elev=22, azim=216)
    sphere.set_axis_off()
    figure.savefig(output / "figure_7_1_bloch_target_sweep.pdf", bbox_inches="tight")
    figure.savefig(output / "figure_7_1_bloch_target_sweep.png", dpi=300, bbox_inches="tight")


def render_performance(summary: list[dict[str, Any]], output: Path) -> None:
    methods = ("CasADi/IPOPT", "analytic GRAPE/L-BFGS-B")
    colors = {"CasADi/IPOPT": "#1f77b4", "analytic GRAPE/L-BFGS-B": "#ff7f0e"}
    labels = {"CasADi/IPOPT": "CasADi/IPOPT", "analytic GRAPE/L-BFGS-B": "analytic GRAPE/L-BFGS-B"}
    figure, axes = plt.subplots(1, 2, figsize=(11.5, 4.6), constrained_layout=True)

    for axis, metric, ylabel in zip(axes, ("solve_time_s", "total_iterations"), ("MPQC time [s]", "Total iterations")):
        for method in methods:
            rows = sorted((row for row in summary if row["method"] == method), key=lambda row: float(row["nu"]))
            nu = np.array([float(row["nu"]) for row in rows]); median = np.array([float(row[f"{metric}_median"]) for row in rows])
            lower = np.array([float(row[f"{metric}_q25"]) for row in rows]); upper = np.array([float(row[f"{metric}_q75"]) for row in rows])
            axis.plot(nu, median, "o-", color=colors[method], markersize=3.5, linewidth=1.35, label=labels[method])
            axis.fill_between(nu, lower, upper, color=colors[method], alpha=.16, linewidth=0)
        axis.set(xlabel=r"$\nu$", ylabel=ylabel, xlim=(-.02, 1.0))
        axis.set_xticks([0, .25, .5, .75], ["0", r"$1/4$", r"$1/2$", r"$3/4$"])
        axis.xaxis.label.set_size(20); axis.yaxis.label.set_size(20)
        axis.tick_params(axis="both", labelsize=13)
        axis.grid(alpha=.28)
        if metric == "solve_time_s":
            axis.legend(loc="best", fontsize=10)
    figure.savefig(output / "figure_7_1_equatorial_solver_sweep.pdf", bbox_inches="tight")
    figure.savefig(output / "figure_7_1_equatorial_solver_sweep.png", dpi=300, bbox_inches="tight")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="Completed s7_1_equatorial_target_sweep result directory.")
    parser.add_argument("--output", type=Path, help="Directory for figures; defaults to --input.")
    args = parser.parse_args(); source = args.input; output = args.output or source
    summary_path = source / "equatorial_summary.csv"
    if not summary_path.exists():
        raise FileNotFoundError(f"Missing {summary_path}; finish the sweep before rendering the final figure.")
    output.mkdir(parents=True, exist_ok=True)
    summary = read_rows(summary_path)
    render_bloch(np.array(sorted({float(row["nu"]) for row in summary})), output)
    render_performance(summary, output)
    print(f"Plots: {output}")


if __name__ == "__main__":
    main()
