"""Section 7.1: paired IPOPT versus analytic-GRAPE sweep over equatorial targets.

Targets are |psi(nu)>=(|0>+exp(i 2 pi nu)|1>)/sqrt(2), so every target has
initial fidelity one half with |0>.  The sweep includes |+> (nu=0) and |->
(nu=1/2), without introducing the trivial initial-state target.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from mpqc_benchmark.artifacts import write_csv, write_json
from run_s7_1_solver_benchmark import Settings, gradient_check, initial_controls, run_one


plt.switch_backend("Agg")


def read_csv_rows(path: Path) -> list[dict[str, Any]]:
    if not path.exists() or path.stat().st_size == 0:
        return []
    rows = []
    with path.open("r", newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            parsed: dict[str, Any] = {}
            for key, value in row.items():
                if value is None or value == "": parsed[key] = ""
                elif value == "True": parsed[key] = True
                elif value == "False": parsed[key] = False
                else:
                    try:
                        number = float(value); parsed[key] = int(number) if number.is_integer() else number
                    except ValueError: parsed[key] = value
            rows.append(parsed)
    return rows


def equatorial_target(nu: float) -> np.ndarray:
    return np.array([1.0, np.exp(2.0j * math.pi * nu)], dtype=np.complex128) / math.sqrt(2.0)


def make_settings(raw: dict[str, Any]) -> Settings:
    return Settings(
        dt=float(raw["dt"]), steps=int(raw["simulation_steps"]), horizon=int(raw["prediction_horizon"]),
        apply_steps=int(raw["apply_steps"]), drift=float(raw["drift_strength"]),
        state_weight=float(raw["cost"]["state_weight"]), control_weight=float(raw["cost"]["control_weight"]),
        terminal_weight=float(raw["cost"]["terminal_weight"]), lower=np.asarray(raw["bounds"]["lower"], dtype=float),
        upper=np.asarray(raw["bounds"]["upper"], dtype=float), input_reference=np.asarray(raw["cost"]["input_reference"], dtype=float),
        ipopt_tolerance=float(raw["ipopt"]["tolerance"]), ipopt_max_iterations=int(raw["ipopt"]["max_iterations"]),
        lbfgsb_gtol=float(raw["lbfgsb"]["gtol"]), lbfgsb_ftol=float(raw["lbfgsb"]["ftol"]),
        lbfgsb_max_iterations=int(raw["lbfgsb"]["max_iterations"]),
    )


def quantile_record(values: list[float], name: str, record: dict[str, Any]) -> None:
    data = np.asarray(values, dtype=float)
    record[f"{name}_median"] = float(np.median(data))
    record[f"{name}_q25"] = float(np.quantile(data, .25))
    record[f"{name}_q75"] = float(np.quantile(data, .75))
    record[f"{name}_min"] = float(np.min(data))
    record[f"{name}_max"] = float(np.max(data))


def summarise(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for target_index in sorted({int(row["target_index"]) for row in rows}):
        for method in ("CasADi/IPOPT", "analytic GRAPE/L-BFGS-B"):
            subset = [row for row in rows if int(row["target_index"]) == target_index and row["method"] == method]
            if not subset: continue
            record: dict[str, Any] = {"target_index": target_index, "nu": float(subset[0]["nu"]), "method": method, "runs": len(subset)}
            for metric in ("solve_time_s", "total_iterations", "final_infidelity", "applied_total_cost"):
                quantile_record([float(row[metric]) for row in subset], metric, record)
            output.append(record)
    return output


def plot(summary: list[dict[str, Any]], target_count: int, output: Path) -> None:
    colors = {"CasADi/IPOPT": "#1f77b4", "analytic GRAPE/L-BFGS-B": "#ff7f0e"}
    labels = {"CasADi/IPOPT": "CasADi/IPOPT", "analytic GRAPE/L-BFGS-B": "analytic GRAPE/L-BFGS-B"}
    figure = plt.figure(figsize=(12.0, 3.45), constrained_layout=True)
    sphere = figure.add_subplot(1, 3, 1, projection="3d")
    azimuth = np.linspace(0, 2*np.pi, 181)
    sphere.plot(np.cos(azimuth), np.sin(azimuth), np.zeros_like(azimuth), color="0.75", linewidth=.8)
    nus = np.arange(target_count) / target_count
    points = sphere.scatter(np.cos(2*np.pi*nus), np.sin(2*np.pi*nus), np.zeros_like(nus), c=nus, cmap="viridis", s=34)
    sphere.scatter([0], [0], [1], color="black", marker="^", s=25)
    sphere.text(0, 0, 1.13, r"$|0\rangle$", fontsize=9)
    sphere.set(xlim=(-1.1,1.1), ylim=(-1.1,1.1), zlim=(-1.1,1.1), xlabel="$x$", ylabel="$y$", zlabel="$z$")
    sphere.set_box_aspect((1, 1, 1)); sphere.view_init(elev=20, azim=35)
    figure.colorbar(points, ax=sphere, fraction=.045, pad=.05, label=r"Target parameter $\nu$")
    for position, metric, ylabel in ((2, "solve_time_s", "Cumulative optimization time [s]"), (3, "total_iterations", "Total optimizer iterations")):
        axis = figure.add_subplot(1, 3, position)
        for method in colors:
            current = sorted((row for row in summary if row["method"] == method), key=lambda row: row["nu"])
            x = np.array([row["nu"] for row in current]); med = np.array([row[f"{metric}_median"] for row in current])
            low = np.array([row[f"{metric}_q25"] for row in current]); high = np.array([row[f"{metric}_q75"] for row in current])
            axis.plot(x, med, marker="o", markersize=3.5, linewidth=1.3, color=colors[method], label=labels[method])
            axis.fill_between(x, low, high, color=colors[method], alpha=.16, linewidth=0)
        axis.set(xlabel=r"Target parameter $\nu$", ylabel=ylabel, xlim=(-.02, 1.0))
        axis.set_xticks([0, .25, .5, .75], ["0", r"$1/4$", r"$1/2$", r"$3/4$"])
        axis.grid(alpha=.3)
        if position == 2: axis.legend(fontsize=8, loc="best")
    figure.savefig(output / "figure_7_1_equatorial_solver_sweep.pdf", bbox_inches="tight")
    figure.savefig(output / "figure_7_1_equatorial_solver_sweep.png", dpi=300, bbox_inches="tight")


def write_latex_summary(summary: list[dict[str, Any]], output: Path) -> None:
    rows = []
    for method in ("CasADi/IPOPT", "analytic GRAPE/L-BFGS-B"):
        selected = [row for row in summary if row["method"] == method]
        record = {"method": method, "target_count": len(selected)}
        for metric in ("final_infidelity", "applied_total_cost", "solve_time_s", "total_iterations"):
            values = [row[f"{metric}_median"] for row in selected]
            record[f"{metric}_min"] = min(values); record[f"{metric}_max"] = max(values)
        rows.append(record)
    write_csv(output / "sweep_range_summary.csv", rows)
    with (output / "sweep_range_summary.tex").open("w", encoding="utf-8") as stream:
        stream.write("% Range across equatorial target phases of per-target trial medians.\n")
        for row in rows:
            stream.write(f"{row['method']}: final infidelity {row['final_infidelity_min']:.3g}--{row['final_infidelity_max']:.3g}; ")
            stream.write(f"applied cost {row['applied_total_cost_min']:.3g}--{row['applied_total_cost_max']:.3g}; ")
            stream.write(f"time {row['solve_time_s_min']:.3g}--{row['solve_time_s_max']:.3g} s; ")
            stream.write(f"iterations {row['total_iterations_min']:.3g}--{row['total_iterations_max']:.3g}.\\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/s7_1_equatorial_target_sweep.json")
    parser.add_argument("--trials", type=int, help="Override paired trials; use 1 for a smoke test.")
    parser.add_argument("--target-count", type=int, help="Override number of equally spaced equatorial targets.")
    parser.add_argument("--resume", type=Path, help="Resume an existing sweep directory.")
    parser.add_argument("--skip-gradient-check", action="store_true")
    args = parser.parse_args(); raw = json.loads(Path(args.config).read_text(encoding="utf-8")); settings = make_settings(raw)
    target_count = args.target_count or int(raw["target_count"]); trials = args.trials or int(raw["paired_trials"])
    if target_count < 4 or trials < 1: raise ValueError("Use at least four targets and one paired trial.")
    config = {**raw, "target_count_effective": target_count, "paired_trials_effective": trials}
    if not args.skip_gradient_check:
        check = gradient_check(settings); print(f"GRAPE gradient check: max relative error = {check['gradient_check_max_relative_error']:.3e}")
        if check["gradient_check_max_relative_error"] > 1e-5: raise RuntimeError("GRAPE gradient check failed")
        config.update(check)
    if args.resume is None:
        output = Path(raw["output_root"]) / f"s7_1_equatorial_target_sweep_{time.strftime('%Y%m%dT%H%M%S')}"; output.mkdir(parents=True); write_json(output / "config.json", config); rows=[]
    else:
        output = args.resume; previous = json.loads((output / "config.json").read_text(encoding="utf-8"))
        for key in ("target_count_effective", "paired_trials_effective"):
            if previous.get(key) != config.get(key): raise ValueError(f"Cannot resume with a different {key}")
        rows=read_csv_rows(output / "equatorial_paired_runs.csv"); print(f"Resuming: {output}")
    def exists(index: int, trial: int, method: str) -> bool:
        return any(int(row["target_index"]) == index and int(row["trial"]) == trial and row["method"] == method for row in rows)
    for index in range(target_count):
        nu=index/target_count; target=equatorial_target(nu); label=f"equator_{index:02d}"
        for trial in range(trials):
            rng=np.random.default_rng(int(raw["seed"]) + 1009*index + trial); guess=initial_controls(rng, settings)
            methods=("ipopt", "grape") if trial % 2 == 0 else ("grape", "ipopt")
            for method in methods:
                display="CasADi/IPOPT" if method == "ipopt" else "analytic GRAPE/L-BFGS-B"
                if exists(index, trial, display): continue
                print(f"nu={nu:.4f}, trial={trial+1}/{trials}, method={method}")
                row=run_one(method, label, trial, guess, settings, config, Path(raw["output_root"]), target)
                row.update({"target_index": index, "nu": nu, "target_phase_rad": 2*math.pi*nu, "target_family": "equatorial"})
                rows.append(row); write_csv(output / "equatorial_paired_runs.csv", rows)
    summary=summarise(rows); write_csv(output / "equatorial_summary.csv", summary); write_latex_summary(summary, output); plot(summary, target_count, output)
    print(f"Results: {output}")


if __name__ == "__main__": main()
