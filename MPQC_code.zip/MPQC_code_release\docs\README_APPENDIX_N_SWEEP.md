# Appendix: full-horizon N sweep

This supplementary experiment keeps the physical duration fixed at `T=4.0`
and evaluates the same solver-matched three-qubit GHZ QOC/MPQC comparison for
`N=40, 80, 120`. Consequently, larger `N` means more control intervals and a
smaller timestep `dt=T/N`; it does not mean more physical time to complete the
state preparation task.

Run a one-seed smoke test first:

```powershell
& .\.venv\Scripts\python.exe .\run_appendix_n_sweep_ghz.py --n-values 40 --seeds 1 --mpqc-horizons 8
```

Run the appendix benchmark:

```powershell
& .\.venv\Scripts\python.exe .\run_appendix_n_sweep_ghz.py
```

The output directory contains the full runs, per-update solver records,
selected-horizon and tuning summaries, and `appendix_n_sweep_n3.pdf/png`.
