"""Section 7.3: random-target TEC versus setpoint-MPQC horizon benchmark.

For every fixed-seed uniformly sampled Bloch-sphere target, the script builds
an admissible non-degenerate reference input that makes that target invariant.
It then finds the smallest *tested* prediction horizon satisfying the declared
terminal, steady-state, final-fidelity, bound, and solver-success criteria.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import casadi as ca
import matplotlib.pyplot as plt
import numpy as np

from mpqc_benchmark.artifacts import write_csv, write_json


plt.switch_backend("Agg")


def read_csv_rows(path: Path) -> list[dict[str, Any]]:
    """Read a checkpoint CSV while recovering simple scalar types."""
    if not path.exists() or path.stat().st_size == 0:
        return []
    rows: list[dict[str, Any]] = []
    with path.open("r", newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            parsed: dict[str, Any] = {}
            for key, value in row.items():
                if value is None or value == "":
                    parsed[key] = ""
                elif value == "True":
                    parsed[key] = True
                elif value == "False":
                    parsed[key] = False
                else:
                    try:
                        number = float(value)
                        parsed[key] = int(number) if number.is_integer() else number
                    except ValueError:
                        parsed[key] = value
            rows.append(parsed)
    return rows


def write_checkpoint(
    output: Path,
    scans: list[dict[str, Any]],
    selected: list[dict[str, Any]],
    selected_runs: list[dict[str, Any]],
    subproblems: list[dict[str, Any]],
) -> None:
    """Persist all completed work; safe to call repeatedly during a run."""
    write_csv(output / "horizon_scan.csv", scans)
    write_csv(output / "selected_target_results.csv", selected)
    write_csv(output / "selected_runs.csv", selected_runs)
    write_csv(output / "subproblems.csv", subproblems)


@dataclass(frozen=True)
class Settings:
    dt: float
    steps: int
    apply_steps: int
    max_horizon: int
    drift_strength: float
    reference_field_magnitude: float
    state_weight: float
    control_weight: float
    eta: float
    setpoint_input_weight: float
    lower: np.ndarray
    upper: np.ndarray
    target_tolerance: float
    terminal_tolerance: float
    steady_state_tolerance: float
    input_tolerance: float
    ipopt_tolerance: float
    ipopt_max_iterations: int


def cross(left: ca.MX, right: ca.MX) -> ca.MX:
    return ca.vertcat(
        left[1] * right[2] - left[2] * right[1],
        left[2] * right[0] - left[0] * right[2],
        left[0] * right[1] - left[1] * right[0],
    )


def rotation_step_symbolic(state: ca.MX, control: ca.MX, settings: Settings) -> ca.MX:
    """Exact constant-Hamiltonian Bloch step using stable Taylor series."""
    field = ca.vertcat(control[0], control[1], settings.drift_strength + control[2])
    squared_norm = ca.dot(field, field)
    cosine = 0
    sin_over_norm = 0
    one_minus_cos_over_norm_sq = 0
    angle_scale = 2.0 * settings.dt
    for index in range(12):
        cosine += (-1) ** index * (angle_scale * angle_scale * squared_norm) ** index / math.factorial(2 * index)
        sin_over_norm += (
            (-1) ** index
            * angle_scale ** (2 * index + 1)
            * squared_norm**index
            / math.factorial(2 * index + 1)
        )
        one_minus_cos_over_norm_sq += (
            (-1) ** index
            * angle_scale ** (2 * index + 2)
            * squared_norm**index
            / math.factorial(2 * index + 2)
        )
    return (
        cosine * state
        + one_minus_cos_over_norm_sq * field * ca.dot(field, state)
        + sin_over_norm * cross(field, state)
    )


def rotation_step_numeric(state: np.ndarray, control: np.ndarray, settings: Settings) -> np.ndarray:
    field = np.array([control[0], control[1], settings.drift_strength + control[2]], dtype=float)
    norm = float(np.linalg.norm(field))
    if norm < 1e-14:
        return state.copy()
    direction = field / norm
    angle = 2.0 * norm * settings.dt
    return (
        math.cos(angle) * state
        + (1.0 - math.cos(angle)) * direction * float(direction @ state)
        + math.sin(angle) * np.cross(direction, state)
    )


def fidelity(left: np.ndarray, right: np.ndarray) -> float:
    return float(np.clip(0.5 * (1.0 + np.dot(left, right)), 0.0, 1.0))


def input_violation(values: np.ndarray, settings: Settings) -> float:
    below = np.maximum(settings.lower[:, None] - values, 0.0)
    above = np.maximum(values - settings.upper[:, None], 0.0)
    return float(max(np.max(below), np.max(above)))


def make_reference_input(target: np.ndarray, settings: Settings) -> np.ndarray:
    beta = settings.reference_field_magnitude
    reference = np.array(
        [beta * target[0], beta * target[1], -settings.drift_strength + beta * target[2]],
        dtype=float,
    )
    if np.any(reference < settings.lower) or np.any(reference > settings.upper):
        raise ValueError("The configured reference field does not yield admissible inputs")
    return reference


def bloch_from_angles_symbolic(angles: ca.MX) -> ca.MX:
    return ca.vertcat(
        ca.sin(angles[0]) * ca.cos(angles[1]),
        ca.sin(angles[0]) * ca.sin(angles[1]),
        ca.cos(angles[0]),
    )


def bloch_from_angles_numeric(angles: np.ndarray) -> np.ndarray:
    return np.array(
        [
            math.sin(angles[0]) * math.cos(angles[1]),
            math.sin(angles[0]) * math.sin(angles[1]),
            math.cos(angles[0]),
        ],
        dtype=float,
    )


def target_rows(count: int, seed: int, minimum_initial_infidelity: float, settings: Settings) -> list[dict[str, Any]]:
    rng = np.random.default_rng(seed)
    rows: list[dict[str, Any]] = []
    while len(rows) < count:
        z = rng.uniform(-1.0, 1.0)
        phi = rng.uniform(0.0, 2.0 * math.pi)
        target = np.array([math.sqrt(1.0 - z * z) * math.cos(phi), math.sqrt(1.0 - z * z) * math.sin(phi), z])
        initial_infidelity = 0.5 * (1.0 - target[2])
        if initial_infidelity < minimum_initial_infidelity:
            continue
        reference = make_reference_input(target, settings)
        identifier = len(rows) + 1
        rows.append(
            {
                "target_id": identifier,
                "n_x": target[0], "n_y": target[1], "n_z": target[2],
                "initial_infidelity": initial_infidelity,
                "u_ref_x": reference[0], "u_ref_y": reference[1], "u_ref_z": reference[2],
            }
        )
    return rows


class Controller:
    def __init__(self, scheme: str, target: np.ndarray, reference: np.ndarray, horizon: int, settings: Settings) -> None:
        self.scheme = scheme
        self.target = target
        self.reference = reference
        self.horizon = horizon
        self.settings = settings

    def build_solver(self, length: int) -> tuple[ca.Function, float]:
        started = time.perf_counter()
        controls = ca.MX.sym("U", 3, length)
        current = ca.MX.sym("current", 3)
        state = current
        target = ca.DM(self.target)
        reference = ca.DM(self.reference)
        objective = 0
        if self.scheme == "setpoint":
            angles = ca.MX.sym("setpoint_angles", 2)
            setpoint_state = bloch_from_angles_symbolic(angles)
            beta = self.settings.reference_field_magnitude
            setpoint_input = ca.vertcat(
                beta * setpoint_state[0],
                beta * setpoint_state[1],
                -self.settings.drift_strength + beta * setpoint_state[2],
            )
            for index in range(length):
                control = controls[:, index]
                state = rotation_step_symbolic(state, control, self.settings)
                objective += self.settings.state_weight * (1.0 - 0.5 * (1.0 + ca.dot(state, setpoint_state)))
                objective += self.settings.control_weight * ca.sumsqr(control - setpoint_input)
            objective += self.settings.eta * (1.0 - 0.5 * (1.0 + ca.dot(setpoint_state, target)))
            objective += self.settings.setpoint_input_weight * ca.sumsqr(setpoint_input - reference)
            decision = ca.vertcat(ca.vec(controls), angles)
            constraint = 1.0 - 0.5 * (1.0 + ca.dot(state, setpoint_state))
        else:
            for index in range(length):
                control = controls[:, index]
                state = rotation_step_symbolic(state, control, self.settings)
                objective += self.settings.state_weight * (1.0 - 0.5 * (1.0 + ca.dot(state, target)))
                objective += self.settings.control_weight * ca.sumsqr(control - reference)
            decision = ca.vec(controls)
            constraint = 1.0 - 0.5 * (1.0 + ca.dot(state, target))
        solver = ca.nlpsol(
            f"{self.scheme}_{length}_{id(self)}", "ipopt",
            {"x": decision, "p": current, "f": objective, "g": constraint},
            {
                "ipopt.print_level": 0,
                "ipopt.sb": "yes",
                "ipopt.tol": self.settings.ipopt_tolerance,
                "ipopt.constr_viol_tol": self.settings.ipopt_tolerance,
                "ipopt.acceptable_tol": self.settings.terminal_tolerance,
                "ipopt.acceptable_constr_viol_tol": self.settings.terminal_tolerance,
                "ipopt.acceptable_dual_inf_tol": 1e-6,
                "ipopt.acceptable_compl_inf_tol": 1e-6,
                "ipopt.acceptable_iter": 3,
                "ipopt.max_iter": self.settings.ipopt_max_iterations,
                "print_time": 0,
            },
        )
        return solver, time.perf_counter() - started

    def bounds_and_guess(
        self, length: int, prior: np.ndarray | None, current: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        if prior is None:
            control_guess = np.tile(self.reference[:, None], (1, length))
        else:
            tail = prior[:, self.settings.apply_steps:]
            control_guess = np.empty((3, length), dtype=float)
            copied = min(length, tail.shape[1])
            control_guess[:, :copied] = tail[:, :copied]
            control_guess[:, copied:] = prior[:, [-1]]
        if self.scheme == "tec":
            return (
                control_guess.reshape(-1, order="F"),
                np.tile(self.settings.lower, length),
                np.tile(self.settings.upper, length),
            )
        target_angles = np.array(
            [math.acos(np.clip(self.target[2], -1.0, 1.0)), math.atan2(self.target[1], self.target[0])]
        )
        decision_guess = np.r_[control_guess.reshape(-1, order="F"), target_angles]
        lower = np.r_[np.tile(self.settings.lower, length), [0.0, -math.pi]]
        upper = np.r_[np.tile(self.settings.upper, length), [math.pi, math.pi]]
        return decision_guess, lower, upper

    def run(
        self, target_id: int, repeat: int, include_records: bool = True,
        include_trace: bool = False,
    ) -> dict[str, Any]:
        state = np.array([0.0, 0.0, 1.0], dtype=float)
        applied_controls = np.zeros((3, self.settings.steps), dtype=float)
        prior: np.ndarray | None = None
        records: list[dict[str, Any]] = []
        trace: list[dict[str, Any]] = []
        if include_trace:
            trace.append({
                "target_id": target_id, "scheme": self.scheme, "update": -1,
                "time": 0.0, "state_x": state[0], "state_y": state[1], "state_z": state[2],
                "physical_target_fidelity": fidelity(state, self.target),
                "setpoint_x": np.nan, "setpoint_y": np.nan, "setpoint_z": np.nan,
                "terminal_residual": np.nan, "steady_state_residual": np.nan,
                "control_x": np.nan, "control_y": np.nan, "control_z": np.nan,
            })
        solver_time = model_time = 0.0
        all_success = True
        failure_message = ""
        started = time.perf_counter()
        for update, time_index in enumerate(range(0, self.settings.steps, self.settings.apply_steps)):
            length = min(self.horizon, self.settings.steps - time_index)
            apply_count = min(self.settings.apply_steps, self.settings.steps - time_index)
            setpoint_state = np.full(3, np.nan, dtype=float)
            try:
                solver, construction = self.build_solver(length)
                guess, lower, upper = self.bounds_and_guess(length, prior, state)
                solve_started = time.perf_counter()
                # Enforcing 1-F=0 exactly is ill-conditioned because the
                # fidelity constraint has vanishing gradient at F=1.  The
                # numerical transcription instead enforces the prescribed
                # terminal accuracy with a strict sub-tolerance.
                solution = solver(
                    x0=guess,
                    p=state,
                    lbx=lower,
                    ubx=upper,
                    lbg=-ca.inf,
                    ubg=0.1 * self.settings.terminal_tolerance,
                )
                elapsed = time.perf_counter() - solve_started
                stats = solver.stats()
                status = str(stats.get("return_status", "unknown"))
                success = bool(stats.get("success", False)) or status in {
                    "Solve_Succeeded", "Solved_To_Acceptable_Level"
                }
                iteration_count = int(stats.get("iter_count", -1))
                decision = np.asarray(solution["x"]).reshape(-1)
                optimum = decision[:3 * length].reshape(3, length, order="F")
                predicted = state.copy()
                for local in range(length):
                    predicted = rotation_step_numeric(predicted, optimum[:, local], self.settings)
                if self.scheme == "tec":
                    terminal_residual = 1.0 - fidelity(predicted, self.target)
                    steady_residual = 0.0
                else:
                    xs = bloch_from_angles_numeric(decision[3 * length:])
                    setpoint_state = xs
                    us = make_reference_input(xs, self.settings)
                    terminal_residual = 1.0 - fidelity(predicted, xs)
                    steady_residual = float(np.linalg.norm(rotation_step_numeric(xs, us, self.settings) - xs))
                prediction_violation = input_violation(optimum, self.settings)
            except Exception as error:  # Preserve the failed update in the output.
                construction = elapsed = 0.0
                success = False
                status = type(error).__name__
                iteration_count = -1
                terminal_residual = steady_residual = prediction_violation = float("inf")
                optimum = np.zeros((3, length))
                failure_message = str(error)
            model_time += construction
            solver_time += elapsed
            all_success = all_success and success
            record = {
                "target_id": target_id, "scheme": self.scheme, "repeat": repeat,
                "horizon": self.horizon, "update": update, "time_index": time_index,
                "solver_success": success, "solver_return_code": status,
                "iterations": iteration_count, "model_construction_time_s": construction,
                "solve_time_s": elapsed, "terminal_residual": terminal_residual,
                "steady_state_residual": steady_residual,
                "max_predicted_input_bound_violation": prediction_violation,
            }
            if include_records:
                records.append(record)
            if not success:
                break
            applied_controls[:, time_index:time_index + apply_count] = optimum[:, :apply_count]
            for local in range(apply_count):
                state = rotation_step_numeric(state, optimum[:, local], self.settings)
                if include_trace:
                    trace.append({
                        "target_id": target_id, "scheme": self.scheme, "update": update,
                        "time": (time_index + local + 1) * self.settings.dt,
                        "state_x": state[0], "state_y": state[1], "state_z": state[2],
                        "physical_target_fidelity": fidelity(state, self.target),
                        "setpoint_x": setpoint_state[0], "setpoint_y": setpoint_state[1], "setpoint_z": setpoint_state[2],
                        "terminal_residual": terminal_residual,
                        "steady_state_residual": steady_residual,
                        "control_x": optimum[0, local], "control_y": optimum[1, local], "control_z": optimum[2, local],
                    })
            prior = optimum
        final_infidelity = 1.0 - fidelity(state, self.target)
        summary = {
            "target_id": target_id, "scheme": self.scheme, "repeat": repeat,
            "prediction_horizon": self.horizon, "simulation_steps_completed": int(np.count_nonzero(np.any(applied_controls, axis=0))),
            "mpc_updates": len(records), "run_success": all_success,
            "failure_message": failure_message, "final_fidelity": 1.0 - final_infidelity,
            "final_infidelity": final_infidelity,
            "solver_all_successful": all_success,
            "total_iterations": int(sum(max(0, row["iterations"]) for row in records)),
            "max_terminal_residual": max((row["terminal_residual"] for row in records), default=float("inf")),
            "max_steady_state_residual": max((row["steady_state_residual"] for row in records), default=float("inf")),
            "max_predicted_input_bound_violation": max((row["max_predicted_input_bound_violation"] for row in records), default=float("inf")),
            "max_applied_input_bound_violation": input_violation(applied_controls, self.settings),
            "model_construction_time_s": model_time, "solve_time_s": solver_time,
            "end_to_end_time_s": time.perf_counter() - started,
        }
        return {"summary": summary, "subproblems": records, "controls": applied_controls, "trace": trace}


def accepted(summary: dict[str, Any], settings: Settings) -> bool:
    return bool(
        summary["run_success"]
        and summary["final_infidelity"] <= settings.target_tolerance
        and summary["max_terminal_residual"] <= settings.terminal_tolerance
        and summary["max_steady_state_residual"] <= settings.steady_state_tolerance
        and summary["max_predicted_input_bound_violation"] <= settings.input_tolerance
        and summary["max_applied_input_bound_violation"] <= settings.input_tolerance
    )


def summarise_selected(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for scheme in ("tec", "setpoint"):
        selected = [row for row in rows if row["scheme"] == scheme]
        horizons = np.array([row["L_min_tested"] for row in selected], dtype=float)
        times = np.array([row["solve_time_median_s"] for row in selected], dtype=float)
        output.append(
            {
                "scheme": scheme, "accepted_targets": len(selected),
                "L_min_median": float(np.median(horizons)), "L_min_q25": float(np.quantile(horizons, .25)),
                "L_min_q75": float(np.quantile(horizons, .75)),
                "solve_time_median_s": float(np.median(times)), "solve_time_q25_s": float(np.quantile(times, .25)),
                "solve_time_q75_s": float(np.quantile(times, .75)),
                "worst_final_infidelity": float(max(row["final_infidelity_median"] for row in selected)),
                "worst_terminal_residual": float(max(row["max_terminal_residual"] for row in selected)),
                "worst_steady_state_residual": float(max(row["max_steady_state_residual"] for row in selected)),
            }
        )
    return output


def make_plots(selected: list[dict[str, Any]], output: Path) -> None:
    schemes = ("tec", "setpoint")
    figure, axes = plt.subplots(1, 2, figsize=(9.2, 3.45), constrained_layout=True)
    metrics = (("L_min_tested", "Smallest tested horizon $L_{\\min}^{\\mathrm{scan}}$"), ("solve_time_median_s", "Optimization time [s]"))
    for axis, (metric, label) in zip(axes, metrics):
        values = []
        for scheme_index, scheme in enumerate(schemes):
            current = np.array([row[metric] for row in selected if row["scheme"] == scheme], dtype=float)
            values.append(current)
            axis.boxplot(current, positions=[scheme_index], widths=.48, showfliers=False)
        for target_id in sorted({row["target_id"] for row in selected}):
            pair = {row["scheme"]: row[metric] for row in selected if row["target_id"] == target_id}
            if set(pair) == set(schemes):
                axis.plot([0, 1], [pair["tec"], pair["setpoint"]], color="0.65", linewidth=.7, zorder=1)
                axis.scatter([0, 1], [pair["tec"], pair["setpoint"]], color=["#1f77b4", "#ff7f0e"], s=16, zorder=2)
        axis.set_xticks([0, 1], ["TEC", "Setpoint"])
        axis.set_ylabel(label)
        axis.grid(axis="y", alpha=.3)
    figure.savefig(output / "section_7_3_horizon_time_distributions.pdf", bbox_inches="tight")
    figure.savefig(output / "section_7_3_horizon_time_distributions.png", dpi=300, bbox_inches="tight")

    figure, axes = plt.subplots(1, 2, figsize=(9.2, 3.45), constrained_layout=True)
    metrics = (("final_infidelity_median", "Final infidelity $1-F$"), ("max_terminal_residual", "Maximum terminal residual"))
    for axis, (metric, label) in zip(axes, metrics):
        for scheme_index, scheme in enumerate(schemes):
            current = np.array([max(row[metric], 1e-16) for row in selected if row["scheme"] == scheme], dtype=float)
            axis.boxplot(current, positions=[scheme_index], widths=.48, showfliers=False)
        for target_id in sorted({row["target_id"] for row in selected}):
            pair = {row["scheme"]: max(row[metric], 1e-16) for row in selected if row["target_id"] == target_id}
            if set(pair) == set(schemes):
                axis.plot([0, 1], [pair["tec"], pair["setpoint"]], color="0.65", linewidth=.7, zorder=1)
                axis.scatter([0, 1], [pair["tec"], pair["setpoint"]], color=["#1f77b4", "#ff7f0e"], s=16, zorder=2)
        axis.axhline(1e-8, color="black", linestyle="--", linewidth=1)
        axis.set_yscale("log")
        axis.set_xticks([0, 1], ["TEC", "Setpoint"])
        axis.set_ylabel(label)
        axis.grid(axis="y", alpha=.3)
    figure.savefig(output / "section_7_3_accuracy_residuals.pdf", bbox_inches="tight")
    figure.savefig(output / "section_7_3_accuracy_residuals.png", dpi=300, bbox_inches="tight")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/s7_3_random_target_horizon_scan.json")
    parser.add_argument("--target-count", type=int)
    parser.add_argument("--max-horizon", type=int)
    parser.add_argument("--timing-repeats", type=int)
    parser.add_argument(
        "--resume", type=Path,
        help="Existing result directory created by this script. Completed target/scheme pairs are skipped.",
    )
    arguments = parser.parse_args()
    raw = json.loads(Path(arguments.config).read_text(encoding="utf-8"))
    settings = Settings(
        dt=float(raw["dt"]), steps=int(raw["simulation_steps"]), apply_steps=int(raw["apply_steps"]),
        max_horizon=arguments.max_horizon or int(raw["max_horizon"]), drift_strength=float(raw["drift_strength"]),
        reference_field_magnitude=float(raw["reference_field_magnitude"]), state_weight=float(raw["cost"]["state_weight"]),
        control_weight=float(raw["cost"]["control_weight"]), eta=float(raw["setpoint"]["eta"]),
        setpoint_input_weight=float(raw["setpoint"]["input_weight"]), lower=np.asarray(raw["bounds"]["lower"], dtype=float),
        upper=np.asarray(raw["bounds"]["upper"], dtype=float), target_tolerance=float(raw["acceptance"]["final_infidelity"]),
        terminal_tolerance=float(raw["acceptance"]["terminal_residual"]), steady_state_tolerance=float(raw["acceptance"]["steady_state_residual"]),
        input_tolerance=float(raw["acceptance"]["input_bound_violation"]), ipopt_tolerance=float(raw["ipopt"]["tolerance"]),
        ipopt_max_iterations=int(raw["ipopt"]["max_iterations"]),
    )
    count = arguments.target_count or int(raw["target_count"])
    repeats = arguments.timing_repeats or int(raw["timing_repeats"])
    config = {**raw, "target_count_effective": count, "max_horizon_effective": settings.max_horizon, "timing_repeats_effective": repeats}
    if arguments.resume is None:
        output = Path(raw["output_root"]) / f"s7_3_random_target_horizon_scan_{time.strftime('%Y%m%dT%H%M%S')}"
        output.mkdir(parents=True)
        write_json(output / "config.json", config)
        targets = target_rows(count, int(raw["seed"]), float(raw["minimum_initial_infidelity"]), settings)
        write_csv(output / "targets.csv", targets)
        scans: list[dict[str, Any]] = []
        subproblems: list[dict[str, Any]] = []
        selected: list[dict[str, Any]] = []
        selected_runs: list[dict[str, Any]] = []
    else:
        output = arguments.resume
        saved_config = output / "config.json"
        if not saved_config.exists() or not (output / "targets.csv").exists():
            raise FileNotFoundError("--resume must name a prior Section 7.3 result directory with config.json and targets.csv")
        previous = json.loads(saved_config.read_text(encoding="utf-8"))
        for key in ("target_count_effective", "max_horizon_effective", "timing_repeats_effective"):
            if previous.get(key) != config.get(key):
                raise ValueError(f"Cannot resume with a different {key}; start a new run instead")
        targets = read_csv_rows(output / "targets.csv")
        for row in targets:
            row["target_id"] = int(row["target_id"])
        scans = read_csv_rows(output / "horizon_scan.csv")
        subproblems = read_csv_rows(output / "subproblems.csv")
        selected = read_csv_rows(output / "selected_target_results.csv")
        selected_runs = read_csv_rows(output / "selected_runs.csv")
        print(f"Resuming: {output}")
    for target_row in targets:
        target = np.array([target_row["n_x"], target_row["n_y"], target_row["n_z"]], dtype=float)
        reference = np.array([target_row["u_ref_x"], target_row["u_ref_y"], target_row["u_ref_z"]], dtype=float)
        for scheme in ("tec", "setpoint"):
            already_done = [
                row for row in selected
                if int(row["target_id"]) == int(target_row["target_id"])
                and row["scheme"] == scheme
                and bool(row["accepted"])
            ]
            if already_done:
                print(f"target={target_row['target_id']:02d}, scheme={scheme} (checkpoint complete; skipping)")
                continue
            # An interruption can occur while a pair is being evaluated.  Remove
            # that partial pair before recomputing it so a resumed CSV has no duplicates.
            target_id = int(target_row["target_id"])
            scans = [row for row in scans if not (int(row["target_id"]) == target_id and row["scheme"] == scheme)]
            subproblems = [row for row in subproblems if not (int(row["target_id"]) == target_id and row["scheme"] == scheme)]
            selected_runs = [row for row in selected_runs if not (int(row["target_id"]) == target_id and row["scheme"] == scheme)]
            selected = [row for row in selected if not (int(row["target_id"]) == target_id and row["scheme"] == scheme)]
            accepted_horizon: int | None = None
            print(f"target={target_row['target_id']:02d}, scheme={scheme}")
            for horizon in range(1, settings.max_horizon + 1):
                run = Controller(scheme, target, reference, horizon, settings).run(int(target_row["target_id"]), 0)
                result = run["summary"]
                result["scan_accepted"] = accepted(result, settings)
                scans.append(result)
                subproblems.extend(run["subproblems"])
                write_checkpoint(output, scans, selected, selected_runs, subproblems)
                if result["scan_accepted"]:
                    accepted_horizon = horizon
                    break
            if accepted_horizon is None:
                selected.append({**target_row, "scheme": scheme, "accepted": False, "L_min_tested": float("nan")})
                write_checkpoint(output, scans, selected, selected_runs, subproblems)
                continue
            timing_runs = []
            for repeat in range(repeats):
                run = Controller(scheme, target, reference, accepted_horizon, settings).run(int(target_row["target_id"]), repeat)
                if not accepted(run["summary"], settings):
                    raise RuntimeError("A selected horizon did not reproduce the declared acceptance criteria")
                timing_runs.append(run["summary"])
                selected_runs.append(run["summary"])
                subproblems.extend(run["subproblems"])
            selected.append(
                {
                    **target_row, "scheme": scheme, "accepted": True, "L_min_tested": accepted_horizon,
                    "final_infidelity_median": float(np.median([row["final_infidelity"] for row in timing_runs])),
                    "max_terminal_residual": float(max(row["max_terminal_residual"] for row in timing_runs)),
                    "max_steady_state_residual": float(max(row["max_steady_state_residual"] for row in timing_runs)),
                    "max_input_bound_violation": float(max(row["max_applied_input_bound_violation"] for row in timing_runs)),
                    "solve_time_median_s": float(np.median([row["solve_time_s"] for row in timing_runs])),
                    "model_construction_time_median_s": float(np.median([row["model_construction_time_s"] for row in timing_runs])),
                    "total_iterations_median": float(np.median([row["total_iterations"] for row in timing_runs])),
                }
            )
            write_checkpoint(output, scans, selected, selected_runs, subproblems)
    write_checkpoint(output, scans, selected, selected_runs, subproblems)
    accepted_rows = [row for row in selected if row["accepted"]]
    if len(accepted_rows) != 2 * count:
        raise RuntimeError("At least one target did not meet the criteria before max_horizon; inspect horizon_scan.csv.")
    summary = summarise_selected(accepted_rows)
    write_csv(output / "statistical_summary.csv", summary)
    make_plots(accepted_rows, output)
    print(f"Results: {output}")


if __name__ == "__main__":
    main()
