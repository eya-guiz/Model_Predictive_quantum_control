from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
from scipy.linalg import expm


PAULI = {
    "x": np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128),
    "y": np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128),
    "z": np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128),
}


@dataclass(frozen=True)
class PhysicalityDiagnostics:
    trace_error: float
    hermiticity_error: float
    min_eigenvalue: float


def basis_density(dimension: int, index: int) -> np.ndarray:
    ket = np.zeros(dimension, dtype=np.complex128)
    ket[index] = 1.0
    return np.outer(ket, ket.conj())


def bloch_density(vector: Iterable[float]) -> np.ndarray:
    components = np.asarray(tuple(vector), dtype=float)
    if components.shape != (3,):
        raise ValueError("A Bloch vector must contain exactly three components")
    if abs(np.linalg.norm(components) - 1.0) > 1e-10:
        raise ValueError("A pure-state Bloch vector must have Euclidean norm one")
    return 0.5 * (
        np.eye(2, dtype=np.complex128)
        + components[0] * PAULI["x"]
        + components[1] * PAULI["y"]
        + components[2] * PAULI["z"]
    )


def density_to_real_vector(rho: np.ndarray) -> np.ndarray:
    """Column-major real vectorization matching CasADi's reshape convention."""
    matrix = np.asarray(rho, dtype=np.complex128)
    return np.concatenate(
        [matrix.real.reshape(-1, order="F"), matrix.imag.reshape(-1, order="F")]
    )


def real_vector_to_density(vector: np.ndarray, dimension: int) -> np.ndarray:
    values = np.asarray(vector, dtype=float).reshape(-1)
    count = dimension * dimension
    if values.size != 2 * count:
        raise ValueError(f"Expected {2 * count} real values, received {values.size}")
    real = values[:count].reshape((dimension, dimension), order="F")
    imag = values[count:].reshape((dimension, dimension), order="F")
    return real + 1.0j * imag


def fidelity_with_pure_target(rho: np.ndarray, target_rho: np.ndarray) -> float:
    return float(np.real(np.trace(target_rho.conj().T @ rho)))


def build_hamiltonian(
    drift_axis: str,
    drift_strength: float,
    control_axes: Iterable[str],
    control: np.ndarray,
) -> np.ndarray:
    hamiltonian = drift_strength * PAULI[drift_axis.lower()]
    for amplitude, axis in zip(np.asarray(control, dtype=float), control_axes):
        hamiltonian = hamiltonian + amplitude * PAULI[axis.lower()]
    return hamiltonian


def exact_density_step(
    rho: np.ndarray, hamiltonian: np.ndarray, dt: float
) -> tuple[np.ndarray, np.ndarray]:
    propagator = expm(-1.0j * hamiltonian * dt)
    next_rho = propagator @ rho @ propagator.conj().T
    return next_rho, propagator


def physicality_diagnostics(rho: np.ndarray) -> PhysicalityDiagnostics:
    matrix = np.asarray(rho, dtype=np.complex128)
    hermitian_part = 0.5 * (matrix + matrix.conj().T)
    return PhysicalityDiagnostics(
        trace_error=float(abs(np.trace(matrix) - 1.0)),
        hermiticity_error=float(np.linalg.norm(matrix - matrix.conj().T, ord="fro")),
        min_eigenvalue=float(np.min(np.linalg.eigvalsh(hermitian_part))),
    )


def propagator_unitarity_error(propagator: np.ndarray) -> float:
    identity = np.eye(propagator.shape[0], dtype=np.complex128)
    return float(np.linalg.norm(propagator.conj().T @ propagator - identity, ord="fro"))


def input_bound_violation(
    controls: np.ndarray, lower: np.ndarray, upper: np.ndarray
) -> float:
    values = np.asarray(controls, dtype=float)
    if values.size == 0:
        return 0.0
    lower_column = np.asarray(lower, dtype=float).reshape(-1, 1)
    upper_column = np.asarray(upper, dtype=float).reshape(-1, 1)
    below = np.maximum(lower_column - values, 0.0)
    above = np.maximum(values - upper_column, 0.0)
    return float(max(np.max(below), np.max(above)))


def applied_trajectory_cost(
    states: list[np.ndarray],
    controls: np.ndarray,
    target_rho: np.ndarray,
    input_reference: np.ndarray,
    dt: float,
    state_weight: float,
    control_weight: float,
    terminal_weight: float,
    integrate_stage_cost: bool,
) -> dict[str, float]:
    """Evaluate the manuscript objective once on the controls that were applied.

    Stage costs use X_t (the pre-step state), as in Eq. (8), and are never
    obtained by summing overlapping MPC prediction objectives.
    """
    step_count = controls.shape[1]
    if len(states) != step_count + 1:
        raise ValueError("states must contain one more sample than controls")
    state_infidelities = np.array(
        [1.0 - fidelity_with_pure_target(states[k], target_rho) for k in range(step_count)]
    )
    input_delta = controls - np.asarray(input_reference, dtype=float).reshape(-1, 1)
    control_effort = np.sum(input_delta * input_delta, axis=0)
    scale = dt if integrate_stage_cost else 1.0
    state_cost = float(scale * state_weight * np.sum(state_infidelities))
    control_cost = float(scale * control_weight * np.sum(control_effort))
    final_infidelity = 1.0 - fidelity_with_pure_target(states[-1], target_rho)
    terminal_cost = float(terminal_weight * final_infidelity)
    return {
        "applied_state_cost": state_cost,
        "applied_control_cost": control_cost,
        "applied_terminal_cost": terminal_cost,
        "applied_total_cost": state_cost + control_cost + terminal_cost,
    }
