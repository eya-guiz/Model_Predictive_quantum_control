"""Record one pre-specified representative Section 7.3 trajectory for plotting.

The default target is target 9 from the completed 20-target study.  It was
selected before rerunning because its TEC minimal accepted horizon (11) equals
the sample median and its TEC solve time is closest to the sample median.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from mpqc_benchmark.artifacts import write_csv, write_json
from run_s7_3_random_target_horizon_scan import Controller, Settings, accepted


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def settings_from(config: dict) -> Settings:
    return Settings(
        dt=float(config["dt"]), steps=int(config["simulation_steps"]), apply_steps=int(config["apply_steps"]),
        max_horizon=int(config["max_horizon_effective"]), drift_strength=float(config["drift_strength"]),
        reference_field_magnitude=float(config["reference_field_magnitude"]),
        state_weight=float(config["cost"]["state_weight"]), control_weight=float(config["cost"]["control_weight"]),
        eta=float(config["setpoint"]["eta"]), setpoint_input_weight=float(config["setpoint"]["input_weight"]),
        lower=np.asarray(config["bounds"]["lower"], dtype=float), upper=np.asarray(config["bounds"]["upper"], dtype=float),
        target_tolerance=float(config["acceptance"]["final_infidelity"]), terminal_tolerance=float(config["acceptance"]["terminal_residual"]),
        steady_state_tolerance=float(config["acceptance"]["steady_state_residual"]), input_tolerance=float(config["acceptance"]["input_bound_violation"]),
        ipopt_tolerance=float(config["ipopt"]["tolerance"]), ipopt_max_iterations=int(config["ipopt"]["max_iterations"]),
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="Completed Section 7.3 result directory.")
    parser.add_argument("--target-id", type=int, default=9)
    parser.add_argument("--output", type=Path, help="Defaults to <input>/representative_target_XX.")
    arguments = parser.parse_args()
    source = arguments.input
    config = json.loads((source / "config.json").read_text(encoding="utf-8"))
    target_row = next(row for row in rows(source / "targets.csv") if int(row["target_id"]) == arguments.target_id)
    selected = [row for row in rows(source / "selected_target_results.csv") if int(row["target_id"]) == arguments.target_id]
    horizons = {row["scheme"]: int(float(row["L_min_tested"])) for row in selected}
    if set(horizons) != {"tec", "setpoint"}:
        raise ValueError("The selected results do not contain both schemes for this target.")
    output = arguments.output or source / f"representative_target_{arguments.target_id:02d}"
    output.mkdir(parents=True, exist_ok=True)
    target = np.array([float(target_row["n_x"]), float(target_row["n_y"]), float(target_row["n_z"])])
    reference = np.array([float(target_row["u_ref_x"]), float(target_row["u_ref_y"]), float(target_row["u_ref_z"])])
    settings = settings_from(config)
    all_trace, all_summary, all_subproblems = [], [], []
    for scheme in ("tec", "setpoint"):
        print(f"target={arguments.target_id:02d}, scheme={scheme}, L={horizons[scheme]}")
        result = Controller(scheme, target, reference, horizons[scheme], settings).run(
            arguments.target_id, 0, include_records=True, include_trace=True,
        )
        if not accepted(result["summary"], settings):
            raise RuntimeError(f"Representative {scheme} trajectory did not reproduce all acceptance criteria.")
        all_trace.extend(result["trace"])
        all_summary.append(result["summary"])
        all_subproblems.extend(result["subproblems"])
    write_json(output / "metadata.json", {
        "source_result_directory": str(source), "target_id": arguments.target_id,
        "selection_rule": "TEC L_min equals the sample median (11); TEC solve time closest to the sample median.",
        "target_bloch_vector": target.tolist(), "selected_horizons": horizons,
    })
    write_csv(output / "trajectory.csv", all_trace)
    write_csv(output / "summary.csv", all_summary)
    write_csv(output / "subproblems.csv", all_subproblems)
    print(f"Representative trajectory: {output}")


if __name__ == "__main__":
    main()
