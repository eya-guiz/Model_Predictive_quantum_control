from __future__ import annotations

import time
import uuid
from dataclasses import dataclass
from typing import Any

import casadi as ca
import numpy as np

from .config import BenchmarkConfig
from .diagnostics import (
    PAULI,
    applied_trajectory_cost,
    basis_density,
    bloch_density,
    build_hamiltonian,
    density_to_real_vector,
    exact_density_step,
    fidelity_with_pure_target,
    input_bound_violation,
    physicality_diagnostics,
    propagator_unitarity_error,
    real_vector_to_density,
)


@dataclass
class SolverTemplate:
    horizon: int
    solver: Any
    build_time_s: float


class QubitTECBenchmark:
    """Instrumented one-qubit TEC MPQC reference implementation.

    CasADi uses an RK4 prediction model. Every applied control is independently
    checked with an exact matrix exponential, so the diagnostics do not validate
    the discretization using the same discretization that generated it.
    """

    def __init__(self, config: BenchmarkConfig) -> None:
        config.validate()
        self.config = config
        self.rng = np.random.default_rng(config.seed)
        self.dimension = config.system.dimension
        self.matrix_size = self.dimension * self.dimension
        self.control_count = config.control_count
        self.initial_rho = (
            bloch_density(config.system.initial_bloch_vector)
            if config.system.initial_bloch_vector is not None
            else basis_density(self.dimension, config.system.initial_basis_index)
        )
        self.target_rho = (
            bloch_density(config.system.target_bloch_vector)
            if config.system.target_bloch_vector is not None
            else basis_density(self.dimension, config.system.target_basis_index)
        )
        self.initial_vector = density_to_real_vector(self.initial_rho)
        self.target_vector = density_to_real_vector(self.target_rho)
        self.lower = np.asarray(config.bounds.lower, dtype=float)
        self.upper = np.asarray(config.bounds.upper, dtype=float)
        self.input_reference = np.asarray(config.cost.input_reference, dtype=float)
        self._solver_templates: dict[int, SolverTemplate] = {}
        self._name_suffix = uuid.uuid4().hex[:10]

        start = time.perf_counter()
        self._build_symbolic_model()
        self.base_model_construction_time_s = time.perf_counter() - start

    def _build_symbolic_model(self) -> None:
        vector_size = 2 * self.matrix_size
        x = ca.MX.sym(f"rho_vector_{self._name_suffix}", vector_size)
        u = ca.MX.sym(f"control_{self._name_suffix}", self.control_count)

        drift = (
            self.config.system.drift_strength
            * PAULI[self.config.system.drift_axis.lower()]
        )
        hamiltonian_real = ca.DM(drift.real)
        hamiltonian_imag = ca.DM(drift.imag)
        for index, axis in enumerate(self.config.system.control_axes):
            control_matrix = PAULI[axis.lower()]
            hamiltonian_real = hamiltonian_real + u[index] * ca.DM(control_matrix.real)
            hamiltonian_imag = hamiltonian_imag + u[index] * ca.DM(control_matrix.imag)

        rho_real = ca.reshape(x[: self.matrix_size], self.dimension, self.dimension)
        rho_imag = ca.reshape(x[self.matrix_size :], self.dimension, self.dimension)
        derivative_real = (
            hamiltonian_real @ rho_imag
            + hamiltonian_imag @ rho_real
            - rho_imag @ hamiltonian_real
            - rho_real @ hamiltonian_imag
        )
        derivative_imag = (
            -hamiltonian_real @ rho_real
            + hamiltonian_imag @ rho_imag
            + rho_real @ hamiltonian_real
            - rho_imag @ hamiltonian_imag
        )
        derivative = ca.vertcat(
            ca.reshape(derivative_real, self.matrix_size, 1),
            ca.reshape(derivative_imag, self.matrix_size, 1),
        )
        self.xdot_function = ca.Function(
            f"xdot_{self._name_suffix}", [x, u], [derivative]
        )

        substep = self.config.time.dt / self.config.time.rk4_substeps
        next_x = x
        for _ in range(self.config.time.rk4_substeps):
            k1 = self.xdot_function(next_x, u)
            k2 = self.xdot_function(next_x + 0.5 * substep * k1, u)
            k3 = self.xdot_function(next_x + 0.5 * substep * k2, u)
            k4 = self.xdot_function(next_x + substep * k3, u)
            next_x = next_x + (substep / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        self.step_function = ca.Function(
            f"step_{self._name_suffix}", [x, u], [next_x]
        )
        target = ca.DM(self.target_vector)
        self.fidelity_function = ca.Function(
            f"fidelity_{self._name_suffix}", [x], [ca.dot(target, x)]
        )

    def _solver_options(self) -> dict[str, Any]:
        solver = self.config.solver
        return {
            "error_on_fail": False,
            "print_time": False,
            "ipopt.print_level": solver.print_level,
            "ipopt.max_iter": solver.max_iterations,
            "ipopt.tol": solver.tolerance,
            "ipopt.constr_viol_tol": solver.constraint_violation_tolerance,
            "ipopt.acceptable_tol": solver.acceptable_tolerance,
            "ipopt.linear_solver": solver.linear_solver,
        }

    def _get_solver_template(self, horizon: int) -> tuple[SolverTemplate, bool]:
        cached = self._solver_templates.get(horizon)
        if cached is not None:
            return cached, False

        start = time.perf_counter()
        state_parameter = ca.MX.sym(
            f"initial_state_L{horizon}_{self._name_suffix}", 2 * self.matrix_size
        )
        controls = ca.MX.sym(
            f"controls_L{horizon}_{self._name_suffix}", self.control_count, horizon
        )
        state = state_parameter
        objective = 0
        dt_scale = self.config.time.dt if self.config.cost.integrate_stage_cost else 1.0
        reference = ca.DM(self.input_reference)
        for step in range(horizon):
            control = controls[:, step]
            objective += dt_scale * (
                self.config.cost.state_weight
                * (1.0 - self.fidelity_function(state))
                + self.config.cost.control_weight * ca.sumsqr(control - reference)
            )
            state = self.step_function(state, control)
        terminal_residual = 1.0 - self.fidelity_function(state)
        objective += self.config.cost.terminal_weight * terminal_residual
        nlp = {
            "x": ca.vec(controls),
            "p": state_parameter,
            "f": objective,
            "g": terminal_residual,
        }
        solver = ca.nlpsol(
            f"tec_solver_L{horizon}_{self._name_suffix}",
            self.config.solver.plugin,
            nlp,
            self._solver_options(),
        )
        template = SolverTemplate(
            horizon=horizon,
            solver=solver,
            build_time_s=time.perf_counter() - start,
        )
        self._solver_templates[horizon] = template
        return template, True

    def _initial_guess(self, horizon: int) -> np.ndarray:
        strategy = self.config.initialization.strategy
        amplitude = np.asarray(self.config.initialization.amplitude, dtype=float)
        if strategy == "zeros":
            return np.zeros((self.control_count, horizon), dtype=float)
        if strategy == "uniform_random":
            sample = self.rng.uniform(-1.0, 1.0, size=(self.control_count, horizon))
            return amplitude.reshape(-1, 1) * sample
        phase = np.linspace(0.0, np.pi, horizon)
        guess = np.empty((self.control_count, horizon), dtype=float)
        for index in range(self.control_count):
            guess[index] = amplitude[index] * np.sin(phase + index * np.pi / 2.0)
        return guess

    def _shift_guess(
        self, previous: np.ndarray | None, horizon: int, applied_steps: int
    ) -> np.ndarray:
        if previous is None:
            return self._initial_guess(horizon)
        guess = np.repeat(self.input_reference.reshape(-1, 1), horizon, axis=1)
        tail = previous[:, applied_steps:]
        copied = min(tail.shape[1], horizon)
        if copied:
            guess[:, :copied] = tail[:, :copied]
        return guess

    def _model_step(self, vector: np.ndarray, control: np.ndarray) -> np.ndarray:
        return np.asarray(self.step_function(vector, control), dtype=float).reshape(-1)

    def _exact_prediction_terminal(
        self, start_rho: np.ndarray, controls: np.ndarray
    ) -> float:
        rho = np.array(start_rho, copy=True)
        for step in range(controls.shape[1]):
            hamiltonian = build_hamiltonian(
                self.config.system.drift_axis,
                self.config.system.drift_strength,
                self.config.system.control_axes,
                controls[:, step],
            )
            rho, _ = exact_density_step(rho, hamiltonian, self.config.time.dt)
        return abs(1.0 - fidelity_with_pure_target(rho, self.target_rho))

    @staticmethod
    def _safe_stat(stats: dict[str, Any], key: str, default: Any = None) -> Any:
        value = stats.get(key, default)
        if isinstance(value, np.generic):
            return value.item()
        return value

    def run(self) -> dict[str, Any]:
        run_start = time.perf_counter()
        current_exact_rho = np.array(self.initial_rho, copy=True)
        current_model_vector = np.array(self.initial_vector, copy=True)
        exact_states = [np.array(current_exact_rho, copy=True)]
        model_validation_states = [np.array(self.initial_rho, copy=True)]
        controls_applied: list[np.ndarray] = []
        propagator_errors: list[float] = []
        local_dynamics_defects: list[float] = [0.0]
        model_exact_state_deviations: list[float] = [0.0]
        subproblems: list[dict[str, Any]] = []
        previous_window: np.ndarray | None = None
        completed_steps = 0
        all_successful = True
        failure_message = ""

        while completed_steps < self.config.time.simulation_steps:
            horizon = self.config.time.prediction_horizon
            apply_count = min(
                self.config.time.apply_steps,
                self.config.time.simulation_steps - completed_steps,
            )
            template, newly_built = self._get_solver_template(horizon)
            guess = self._shift_guess(previous_window, horizon, apply_count)
            lower = np.tile(self.lower, horizon)
            upper = np.tile(self.upper, horizon)

            solve_start = time.perf_counter()
            try:
                solution = template.solver(
                    x0=guess.reshape(-1, order="F"),
                    lbx=lower,
                    ubx=upper,
                    lbg=np.array([-self.config.solver.terminal_constraint_tolerance]),
                    ubg=np.array([self.config.solver.terminal_constraint_tolerance]),
                    p=current_model_vector,
                )
                solve_exception = None
            except Exception as error:  # CasADi plugin errors must still become run evidence.
                solution = None
                solve_exception = error
            solve_time = time.perf_counter() - solve_start
            stats = template.solver.stats()
            return_status = str(self._safe_stat(stats, "return_status", "exception"))
            solver_success = bool(self._safe_stat(stats, "success", False))
            current_fidelity_model = float(self.fidelity_function(current_model_vector))
            current_fidelity_exact = fidelity_with_pure_target(
                current_exact_rho, self.target_rho
            )

            record: dict[str, Any] = {
                "update_index": len(subproblems),
                "applied_start_index": completed_steps,
                "prediction_horizon": horizon,
                "applied_steps": apply_count,
                "solver_template_newly_built": newly_built,
                "solver_construction_time_s": template.build_time_s if newly_built else 0.0,
                "solve_time_s": solve_time,
                "solver_return_code": return_status,
                "solver_success": solver_success,
                "solver_iterations": self._safe_stat(stats, "iter_count", -1),
                "solver_wall_time_reported_s": self._safe_stat(stats, "t_wall_total"),
                "current_fidelity_model": current_fidelity_model,
                "current_infidelity_model": 1.0 - current_fidelity_model,
                "current_fidelity_exact": current_fidelity_exact,
                "current_infidelity_exact": 1.0 - current_fidelity_exact,
            }
            if solution is None:
                all_successful = False
                failure_message = str(solve_exception)
                record.update(
                    {
                        "objective_value": np.nan,
                        "terminal_residual_model": np.nan,
                        "terminal_residual_exact": np.nan,
                        "max_constraint_violation": np.nan,
                        "max_input_violation_window": np.nan,
                        "applied_first_stage_cost_model": np.nan,
                        "exception": failure_message,
                    }
                )
                subproblems.append(record)
                break

            optimized = np.asarray(solution["x"], dtype=float).reshape(
                (self.control_count, horizon), order="F"
            )
            previous_window = optimized.copy()
            terminal_residual_model = abs(float(np.asarray(solution["g"]).reshape(-1)[0]))
            terminal_residual_exact = self._exact_prediction_terminal(
                current_exact_rho, optimized
            )
            window_input_violation = input_bound_violation(optimized, self.lower, self.upper)
            stage_scale = (
                self.config.time.dt
                if self.config.cost.integrate_stage_cost
                else 1.0
            )
            first_control_delta = optimized[:, 0] - self.input_reference
            applied_first_stage_cost_model = stage_scale * (
                self.config.cost.state_weight * (1.0 - current_fidelity_model)
                + self.config.cost.control_weight
                * float(first_control_delta @ first_control_delta)
            )
            record.update(
                {
                    "objective_value": float(solution["f"]),
                    "terminal_residual_model": terminal_residual_model,
                    "terminal_residual_exact": terminal_residual_exact,
                    "max_constraint_violation": max(
                        max(
                            terminal_residual_model
                            - self.config.solver.terminal_constraint_tolerance,
                            0.0,
                        ),
                        window_input_violation,
                    ),
                    "max_input_violation_window": window_input_violation,
                    "applied_first_stage_cost_model": applied_first_stage_cost_model,
                    "exception": "",
                }
            )
            subproblems.append(record)

            if not solver_success:
                all_successful = False
                failure_message = (
                    f"Solver failed at update {record['update_index']}: {return_status}"
                )
                if self.config.solver.require_success:
                    break

            for local_step in range(apply_count):
                control = optimized[:, local_step]
                model_next_vector = self._model_step(current_model_vector, control)
                model_next_rho = real_vector_to_density(
                    model_next_vector, self.dimension
                )
                hamiltonian = build_hamiltonian(
                    self.config.system.drift_axis,
                    self.config.system.drift_strength,
                    self.config.system.control_axes,
                    control,
                )
                exact_next_rho, propagator = exact_density_step(
                    current_exact_rho, hamiltonian, self.config.time.dt
                )
                local_model_next_vector = self._model_step(
                    density_to_real_vector(current_exact_rho), control
                )
                local_model_next_rho = real_vector_to_density(
                    local_model_next_vector, self.dimension
                )
                controls_applied.append(np.array(control, copy=True))
                propagator_errors.append(propagator_unitarity_error(propagator))
                local_dynamics_defects.append(
                    float(
                        np.linalg.norm(
                            local_model_next_rho - exact_next_rho, ord="fro"
                        )
                    )
                )
                model_exact_state_deviations.append(
                    float(np.linalg.norm(model_next_rho - exact_next_rho, ord="fro"))
                )
                model_validation_states.append(model_next_rho)
                exact_states.append(exact_next_rho)
                current_exact_rho = exact_next_rho
                current_model_vector = model_next_vector
                completed_steps += 1

        for index, record in enumerate(subproblems):
            record["value_function_decrease"] = np.nan
            record["lyapunov_decrease_rhs"] = np.nan
            record["lyapunov_inequality_residual"] = np.nan
            record["lyapunov_decrease_satisfied"] = ""
            if index + 1 >= len(subproblems):
                continue
            next_record = subproblems[index + 1]
            values = (
                record.get("objective_value", np.nan),
                next_record.get("objective_value", np.nan),
                record.get("applied_first_stage_cost_model", np.nan),
            )
            if not all(np.isfinite(value) for value in values):
                continue
            value_decrease = float(values[1] - values[0])
            stage_cost = float(values[2])
            lyapunov_residual = value_decrease + stage_cost
            record["value_function_decrease"] = value_decrease
            record["lyapunov_decrease_rhs"] = -stage_cost
            record["lyapunov_inequality_residual"] = lyapunov_residual
            record["lyapunov_decrease_satisfied"] = (
                lyapunov_residual
                <= self.config.validation.lyapunov_decrease_tolerance
            )

        control_matrix = (
            np.stack(controls_applied, axis=1)
            if controls_applied
            else np.zeros((self.control_count, 0), dtype=float)
        )
        cost = applied_trajectory_cost(
            exact_states,
            control_matrix,
            self.target_rho,
            self.input_reference,
            self.config.time.dt,
            self.config.cost.state_weight,
            self.config.cost.control_weight,
            self.config.cost.terminal_weight,
            self.config.cost.integrate_stage_cost,
        )
        trajectory_rows: list[dict[str, Any]] = []
        for index, rho in enumerate(exact_states):
            physicality = physicality_diagnostics(rho)
            trajectory_rows.append(
                {
                    "state_index": index,
                    "time": index * self.config.time.dt,
                    "fidelity": fidelity_with_pure_target(rho, self.target_rho),
                    "infidelity": 1.0
                    - fidelity_with_pure_target(rho, self.target_rho),
                    "one_step_dynamics_defect": local_dynamics_defects[index],
                    "model_exact_state_deviation": model_exact_state_deviations[index],
                    "trace_error": physicality.trace_error,
                    "hermiticity_error": physicality.hermiticity_error,
                    "min_eigenvalue": physicality.min_eigenvalue,
                }
            )
        control_rows: list[dict[str, Any]] = []
        for step in range(control_matrix.shape[1]):
            row: dict[str, Any] = {
                "control_index": step,
                "time": step * self.config.time.dt,
            }
            for channel, axis in enumerate(self.config.system.control_axes):
                row[f"u_{channel}_{axis}"] = control_matrix[channel, step]
            control_rows.append(row)

        terminal_model_values = [
            float(record["terminal_residual_model"])
            for record in subproblems
            if np.isfinite(record["terminal_residual_model"])
        ]
        terminal_exact_values = [
            float(record["terminal_residual_exact"])
            for record in subproblems
            if np.isfinite(record["terminal_residual_exact"])
        ]
        final_fidelity = fidelity_with_pure_target(exact_states[-1], self.target_rho)
        reference_hamiltonian = build_hamiltonian(
            self.config.system.drift_axis,
            self.config.system.drift_strength,
            self.config.system.control_axes,
            self.input_reference,
        )
        target_after_reference_step, _ = exact_density_step(
            self.target_rho, reference_hamiltonian, self.config.time.dt
        )
        target_invariance_residual = abs(
            1.0
            - fidelity_with_pure_target(
                target_after_reference_step, self.target_rho
            )
        )
        trajectory_physicality = [physicality_diagnostics(rho) for rho in exact_states]
        max_window_input_violation = max(
            (
                float(record["max_input_violation_window"])
                for record in subproblems
                if np.isfinite(record["max_input_violation_window"])
            ),
            default=0.0,
        )
        applied_input_violation = input_bound_violation(
            control_matrix, self.lower, self.upper
        )
        solver_build_time = sum(
            template.build_time_s for template in self._solver_templates.values()
        )
        solve_time_total = sum(float(record["solve_time_s"]) for record in subproblems)
        lyapunov_residuals = [
            float(record["lyapunov_inequality_residual"])
            for record in subproblems
            if np.isfinite(record["lyapunov_inequality_residual"])
        ]
        lyapunov_satisfied = [
            bool(record["lyapunov_decrease_satisfied"])
            for record in subproblems
            if record["lyapunov_decrease_satisfied"] != ""
        ]
        lyapunov_check_passed = bool(lyapunov_satisfied) and all(lyapunov_satisfied)
        run_success = (
            all_successful
            and completed_steps == self.config.time.simulation_steps
            and max(terminal_model_values, default=np.inf)
            <= self.config.validation.terminal_residual_tolerance
            and max(terminal_exact_values, default=np.inf)
            <= self.config.validation.terminal_residual_tolerance
            and max(local_dynamics_defects, default=np.inf)
            <= self.config.validation.dynamics_defect_tolerance
            and max(applied_input_violation, max_window_input_violation)
            <= self.config.validation.input_violation_tolerance
            and max(propagator_errors, default=0.0)
            <= self.config.validation.unitarity_tolerance
            and (
                self.config.time.apply_steps != 1
                or lyapunov_check_passed
                or len(subproblems) <= 1
            )
        )
        summary = {
            "run_success": run_success,
            "solver_all_successful": all_successful,
            "failure_message": failure_message,
            "experiment_name": self.config.experiment_name,
            "run_label": self.config.run_label,
            "seed": self.config.seed,
            "dimension": self.dimension,
            "control_count": self.control_count,
            "dt": self.config.time.dt,
            "simulation_steps_requested": self.config.time.simulation_steps,
            "simulation_steps_completed": completed_steps,
            "prediction_horizon": self.config.time.prediction_horizon,
            "apply_steps": self.config.time.apply_steps,
            "mpc_updates": len(subproblems),
            "target_invariance_residual": target_invariance_residual,
            "reference_input_bound_violation": input_bound_violation(
                self.input_reference.reshape(-1, 1), self.lower, self.upper
            ),
            "final_fidelity": final_fidelity,
            "final_infidelity": 1.0 - final_fidelity,
            **cost,
            "max_dynamics_defect": max(local_dynamics_defects, default=0.0),
            "max_model_exact_state_deviation": max(
                model_exact_state_deviations, default=0.0
            ),
            "max_input_bound_violation": max(
                applied_input_violation, max_window_input_violation
            ),
            "max_applied_input_bound_violation": applied_input_violation,
            "max_predicted_input_bound_violation": max_window_input_violation,
            "max_terminal_residual_model": max(terminal_model_values, default=np.nan),
            "max_terminal_residual_exact": max(terminal_exact_values, default=np.nan),
            "max_propagator_unitarity_error": max(propagator_errors, default=0.0),
            "max_trace_error": max(
                diagnostic.trace_error for diagnostic in trajectory_physicality
            ),
            "max_hermiticity_error": max(
                diagnostic.hermiticity_error for diagnostic in trajectory_physicality
            ),
            "minimum_density_eigenvalue": min(
                diagnostic.min_eigenvalue for diagnostic in trajectory_physicality
            ),
            "lyapunov_updates_checked": len(lyapunov_residuals),
            "lyapunov_updates_satisfied": sum(lyapunov_satisfied),
            "lyapunov_fraction_satisfied": (
                float(np.mean(lyapunov_satisfied)) if lyapunov_satisfied else np.nan
            ),
            "max_lyapunov_inequality_residual": max(
                lyapunov_residuals, default=np.nan
            ),
            "base_model_construction_time_s": self.base_model_construction_time_s,
            "solver_construction_time_s": solver_build_time,
            "model_construction_time_s": self.base_model_construction_time_s
            + solver_build_time,
            "solve_time_s": solve_time_total,
            "end_to_end_time_s": self.base_model_construction_time_s
            + (time.perf_counter() - run_start),
        }
        arrays = {
            "controls": control_matrix,
            "exact_states": np.stack(exact_states),
            "model_validation_states": np.stack(model_validation_states),
            "target_state": self.target_rho,
            "initial_state": self.initial_rho,
        }
        return {
            "summary": summary,
            "subproblems": subproblems,
            "trajectory": trajectory_rows,
            "controls": control_rows,
            "arrays": arrays,
        }
