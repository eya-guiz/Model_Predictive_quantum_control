"""Appendix N-sweep for the solver-matched GHZ QOC versus MPQC benchmark.

The physical duration T is fixed.  Thus increasing N changes the number of
piecewise-constant control variables and the discretization, not the time
available for preparing the GHZ state.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from mpqc_benchmark.artifacts import write_csv, write_json
from run_s7_4_ghz_qoc_mpqc_pareto import (
    GHZSystem,
    Settings,
    aggregate,
    run_controller,
    selection,
)


plt.switch_backend("Agg")


def make_settings(raw: dict[str, Any], steps: int, duration: float) -> Settings:
    return Settings(
        dt=duration / steps,
        steps=steps,
        apply_steps=int(raw["apply_steps"]),
        rk4_substeps=int(raw["rk4_substeps"]),
        coupling=float(raw["coupling"]),
        amplitude_bound=float(raw["amplitude_bound"]),
        state_weight=float(raw["cost"]["state_weight"]),
        control_weight=float(raw["cost"]["control_weight"]),
        terminal_weight=float(raw["cost"]["terminal_weight"]),
        ipopt_tolerance=float(raw["ipopt"]["tolerance"]),
        ipopt_max_iterations=int(raw["ipopt"]["max_iterations"]),
        input_tolerance=float(raw["validation"]["input_bound_violation"]),
        dynamics_tolerance=float(raw["validation"]["model_exact_state_deviation"]),
        accuracy_floor=float(raw["selection"]["accuracy_floor"]),
        qoc_accuracy_factor=float(raw["selection"]["qoc_accuracy_factor"]),
    )


def create_plot(
    summary: list[dict[str, Any]], selected: list[dict[str, Any]], output: Path, qubits: int
) -> None:
    qoc_rows = sorted(
        [row for row in summary if int(row["qubits"]) == qubits and row["scheme"] == "qoc"],
        key=lambda row: row["simulation_steps"] if "simulation_steps" in row else row["prediction_horizon"],
    )
    # The summary groups do not retain N separately from full-QOC horizon;
    # for MPQC the parent runner adds it below as full_horizon_N.
    qoc_rows = sorted(qoc_rows, key=lambda row: row["prediction_horizon"])
    selected_rows = sorted(selected, key=lambda row: row["full_horizon_N"])
    qoc_N = np.array([row["prediction_horizon"] for row in qoc_rows], dtype=float)
    qoc_time = np.array([row["solve_time_s_median"] for row in qoc_rows], dtype=float)
    qoc_error = np.array([max(row["final_infidelity_median"], 1e-16) for row in qoc_rows], dtype=float)
    mpqc_N = np.array([row["full_horizon_N"] for row in selected_rows], dtype=float)
    mpqc_time = np.array([row["solve_time_s_median"] for row in selected_rows], dtype=float)
    mpqc_error = np.array([max(row["final_infidelity_median"], 1e-16) for row in selected_rows], dtype=float)
    labels = [int(row["prediction_horizon"]) for row in selected_rows]

    figure, axes = plt.subplots(1, 2, figsize=(9.1, 3.45), constrained_layout=True)
    axes[0].plot(qoc_N, qoc_time, "o-", color="crimson", label="Full-horizon QOC")
    if selected_rows:
        axes[0].plot(mpqc_N, mpqc_time, "s-", color="#1f77b4", label="Selected MPQC")
        for x, y, label in zip(mpqc_N, mpqc_time, labels):
            axes[0].annotate(f"$L={label}$", (x, y), xytext=(4, 5), textcoords="offset points", fontsize=8)
    axes[0].set_xlabel("Number of control intervals $N$")
    axes[0].set_ylabel("Optimization time [s]")
    axes[0].grid(alpha=.3)
    axes[0].legend()

    axes[1].plot(qoc_N, qoc_error, "o-", color="crimson", label="Full-horizon QOC")
    if selected_rows:
        axes[1].plot(mpqc_N, mpqc_error, "s-", color="#1f77b4", label="Selected MPQC")
        for x, y, label in zip(mpqc_N, mpqc_error, labels):
            axes[1].annotate(f"$L={label}$", (x, y), xytext=(4, 5), textcoords="offset points", fontsize=8)
    axes[1].set_xlabel("Number of control intervals $N$")
    axes[1].set_ylabel("Final infidelity $1-F$")
    axes[1].set_yscale("log")
    axes[1].grid(which="both", alpha=.3)
    axes[1].legend()
    figure.savefig(output / f"appendix_n_sweep_n{qubits}.pdf", bbox_inches="tight")
    figure.savefig(output / f"appendix_n_sweep_n{qubits}.png", dpi=300, bbox_inches="tight")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/appendix_n_sweep_ghz.json")
    parser.add_argument("--n-values", nargs="+", type=int)
    parser.add_argument("--seeds", type=int)
    parser.add_argument("--mpqc-horizons", nargs="+", type=int)
    arguments = parser.parse_args()
    raw = json.loads(Path(arguments.config).read_text(encoding="utf-8"))
    n_values = arguments.n_values or list(raw["N_values"])
    seed_count = arguments.seeds or int(raw["seed_count"])
    qubits = int(raw["qubits"])
    output = Path(raw["output_root"]) / f"appendix_n_sweep_ghz_{time.strftime('%Y%m%dT%H%M%S')}"
    output.mkdir(parents=True)
    write_json(output / "config.json", {**raw, "effective_N_values": n_values, "effective_seed_count": seed_count})

    all_runs: list[dict[str, Any]] = []
    all_subproblems: list[dict[str, Any]] = []
    duration = float(raw["total_duration"])
    for steps in n_values:
        settings = make_settings(raw, int(steps), duration)
        requested_horizons = arguments.mpqc_horizons or raw["mpqc_horizons"]
        horizons = sorted({int(value) for value in requested_horizons if int(value) < steps})
        if not horizons:
            raise ValueError(f"No candidate MPQC horizons are smaller than N={steps}.")
        system = GHZSystem(qubits, settings)
        for seed_offset in range(seed_count):
            seed = int(raw["seed"]) + 100003 * int(steps) + seed_offset
            rng = np.random.default_rng(seed)
            base_guess = rng.uniform(-settings.amplitude_bound, settings.amplitude_bound, size=(system.control_count, settings.steps)) * float(raw["initialization_scale"])
            print(f"N={steps}, seed={seed_offset + 1}/{seed_count}, scheme=qoc")
            run = run_controller(system, "qoc", settings.steps, seed, base_guess)
            run["summary"]["full_horizon_N"] = steps
            all_runs.append(run["summary"])
            for record in run["subproblems"]:
                record["full_horizon_N"] = steps
            all_subproblems.extend(run["subproblems"])
            for horizon in horizons:
                print(f"N={steps}, seed={seed_offset + 1}/{seed_count}, scheme=mpqc, L={horizon}")
                run = run_controller(system, "mpqc", horizon, seed, base_guess)
                run["summary"]["full_horizon_N"] = steps
                all_runs.append(run["summary"])
                for record in run["subproblems"]:
                    record["full_horizon_N"] = steps
                all_subproblems.extend(run["subproblems"])

    write_csv(output / "run_results.csv", all_runs)
    write_csv(output / "subproblems.csv", all_subproblems)
    # Aggregate separately for each N, otherwise equal L values from different
    # full horizons would be incorrectly mixed.
    summary: list[dict[str, Any]] = []
    selected: list[dict[str, Any]] = []
    tuning: list[dict[str, Any]] = []
    for steps in n_values:
        current_runs = [row for row in all_runs if int(row["full_horizon_N"]) == int(steps)]
        settings = make_settings(raw, int(steps), duration)
        current_summary = aggregate(current_runs, settings)
        for row in current_summary:
            row["full_horizon_N"] = int(steps)
        current_selected, current_tuning = selection(current_summary, settings)
        for row in current_selected:
            row["full_horizon_N"] = int(steps)
        for row in current_tuning:
            row["full_horizon_N"] = int(steps)
        summary.extend(current_summary); selected.extend(current_selected); tuning.extend(current_tuning)
    write_csv(output / "statistical_summary.csv", summary)
    write_csv(output / "selected_horizons.csv", selected)
    write_csv(output / "tuning_summary.csv", tuning)
    create_plot(summary, selected, output, qubits)
    print(f"Results: {output}")


if __name__ == "__main__":
    main()
