"""Section 7.5: finite-shot tomography cost for closed-loop Basic MPQC.

The nominal two-qubit plant is controlled with Basic MPQC.  At every MPC
update, the controller receives either the exact state (the ideal-feedback
reference) or an estimate from nine-setting local-Pauli tomography.  Each
finite-shot setting is repeated independently for the configured number of
Monte-Carlo trials.  Checkpoints are written after every completed trial and
can be resumed without repeating completed work.
"""

from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from mpqc_benchmark.artifacts import write_csv, write_json
from run_s7_5_static_mismatch_tomography import (
    GHZSystem,
    make_settings,
    run_feedback,
)


plt.switch_backend("Agg")


def read_rows(path: Path) -> list[dict[str, Any]]:
    if not path.exists() or path.stat().st_size == 0:
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def completed(rows: list[dict[str, Any]], shots: int | None, trial: int) -> bool:
    label = "ideal" if shots is None else str(shots)
    return any(str(row["shots"]) == label and int(row["trial"]) == trial for row in rows)


def statistics(rows: list[dict[str, Any]], shots: int | None) -> tuple[float, float, float, int]:
    label = "ideal" if shots is None else str(shots)
    values = np.asarray(
        [float(row["final_infidelity"]) for row in rows
         if str(row["shots"]) == label and str(row["run_success"]) == "True"],
        dtype=float,
    )
    if len(values) == 0:
        return float("nan"), float("nan"), float("nan"), 0
    return float(np.mean(values)), float(np.min(values)), float(np.max(values)), int(len(values))


def write_summary(rows: list[dict[str, Any]], shots: tuple[int, ...], output: Path) -> list[dict[str, Any]]:
    summary: list[dict[str, Any]] = []
    for budget in (*shots, None):
        mean, minimum, maximum, count = statistics(rows, budget)
        copies_update = 0 if budget is None else 9 * budget
        # M=1: one tomography estimate is requested for each of the 80 updates.
        updates = int(float(next((r["mpc_updates"] for r in rows if str(r["shots"]) == ("ideal" if budget is None else str(budget))), 80)))
        summary.append({
            "scheme": "basic",
            "shots_per_setting": "ideal" if budget is None else budget,
            "successful_trials": count,
            "mean_final_infidelity": mean,
            "min_final_infidelity": minimum,
            "max_final_infidelity": maximum,
            "copies_per_update": copies_update,
            "copies_per_run": 0 if budget is None else copies_update * updates,
        })
    write_csv(output / "tomography_budget_summary.csv", summary)
    return summary


def plot(rows: list[dict[str, Any]], shots: tuple[int, ...], output: Path) -> None:
    budgets = np.asarray(shots, dtype=float)
    values = [statistics(rows, int(budget)) for budget in budgets]
    means = np.asarray([value[0] for value in values])
    lower = np.asarray([value[1] for value in values])
    upper = np.asarray([value[2] for value in values])
    ideal_mean, _, _, ideal_count = statistics(rows, None)
    figure, axis = plt.subplots(figsize=(7.2, 5.0), constrained_layout=True)
    axis.errorbar(budgets, means, yerr=np.vstack((means - lower, upper - means)), fmt="o-", color="#1f77b4", capsize=3,
                  label="Finite-shot tomography")
    if ideal_count:
        axis.axhline(ideal_mean, color="black", linestyle="--", linewidth=1.2,
                     label="Ideal state feedback")
    axis.set_xscale("log")
    axis.set_yscale("log")
    axis.set_xlabel(r"$N_{\mathrm{shot}}$", fontsize=22)
    axis.set_ylabel(r"Final infidelity $1-F$", fontsize=22)
    axis.tick_params(axis="both", which="major", labelsize=18)
    axis.tick_params(axis="both", which="minor", labelsize=14)
    axis.grid(True, which="both", alpha=0.25)
    axis.legend(fontsize=18)
    figure.savefig(output / "section_7_5_tomography_budget.pdf", bbox_inches="tight")
    figure.savefig(output / "section_7_5_tomography_budget.png", dpi=300, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/s7_5_basic_tomography_budget.json")
    parser.add_argument("--trials", type=int, help="Override the number of finite-shot trials.")
    parser.add_argument("--resume", type=Path, help="Existing result directory to continue.")
    arguments = parser.parse_args()
    raw = json.loads(Path(arguments.config).read_text(encoding="utf-8"))
    trials = arguments.trials if arguments.trials is not None else int(raw["tomography_trials"])
    settings = make_settings(raw, None)
    shots = tuple(int(value) for value in raw["tomography_shots"])
    effective = {**raw, "effective_tomography_trials": trials, "scheme": "basic"}

    if arguments.resume is None:
        output = Path(raw["output_root"]) / f"{raw['experiment_name']}_{time.strftime('%Y%m%dT%H%M%S')}"
        output.mkdir(parents=True, exist_ok=False)
        write_json(output / "config.json", effective)
        rows: list[dict[str, Any]] = []
        subproblems: list[dict[str, Any]] = []
    else:
        output = arguments.resume
        previous = json.loads((output / "config.json").read_text(encoding="utf-8"))
        # The number of requested Monte-Carlo trials is deliberately allowed
        # to change on resume: it affects only how many additional stochastic
        # replications are generated, not the physical experiment.
        for key in (
            "dt", "simulation_steps", "apply_steps", "rk4_substeps", "coupling",
            "amplitude_bound", "mpqc_horizon", "cost", "ipopt", "tomography_shots",
        ):
            if previous.get(key) != effective.get(key):
                raise ValueError(f"Cannot resume with a different {key}.")
        rows, subproblems = read_rows(output / "tomography_results.csv"), read_rows(output / "tomography_subproblems.csv")
        print(f"Resuming: {output}")

    system = GHZSystem(2, settings)
    seed = int(raw["seed"])
    horizon = int(raw["mpqc_horizon"])
    for budget in (*shots, None):
        # The ideal reference is deterministic; one run is sufficient.
        trial_count = 1 if budget is None else trials
        label = "ideal" if budget is None else str(budget)
        for trial in range(trial_count):
            if completed(rows, budget, trial):
                continue
            print(f"Basic MPQC: shots={label}, trial={trial + 1}/{trial_count}", flush=True)
            # Keep the initial control sequence identical for every shot
            # budget and Monte-Carlo realization.  Variability must then be
            # attributable solely to finite-shot tomography, not to a
            # different IPOPT basin of attraction.
            guess_rng = np.random.default_rng(seed)
            guess = guess_rng.uniform(-settings.amplitude_bound, settings.amplitude_bound, (4, settings.steps)) * float(raw["initialization_scale"])
            estimate_rng = np.random.default_rng(seed + 100_000 * (0 if budget is None else budget) + trial)
            result, updates = run_feedback(system, "basic", horizon, budget, trial, guess, estimate_rng, 1e-8)
            result.update({"mpc_updates": len(updates), "prediction_horizon": horizon, "apply_steps": settings.apply_steps})
            rows.append(result)
            subproblems.extend(updates)
            write_csv(output / "tomography_results.csv", rows)
            write_csv(output / "tomography_subproblems.csv", subproblems)

    write_summary(rows, shots, output)
    plot(rows, shots, output)
    print(f"Results: {output}")


if __name__ == "__main__":
    main()
