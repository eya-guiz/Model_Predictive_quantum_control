"""Exploratory, solver-matched coupling scan for the Section 7.4 GHZ task.

The scan selects a physically reasonable benchmark parameter by an accuracy
threshold and MPQC-time criterion, rather than by a fortuitously poor QOC
local solution. The selected coupling must subsequently be rerun with several
paired initializations for the paper.
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import replace
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from mpqc_benchmark.artifacts import write_csv, write_json
from run_s7_4_ghz_qoc_mpqc_pareto import (
    GHZSystem, Settings, read_csv_rows, run_controller, write_checkpoint,
)


plt.switch_backend("Agg")


def aggregate(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    keys = sorted({(float(row["coupling"]), str(row["scheme"]), int(row["prediction_horizon"])) for row in rows})
    for coupling, scheme, horizon in keys:
        subset = [row for row in rows if float(row["coupling"]) == coupling and row["scheme"] == scheme and int(row["prediction_horizon"]) == horizon]
        output.append({
            "coupling": coupling, "scheme": scheme, "prediction_horizon": horizon,
            "runs": len(subset),
            "success_rate": float(np.mean([bool(row["run_success"]) for row in subset])),
            "final_infidelity_median": float(np.median([float(row["final_infidelity"]) for row in subset])),
            "mpqc_time_median_s": float(np.median([float(row["solve_time_s"]) for row in subset])),
            "total_iterations_median": float(np.median([float(row["total_iterations"]) for row in subset])),
            "max_model_exact_state_deviation": float(max(float(row["max_model_exact_state_deviation"]) for row in subset)),
        })
    return output


def select(summary: list[dict[str, Any]], absolute_accuracy: float, qoc_factor: float) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for coupling in sorted({float(row["coupling"]) for row in summary}):
        rows = [row for row in summary if float(row["coupling"]) == coupling]
        qoc = next(row for row in rows if row["scheme"] == "qoc")
        threshold = max(absolute_accuracy, qoc_factor * qoc["final_infidelity_median"])
        candidates = [row for row in rows if row["scheme"] == "mpqc" and row["success_rate"] == 1.0 and row["final_infidelity_median"] <= threshold]
        record: dict[str, Any] = {
            "coupling": coupling, "accuracy_threshold": threshold,
            "qoc_final_infidelity": qoc["final_infidelity_median"],
            "qoc_time_s": qoc["mpqc_time_median_s"],
        }
        if candidates:
            choice = min(candidates, key=lambda row: row["mpqc_time_median_s"])
            record.update({
                "accuracy_matched": True,
                "selected_horizon": choice["prediction_horizon"],
                "selected_final_infidelity": choice["final_infidelity_median"],
                "selected_mpqc_time_s": choice["mpqc_time_median_s"],
                "qoc_over_mpqc_time_ratio": qoc["mpqc_time_median_s"] / choice["mpqc_time_median_s"],
            })
        else:
            record.update({"accuracy_matched": False, "selected_horizon": "", "selected_final_infidelity": "", "selected_mpqc_time_s": "", "qoc_over_mpqc_time_ratio": ""})
        output.append(record)
    return output


def plot(summary: list[dict[str, Any]], output: Path) -> None:
    couplings = sorted({float(row["coupling"]) for row in summary})
    columns = 3
    figure, axes = plt.subplots(int(np.ceil(len(couplings) / columns)), columns, figsize=(12, 6.3), squeeze=False, constrained_layout=True)
    for axis, coupling in zip(axes.flat, couplings):
        rows = [row for row in summary if float(row["coupling"]) == coupling]
        qoc = next(row for row in rows if row["scheme"] == "qoc")
        mpqc = sorted((row for row in rows if row["scheme"] == "mpqc"), key=lambda row: row["prediction_horizon"])
        horizons = [row["prediction_horizon"] for row in mpqc]
        axis.scatter([row["mpqc_time_median_s"] for row in mpqc], [max(row["final_infidelity_median"], 1e-16) for row in mpqc], c=horizons, cmap="viridis", s=42, label="MPQC")
        axis.scatter(qoc["mpqc_time_median_s"], max(qoc["final_infidelity_median"], 1e-16), marker="*", s=120, color="crimson", label="Full-horizon QOC", zorder=3)
        axis.axhline(max(qoc["final_infidelity_median"], 1e-16), color="crimson", linestyle=":", linewidth=.8)
        axis.axvline(qoc["mpqc_time_median_s"], color="crimson", linestyle=":", linewidth=.8)
        axis.set_yscale("log")
        axis.set_title(rf"$J={coupling:g}$")
        axis.set_xlabel("MPQC time [s]")
        axis.set_ylabel("Final infidelity $1-F$")
        axis.grid(which="both", alpha=.25)
    for axis in axes.flat[len(couplings):]:
        axis.set_visible(False)
    handles, labels = axes.flat[0].get_legend_handles_labels()
    figure.legend(handles, labels, loc="upper center", ncol=2, bbox_to_anchor=(.5, 1.04))
    figure.savefig(output / "coupling_scan_pareto.pdf", bbox_inches="tight")
    figure.savefig(output / "coupling_scan_pareto.png", dpi=300, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/s7_4_coupling_scan.json")
    parser.add_argument("--couplings", nargs="+", type=float)
    parser.add_argument("--seeds", type=int)
    parser.add_argument("--resume", type=Path)
    arguments = parser.parse_args()
    raw = json.loads(Path(arguments.config).read_text(encoding="utf-8"))
    couplings = arguments.couplings or [float(value) for value in raw["candidate_couplings"]]
    seed_count = arguments.seeds or int(raw["seed_count"])
    horizons = sorted(int(value) for value in raw["mpqc_horizons"] if int(value) < int(raw["simulation_steps"]))
    base = Settings(
        dt=float(raw["dt"]), steps=int(raw["simulation_steps"]), apply_steps=int(raw["apply_steps"]),
        rk4_substeps=int(raw["rk4_substeps"]), coupling=0.0, amplitude_bound=float(raw["amplitude_bound"]),
        state_weight=float(raw["cost"]["state_weight"]), control_weight=float(raw["cost"]["control_weight"]), terminal_weight=float(raw["cost"]["terminal_weight"]),
        ipopt_tolerance=float(raw["ipopt"]["tolerance"]), ipopt_max_iterations=int(raw["ipopt"]["max_iterations"]),
        input_tolerance=1e-7, dynamics_tolerance=1e-6,
        accuracy_floor=float(raw["accuracy"]["absolute_final_infidelity"]), qoc_accuracy_factor=float(raw["accuracy"]["qoc_factor"]),
    )
    effective = {**raw, "effective_couplings": couplings, "effective_seed_count": seed_count, "effective_mpqc_horizons": horizons}
    if arguments.resume is None:
        output = Path(raw["output_root"]) / f"{raw['experiment_name']}_{time.strftime('%Y%m%dT%H%M%S')}"
        output.mkdir(parents=True, exist_ok=False)
        write_json(output / "config.json", effective)
        all_runs: list[dict[str, Any]] = []; all_subproblems: list[dict[str, Any]] = []
    else:
        output = arguments.resume
        previous = json.loads((output / "config.json").read_text(encoding="utf-8"))
        for key in ("effective_couplings", "effective_seed_count", "effective_mpqc_horizons"):
            if previous.get(key) != effective.get(key):
                raise ValueError(f"Cannot resume with a different {key}.")
        all_runs, all_subproblems = read_csv_rows(output / "run_results.csv"), read_csv_rows(output / "subproblems.csv")
        print(f"Resuming: {output}")

    def done(coupling: float, seed: int, scheme: str, horizon: int) -> bool:
        return any(float(row["coupling"]) == coupling and int(row["seed"]) == seed and row["scheme"] == scheme and int(row["prediction_horizon"]) == horizon for row in all_runs)

    for coupling in couplings:
        system = GHZSystem(int(raw["qubits"]), replace(base, coupling=coupling))
        for offset in range(seed_count):
            seed = int(raw["seed"]) + 1009 * offset
            rng = np.random.default_rng(seed)
            guess = rng.uniform(-base.amplitude_bound, base.amplitude_bound, (system.control_count, base.steps)) * float(raw["initialization_scale"])
            for scheme, horizon in [("qoc", base.steps), *(("mpqc", value) for value in horizons)]:
                if done(coupling, seed, scheme, horizon):
                    continue
                print(f"J={coupling:g}, seed={offset + 1}/{seed_count}, scheme={scheme}, L={horizon}", flush=True)
                run = run_controller(system, scheme, horizon, seed, guess)
                run["summary"]["coupling"] = coupling
                for row in run["subproblems"]:
                    row["coupling"] = coupling
                all_runs.append(run["summary"]); all_subproblems.extend(run["subproblems"])
                write_checkpoint(output, all_runs, all_subproblems)
    write_checkpoint(output, all_runs, all_subproblems)
    summary = aggregate(all_runs)
    write_csv(output / "coupling_scan_summary.csv", summary)
    write_csv(output / "coupling_scan_selection.csv", select(summary, base.accuracy_floor, base.qoc_accuracy_factor))
    plot(summary, output)
    print(f"Results: {output}")


if __name__ == "__main__":
    main()
