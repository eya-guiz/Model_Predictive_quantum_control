"""Solver-matched multi-qubit GHZ: full-horizon QOC versus Basic MPQC.

The only architectural distinction is the prediction horizon: full QOC solves
one N-step problem, while nominal open-loop MPQC repeatedly solves L-step
problems using the same CasADi/IPOPT formulation, costs, bounds, and seeds.
"""

from __future__ import annotations

import argparse
import csv
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import casadi as ca
import matplotlib.pyplot as plt
import numpy as np
from scipy.linalg import expm

from mpqc_benchmark.artifacts import write_csv, write_json


plt.switch_backend("Agg")


def read_csv_rows(path: Path) -> list[dict[str, Any]]:
    """Read checkpoint data and restore simple scalar types."""
    if not path.exists() or path.stat().st_size == 0:
        return []
    rows: list[dict[str, Any]] = []
    with path.open("r", newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            parsed: dict[str, Any] = {}
            for key, value in row.items():
                if value is None or value == "":
                    parsed[key] = ""
                elif value == "True":
                    parsed[key] = True
                elif value == "False":
                    parsed[key] = False
                else:
                    try:
                        number = float(value)
                        parsed[key] = int(number) if number.is_integer() else number
                    except ValueError:
                        parsed[key] = value
            rows.append(parsed)
    return rows


def write_checkpoint(output: Path, runs: list[dict[str, Any]], subproblems: list[dict[str, Any]]) -> None:
    """Persist completed controller evaluations so an interrupted job can resume."""
    write_csv(output / "run_results.csv", runs)
    write_csv(output / "subproblems.csv", subproblems)


@dataclass(frozen=True)
class Settings:
    dt: float
    steps: int
    apply_steps: int
    rk4_substeps: int
    coupling: float
    amplitude_bound: float
    state_weight: float
    control_weight: float
    terminal_weight: float
    ipopt_tolerance: float
    ipopt_max_iterations: int
    input_tolerance: float
    dynamics_tolerance: float
    accuracy_floor: float
    qoc_accuracy_factor: float


def kron_all(matrices: list[np.ndarray]) -> np.ndarray:
    result = matrices[0]
    for matrix in matrices[1:]:
        result = np.kron(result, matrix)
    return result


class GHZSystem:
    def __init__(self, qubits: int, settings: Settings) -> None:
        if qubits < 2:
            raise ValueError("The interacting GHZ family starts at two qubits.")
        self.qubits = qubits
        self.settings = settings
        self.dimension = 2**qubits
        identity = np.eye(2, dtype=np.complex128)
        x = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
        y = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128)
        z = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128)

        def local(operator: np.ndarray, location: int) -> np.ndarray:
            return kron_all([operator if index == location else identity for index in range(qubits)])

        drift = np.zeros((self.dimension, self.dimension), dtype=np.complex128)
        for location in range(qubits - 1):
            factors = [identity for _ in range(qubits)]
            factors[location] = z
            factors[location + 1] = z
            drift += settings.coupling * kron_all(factors)
        self.drift = drift
        self.controls = []
        for location in range(qubits):
            self.controls.extend([local(x, location), local(y, location)])
        self.control_count = len(self.controls)
        self.initial = np.zeros(self.dimension, dtype=np.complex128)
        self.initial[0] = 1.0
        self.target = np.zeros(self.dimension, dtype=np.complex128)
        self.target[0] = 1.0 / np.sqrt(2.0)
        self.target[-1] = 1.0 / np.sqrt(2.0)
        self.initial_real = self.to_real(self.initial)
        self.target_real = self.to_real(self.target)
        self._make_casadi_step()

    def to_real(self, state: np.ndarray) -> np.ndarray:
        return np.r_[state.real, state.imag]

    def to_complex(self, state: np.ndarray) -> np.ndarray:
        return state[: self.dimension] + 1.0j * state[self.dimension :]

    def _make_casadi_step(self) -> None:
        dimension = self.dimension
        state = ca.MX.sym("state", 2 * dimension)
        control = ca.MX.sym("control", self.control_count)
        real_hamiltonian = ca.DM(self.drift.real)
        imag_hamiltonian = ca.DM(self.drift.imag)
        for index, matrix in enumerate(self.controls):
            real_hamiltonian += control[index] * ca.DM(matrix.real)
            imag_hamiltonian += control[index] * ca.DM(matrix.imag)

        def derivative(value: ca.MX) -> ca.MX:
            real_state = value[:dimension]
            imag_state = value[dimension:]
            return ca.vertcat(
                imag_hamiltonian @ real_state + real_hamiltonian @ imag_state,
                -real_hamiltonian @ real_state + imag_hamiltonian @ imag_state,
            )

        h = self.settings.dt / self.settings.rk4_substeps
        next_state = state
        for _ in range(self.settings.rk4_substeps):
            k1 = derivative(next_state)
            k2 = derivative(next_state + 0.5 * h * k1)
            k3 = derivative(next_state + 0.5 * h * k2)
            k4 = derivative(next_state + h * k3)
            next_state = next_state + (h / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
        self.step_function = ca.Function(f"ghz_step_{self.qubits}", [state, control], [next_state])

    def exact_step(self, state: np.ndarray, control: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        hamiltonian = self.drift.copy()
        for amplitude, matrix in zip(control, self.controls):
            hamiltonian += amplitude * matrix
        propagator = expm(-1.0j * hamiltonian * self.settings.dt)
        return propagator @ state, propagator

    def fidelity(self, state: np.ndarray) -> float:
        return float(np.clip(abs(np.vdot(self.target, state)) ** 2, 0.0, 1.0))


class ProblemFactory:
    def __init__(self, system: GHZSystem) -> None:
        self.system = system
        self.cache: dict[int, ca.Function] = {}

    def solver(self, horizon: int) -> tuple[ca.Function, float]:
        if horizon in self.cache:
            return self.cache[horizon], 0.0
        started = time.perf_counter()
        controls = ca.MX.sym("controls", self.system.control_count, horizon)
        initial = ca.MX.sym("initial", 2 * self.system.dimension)
        target = ca.DM(self.system.target_real)
        state = initial
        objective = 0
        for index in range(horizon):
            control = controls[:, index]
            state = self.system.step_function(state, control)
            overlap_real = ca.dot(target[: self.system.dimension], state[: self.system.dimension]) + ca.dot(target[self.system.dimension :], state[self.system.dimension :])
            overlap_imag = ca.dot(target[: self.system.dimension], state[self.system.dimension :]) - ca.dot(target[self.system.dimension :], state[: self.system.dimension])
            fidelity = overlap_real**2 + overlap_imag**2
            objective += self.system.settings.state_weight * (1.0 - fidelity)
            objective += self.system.settings.control_weight * ca.sumsqr(control)
        objective += self.system.settings.terminal_weight * (1.0 - fidelity)
        solver = ca.nlpsol(
            f"ghz_n{self.system.qubits}_L{horizon}", "ipopt",
            {"x": ca.vec(controls), "p": initial, "f": objective},
            {
                "ipopt.print_level": 0,
                "ipopt.sb": "yes",
                "ipopt.tol": self.system.settings.ipopt_tolerance,
                "ipopt.max_iter": self.system.settings.ipopt_max_iterations,
                "print_time": 0,
            },
        )
        self.cache[horizon] = solver
        return solver, time.perf_counter() - started


def shifted_warm_start(previous: np.ndarray | None, base: np.ndarray, horizon: int, apply_steps: int) -> np.ndarray:
    if previous is None:
        return base[:, :horizon].copy()
    output = np.empty((previous.shape[0], horizon), dtype=float)
    tail = previous[:, apply_steps:]
    copied = min(horizon, tail.shape[1])
    output[:, :copied] = tail[:, :copied]
    output[:, copied:] = previous[:, [-1]]
    return output


def input_violation(control: np.ndarray, settings: Settings) -> float:
    return float(max(np.max(np.maximum(abs(control) - settings.amplitude_bound, 0.0)), 0.0))


def run_controller(
    system: GHZSystem,
    scheme: str,
    horizon: int,
    seed: int,
    base_guess: np.ndarray,
) -> dict[str, Any]:
    settings = system.settings
    factory = ProblemFactory(system)
    current = system.initial.copy()
    current_real = system.initial_real.copy()
    applied = np.zeros((system.control_count, settings.steps))
    states = [current.copy()]
    records: list[dict[str, Any]] = []
    previous: np.ndarray | None = None
    model_time = solve_time = 0.0
    started = time.perf_counter()
    if scheme == "qoc":
        updates = [(0, settings.steps, settings.steps)]
    else:
        updates = [
            (index, min(horizon, settings.steps - index), min(settings.apply_steps, settings.steps - index))
            for index in range(0, settings.steps, settings.apply_steps)
        ]
    failure_message = ""
    for update, (time_index, length, apply_count) in enumerate(updates):
        try:
            solver, construction = factory.solver(length)
            guess = shifted_warm_start(previous, base_guess, length, settings.apply_steps)
            solve_started = time.perf_counter()
            solution = solver(
                x0=guess.reshape(-1, order="F"), p=current_real,
                lbx=-settings.amplitude_bound, ubx=settings.amplitude_bound,
            )
            elapsed = time.perf_counter() - solve_started
            stats = solver.stats()
            status = str(stats.get("return_status", "unknown"))
            success = bool(stats.get("success", False)) or status in {"Solve_Succeeded", "Solved_To_Acceptable_Level"}
            iterations = int(stats.get("iter_count", -1))
            optimum = np.asarray(solution["x"]).reshape(system.control_count, length, order="F")
        except Exception as error:
            construction = elapsed = 0.0
            status = type(error).__name__
            success = False
            iterations = -1
            optimum = np.zeros((system.control_count, length))
            failure_message = str(error)
        model_time += construction
        solve_time += elapsed
        records.append(
            {
                "scheme": scheme, "seed": seed, "qubits": system.qubits, "dimension": system.dimension,
                "control_count": system.control_count, "prediction_horizon": horizon, "update": update,
                "time_index": time_index, "solver_success": success, "solver_return_code": status,
                "iterations": iterations, "model_construction_time_s": construction, "solve_time_s": elapsed,
                "max_predicted_input_bound_violation": input_violation(optimum, settings),
            }
        )
        if not success:
            break
        applied[:, time_index : time_index + apply_count] = optimum[:, :apply_count]
        for local in range(apply_count):
            next_state, propagator = system.exact_step(current, optimum[:, local])
            casadi_next = np.asarray(system.step_function(current_real, optimum[:, local])).reshape(-1)
            exact_real = system.to_real(next_state)
            records[-1].setdefault("max_model_exact_state_deviation", 0.0)
            records[-1]["max_model_exact_state_deviation"] = max(
                records[-1]["max_model_exact_state_deviation"], float(np.linalg.norm(casadi_next - exact_real))
            )
            current, current_real = next_state, exact_real
            states.append(current.copy())
        previous = optimum
    final_fidelity = system.fidelity(current)
    state_cost = sum(settings.state_weight * (1.0 - system.fidelity(state)) for state in states[:-1])
    control_cost = settings.control_weight * float(np.sum(applied * applied))
    terminal_cost = settings.terminal_weight * (1.0 - final_fidelity)
    summary = {
        "scheme": scheme, "seed": seed, "qubits": system.qubits, "dimension": system.dimension,
        "control_count": system.control_count, "dt": settings.dt, "simulation_steps": settings.steps,
        "prediction_horizon": horizon, "apply_steps": settings.apply_steps, "mpc_updates": len(records),
        "run_success": bool(records) and all(bool(row["solver_success"]) for row in records),
        "failure_message": failure_message, "final_fidelity": final_fidelity,
        "final_infidelity": 1.0 - final_fidelity,
        "total_iterations": int(sum(max(0, int(row["iterations"])) for row in records)),
        "max_input_bound_violation": input_violation(applied, settings),
        "max_predicted_input_bound_violation": max((row["max_predicted_input_bound_violation"] for row in records), default=float("inf")),
        "max_model_exact_state_deviation": max((row.get("max_model_exact_state_deviation", 0.0) for row in records), default=float("inf")),
        "model_construction_time_s": model_time, "solve_time_s": solve_time,
        "end_to_end_time_s": time.perf_counter() - started,
        "applied_state_cost": state_cost, "applied_control_cost": control_cost,
        "applied_terminal_cost": terminal_cost,
        "applied_total_cost": state_cost + control_cost + terminal_cost,
    }
    return {"summary": summary, "subproblems": records}


def quantiles(values: list[float]) -> tuple[float, float, float]:
    array = np.asarray(values, dtype=float)
    return float(np.median(array)), float(np.quantile(array, .25)), float(np.quantile(array, .75))


def bootstrap_median_ci(values: list[float], seed: int, samples: int = 10000) -> tuple[float, float]:
    """Percentile 95% bootstrap confidence interval for a sample median."""
    array = np.asarray(values, dtype=float)
    if len(array) <= 1 or np.all(array == array[0]):
        value = float(np.median(array))
        return value, value
    generator = np.random.default_rng(seed)
    medians = np.median(generator.choice(array, size=(samples, len(array)), replace=True), axis=1)
    return float(np.quantile(medians, .025)), float(np.quantile(medians, .975))


def aggregate(rows: list[dict[str, Any]], settings: Settings) -> list[dict[str, Any]]:
    output = []
    keys = sorted({(int(row["qubits"]), row["scheme"], int(row["prediction_horizon"])) for row in rows})
    for qubits, scheme, horizon in keys:
        subset = [row for row in rows if int(row["qubits"]) == qubits and row["scheme"] == scheme and int(row["prediction_horizon"]) == horizon]
        record: dict[str, Any] = {"qubits": qubits, "dimension": subset[0]["dimension"], "control_count": subset[0]["control_count"], "scheme": scheme, "prediction_horizon": horizon, "runs": len(subset), "success_rate": float(np.mean([bool(row["run_success"]) for row in subset]))}
        for metric_index, metric in enumerate(("final_infidelity", "applied_total_cost", "solve_time_s", "model_construction_time_s", "end_to_end_time_s", "total_iterations", "max_input_bound_violation", "max_model_exact_state_deviation")):
            values = [float(row[metric]) for row in subset]
            median, q25, q75 = quantiles(values)
            record[f"{metric}_median"] = median; record[f"{metric}_q25"] = q25; record[f"{metric}_q75"] = q75
            record[f"{metric}_min"] = float(np.min(values)); record[f"{metric}_max"] = float(np.max(values))
            lower, upper = bootstrap_median_ci(values, 20260907 + 10000 * qubits + 100 * horizon + metric_index)
            record[f"{metric}_median_ci95_lower"] = lower
            record[f"{metric}_median_ci95_upper"] = upper
        output.append(record)
    return output


def pareto_plot(summary: list[dict[str, Any]], qubits: int, output: Path) -> None:
    rows = [row for row in summary if int(row["qubits"]) == qubits]
    qoc = next(row for row in rows if row["scheme"] == "qoc")
    mpqc = sorted((row for row in rows if row["scheme"] == "mpqc"), key=lambda row: row["prediction_horizon"])
    figure, axis = plt.subplots(figsize=(7.2, 5.0), constrained_layout=True)
    horizons = np.array([row["prediction_horizon"] for row in mpqc])
    scatter = axis.scatter([row["solve_time_s_median"] for row in mpqc], [max(row["final_infidelity_median"], 1e-16) for row in mpqc], c=horizons, cmap="viridis", s=76, label="Basic MPQC")
    for row in mpqc:
        axis.errorbar(
            row["solve_time_s_median"], max(row["final_infidelity_median"], 1e-16),
            xerr=[[row["solve_time_s_median"] - row["solve_time_s_median_ci95_lower"]], [row["solve_time_s_median_ci95_upper"] - row["solve_time_s_median"]]],
            yerr=[[row["final_infidelity_median"] - row["final_infidelity_median_ci95_lower"]], [row["final_infidelity_median_ci95_upper"] - row["final_infidelity_median"]]],
            fmt="none", ecolor="0.45", elinewidth=1.1, capsize=3, zorder=0,
        )
    qoc_x, qoc_y = qoc["solve_time_s_median"], max(qoc["final_infidelity_median"], 1e-16)
    axis.scatter([qoc_x], [qoc_y], color="crimson", marker="*", s=205, label="QOC", zorder=3)
    axis.errorbar(
        qoc_x, qoc_y,
        xerr=[[qoc_x - qoc["solve_time_s_median_ci95_lower"]], [qoc["solve_time_s_median_ci95_upper"] - qoc_x]],
        yerr=[[qoc["final_infidelity_median"] - qoc["final_infidelity_median_ci95_lower"]], [qoc["final_infidelity_median_ci95_upper"] - qoc["final_infidelity_median"]]],
        fmt="none", ecolor="0.45", elinewidth=1.1, capsize=3, zorder=0,
    )
    axis.axhline(qoc_y, color="crimson", linestyle=":", linewidth=1)
    axis.axvline(qoc_x, color="crimson", linestyle=":", linewidth=1)
    axis.set_yscale("log")
    axis.set_xlabel("Cumulative optimization time [s]", fontsize=22)
    axis.set_ylabel("Final infidelity $1-F$", fontsize=22)
    axis.tick_params(axis="both", which="major", labelsize=18)
    axis.tick_params(axis="both", which="minor", labelsize=14)
    axis.grid(which="both", alpha=.25)
    axis.legend(loc="upper right", fontsize=18)
    colorbar = figure.colorbar(scatter, ax=axis, pad=.02)
    colorbar.set_label("MPQC prediction horizon $L$", fontsize=20)
    colorbar.ax.tick_params(labelsize=18)
    figure.savefig(output / f"section_7_4_pareto_n{qubits}.pdf", bbox_inches="tight")
    figure.savefig(output / f"section_7_4_pareto_n{qubits}.png", dpi=300, bbox_inches="tight")


def selection(summary: list[dict[str, Any]], settings: Settings) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    selected, tuning = [], []
    for qubits in sorted({int(row["qubits"]) for row in summary}):
        rows = [row for row in summary if int(row["qubits"]) == qubits]
        qoc = next(row for row in rows if row["scheme"] == "qoc")
        threshold = max(settings.accuracy_floor, settings.qoc_accuracy_factor * qoc["final_infidelity_median"])
        candidates = [row for row in rows if row["scheme"] == "mpqc" and row["success_rate"] == 1.0 and row["final_infidelity_median"] <= threshold and row["max_input_bound_violation_median"] <= settings.input_tolerance and row["max_model_exact_state_deviation_median"] <= settings.dynamics_tolerance]
        tested = [row for row in rows if row["scheme"] == "mpqc"]
        tuning.append({"qubits": qubits, "accuracy_threshold": threshold, "L_candidates_tested": len(tested), "tuning_optimization_time_s": float(sum(row["solve_time_s_median"] for row in tested)), "tuning_end_to_end_time_s": float(sum(row["end_to_end_time_s_median"] for row in tested))})
        if candidates:
            choice = min(candidates, key=lambda row: row["prediction_horizon"])
            selected.append({"qubits": qubits, "accuracy_threshold": threshold, **choice})
    return selected, tuning


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/s7_4_ghz_qoc_mpqc.json")
    parser.add_argument("--qubits", nargs="+", type=int)
    parser.add_argument("--seeds", type=int)
    parser.add_argument("--steps", type=int, help="Smoke-test override only; changes the physical duration.")
    parser.add_argument(
        "--resume", type=Path,
        help="Existing result directory created by this script. Completed evaluations are skipped.",
    )
    arguments = parser.parse_args()
    raw = json.loads(Path(arguments.config).read_text(encoding="utf-8"))
    settings = Settings(dt=float(raw["dt"]), steps=arguments.steps or int(raw["simulation_steps"]), apply_steps=int(raw["apply_steps"]), rk4_substeps=int(raw["rk4_substeps"]), coupling=float(raw["coupling"]), amplitude_bound=float(raw["amplitude_bound"]), state_weight=float(raw["cost"]["state_weight"]), control_weight=float(raw["cost"]["control_weight"]), terminal_weight=float(raw["cost"]["terminal_weight"]), ipopt_tolerance=float(raw["ipopt"]["tolerance"]), ipopt_max_iterations=int(raw["ipopt"]["max_iterations"]), input_tolerance=float(raw["validation"]["input_bound_violation"]), dynamics_tolerance=float(raw["validation"]["model_exact_state_deviation"]), accuracy_floor=float(raw["selection"]["accuracy_floor"]), qoc_accuracy_factor=float(raw["selection"]["qoc_accuracy_factor"]))
    qubits_values = arguments.qubits or list(raw["qubits"])
    seed_count = arguments.seeds or int(raw["seed_count"])
    horizons = sorted({int(value) for value in raw["mpqc_horizons"] if int(value) < settings.steps})
    if not horizons:
        raise ValueError("At least one MPQC horizon must be smaller than N.")
    effective_config = {
        **raw,
        "effective_steps": settings.steps,
        "effective_qubits": qubits_values,
        "effective_seed_count": seed_count,
        "effective_mpqc_horizons": horizons,
    }
    if arguments.resume is None:
        output = Path(raw["output_root"]) / f"s7_4_ghz_qoc_mpqc_{time.strftime('%Y%m%dT%H%M%S')}"
        output.mkdir(parents=True)
        write_json(output / "config.json", effective_config)
        all_runs: list[dict[str, Any]] = []
        all_subproblems: list[dict[str, Any]] = []
    else:
        output = arguments.resume
        saved_config = output / "config.json"
        if not saved_config.exists():
            raise FileNotFoundError("--resume must name a prior GHZ result directory containing config.json")
        previous = json.loads(saved_config.read_text(encoding="utf-8"))
        for key in ("effective_steps", "effective_qubits", "effective_seed_count", "effective_mpqc_horizons"):
            if previous.get(key) != effective_config.get(key):
                raise ValueError(f"Cannot resume with a different {key}; start a new run instead")
        all_runs = read_csv_rows(output / "run_results.csv")
        all_subproblems = read_csv_rows(output / "subproblems.csv")
        print(f"Resuming: {output}")

    def completed(qubits: int, seed: int, scheme: str, horizon: int) -> bool:
        return any(
            int(row["qubits"]) == qubits
            and int(row["seed"]) == seed
            and row["scheme"] == scheme
            and int(row["prediction_horizon"]) == horizon
            for row in all_runs
        )

    for qubits in qubits_values:
        system = GHZSystem(qubits, settings)
        for seed_offset in range(seed_count):
            seed = int(raw["seed"]) + 1009 * qubits + seed_offset
            rng = np.random.default_rng(seed)
            base_guess = rng.uniform(-settings.amplitude_bound, settings.amplitude_bound, size=(system.control_count, settings.steps)) * float(raw["initialization_scale"])
            if completed(qubits, seed, "qoc", settings.steps):
                print(f"qubits={qubits}, seed={seed_offset + 1}/{seed_count}, scheme=qoc (checkpoint complete; skipping)")
            else:
                print(f"qubits={qubits}, seed={seed_offset + 1}/{seed_count}, scheme=qoc")
                run = run_controller(system, "qoc", settings.steps, seed, base_guess)
                all_runs.append(run["summary"]); all_subproblems.extend(run["subproblems"])
                write_checkpoint(output, all_runs, all_subproblems)
            for horizon in horizons:
                if completed(qubits, seed, "mpqc", horizon):
                    print(f"qubits={qubits}, seed={seed_offset + 1}/{seed_count}, scheme=mpqc, L={horizon} (checkpoint complete; skipping)")
                    continue
                print(f"qubits={qubits}, seed={seed_offset + 1}/{seed_count}, scheme=mpqc, L={horizon}")
                run = run_controller(system, "mpqc", horizon, seed, base_guess)
                all_runs.append(run["summary"]); all_subproblems.extend(run["subproblems"])
                write_checkpoint(output, all_runs, all_subproblems)
    write_checkpoint(output, all_runs, all_subproblems)
    summary = aggregate(all_runs, settings)
    write_csv(output / "statistical_summary.csv", summary)
    selected, tuning = selection(summary, settings)
    write_csv(output / "selected_horizons.csv", selected)
    write_csv(output / "tuning_summary.csv", tuning)
    for qubits in qubits_values:
        pareto_plot(summary, qubits, output)
    print(f"Results: {output}")


if __name__ == "__main__":
    main()
