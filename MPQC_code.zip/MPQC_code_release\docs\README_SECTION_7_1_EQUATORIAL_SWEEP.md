# Section 7.1: equatorial target sweep

This benchmark replaces three hand-picked pure-state targets by the fixed
equatorial family

```text
|psi(nu)> = (|0> + exp(i 2 pi nu)|1>) / sqrt(2),  nu = j/16, j=0,...,15.
```

Every target has initial fidelity one half with `|0>`. The family includes
`|+>` at `nu=0` and `|->` at `nu=1/2`; no trivial target equal to the initial
state is included. The two solvers use paired seeded initial controls, matched
dynamics/cost/bounds, and method-specific shifted warm starts, exactly as in
the Section 7.1 three-target benchmark.

Run a four-target, one-trial plumbing test:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_1_equatorial_target_sweep.py --target-count 4 --trials 1
```

Run the paper experiment (16 targets, 10 paired trials per target):

```powershell
& .\.venv\Scripts\python.exe .\run_s7_1_equatorial_target_sweep.py
```

The runner checkpoints after each method/trial. Resume a stopped run with:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_1_equatorial_target_sweep.py --resume ".\results\s7_1_equatorial_target_sweep_YYYYMMDDTHHMMSS"
```

The main figure is `figure_7_1_equatorial_solver_sweep.pdf`: a Bloch-sphere
view of the target family plus cumulative optimization-time and total-iteration
plots. Lines are trial medians and shaded bands are IQRs. Complete per-trial
data are in `equatorial_paired_runs.csv` and per-target summaries are in
`equatorial_summary.csv`.
