# Section 7.3 random-target TEC versus setpoint benchmark

This benchmark samples 20 fixed-seed Bloch-sphere target states and compares
TEC MPQC with artificial-setpoint MPQC.  For each target Bloch vector `n`, the
reference input is `u_ref=(0.25 n_x, 0.25 n_y, 0.5+0.25 n_z)`. Therefore the
target is an eigenstate of the nonzero, admissible reference Hamiltonian.

The script scans prediction horizons from 1 to 30 and reports the smallest
tested horizon satisfying all stated numerical criteria.  TEC checks its
terminal equality with the target.  Setpoint MPQC checks terminal equality to
its optimized artificial setpoint and the artificial-setpoint steady-state
condition; requiring target equality at every update for the setpoint method
would incorrectly turn it into TEC.

Numerically, the terminal conditions are imposed as infidelity inequalities
below one tenth of the declared acceptance tolerance. This is equivalent at
the reported precision while avoiding the zero constraint gradient of the
literal equality $1-F=0$ at unit fidelity.

The artificial setpoint is parameterized by two Bloch-sphere angles.  Its input
is constructed from a fixed nonzero field parallel to that Bloch vector, so the
setpoint is on the steady-state manifold by construction.  This avoids the
redundant equality constraints that arise from representing a pure Bloch state
with three unconstrained Cartesian variables.

Run a small validation first:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_3_random_target_horizon_scan.py --target-count 1 --max-horizon 10 --timing-repeats 1
```

Run the paper experiment:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_3_random_target_horizon_scan.py
```

The runner checkpoints after every tested horizon. If it is interrupted, resume
the same run directory (shown in the terminal when it starts), for example:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_3_random_target_horizon_scan.py --resume ".\results\s7_3_random_target_horizon_scan_YYYYMMDDTHHMMSS"
```

Completed target--scheme pairs are skipped. A partially completed pair is
recomputed cleanly, so the resumed CSV files do not contain duplicate rows.
Do not resume a directory created before a material solver or configuration
change; start a new directory for the final paper data in that case.

The resulting directory contains `targets.csv`, all attempted horizons in
`horizon_scan.csv`, every solver update in `subproblems.csv`, selected-horizon
results in `selected_target_results.csv`, and the distribution/diagnostic
figures in PDF and PNG formats.
