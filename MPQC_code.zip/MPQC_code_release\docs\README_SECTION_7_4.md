# Section 7.4: multi-qubit GHZ QOC versus MPQC

The benchmark compares a full-horizon QOC solve with nominal open-loop Basic
MPQC for the interacting GHZ-preparation family. Both use the same
CasADi/IPOPT solver, Hamiltonian, bounds, cost, discretization, and seeded
initial control sequence. The only intended architectural variable is the
MPQC prediction horizon `L`.

Run a short smoke test first:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_4_ghz_qoc_mpqc_pareto.py --qubits 2 --seeds 1 --steps 20
```

Run the configured paper experiment:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_4_ghz_qoc_mpqc_pareto.py
```

The runner checkpoints after every completed QOC or MPQC evaluation. If a run
is stopped, resume the same output directory (printed at the end of a
successful run, or visible as the newest folder under `results`) with:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_4_ghz_qoc_mpqc_pareto.py --resume ".\results\s7_4_ghz_qoc_mpqc_YYYYMMDDTHHMMSS"
```

The same effective qubit list, seed count, step count, and horizon grid must
be used when resuming. Completed evaluations are skipped.

Each output directory contains full per-run and per-MPC-update CSV logs,
distribution summaries, selected acceptable horizons, explicit L-search tuning
time, and one runtime-versus-final-infidelity Pareto figure per qubit count.
`selected_horizons.csv` uses the smallest tested `L` that reaches the declared
accuracy threshold relative to full-horizon QOC and passes all numerical
checks. A missing selected horizon is a result, not a condition to hide.
