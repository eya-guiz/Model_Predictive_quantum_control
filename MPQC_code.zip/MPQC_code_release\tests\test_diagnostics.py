from __future__ import annotations

import unittest

import numpy as np

from mpqc_benchmark.diagnostics import (
    PAULI,
    applied_trajectory_cost,
    basis_density,
    density_to_real_vector,
    exact_density_step,
    input_bound_violation,
    physicality_diagnostics,
    propagator_unitarity_error,
    real_vector_to_density,
)


class DiagnosticsTests(unittest.TestCase):
    def test_column_major_density_vectorization_round_trip(self) -> None:
        rho = np.array(
            [[0.6, 0.2 + 0.3j], [0.2 - 0.3j, 0.4]], dtype=np.complex128
        )
        reconstructed = real_vector_to_density(density_to_real_vector(rho), 2)
        np.testing.assert_allclose(reconstructed, rho, atol=0.0, rtol=0.0)

    def test_exact_propagator_preserves_density_physicality(self) -> None:
        plus = np.array([1.0, 1.0], dtype=np.complex128) / np.sqrt(2.0)
        rho = np.outer(plus, plus.conj())
        next_rho, propagator = exact_density_step(rho, 0.7 * PAULI["y"], 0.13)
        diagnostics = physicality_diagnostics(next_rho)
        self.assertLess(diagnostics.trace_error, 1e-14)
        self.assertLess(diagnostics.hermiticity_error, 1e-14)
        self.assertGreater(diagnostics.min_eigenvalue, -1e-14)
        self.assertLess(propagator_unitarity_error(propagator), 1e-14)

    def test_input_bound_violation(self) -> None:
        controls = np.array([[0.0, 1.1], [-1.2, 0.2]])
        violation = input_bound_violation(
            controls, np.array([-1.0, -1.0]), np.array([1.0, 1.0])
        )
        self.assertAlmostEqual(violation, 0.2)

    def test_applied_cost_uses_pre_step_state_and_dt(self) -> None:
        initial = basis_density(2, 0)
        target = basis_density(2, 1)
        controls = np.zeros((1, 1))
        result = applied_trajectory_cost(
            states=[initial, initial],
            controls=controls,
            target_rho=target,
            input_reference=np.zeros(1),
            dt=0.25,
            state_weight=2.0,
            control_weight=1.0,
            terminal_weight=3.0,
            integrate_stage_cost=True,
        )
        self.assertAlmostEqual(result["applied_state_cost"], 0.5)
        self.assertAlmostEqual(result["applied_control_cost"], 0.0)
        self.assertAlmostEqual(result["applied_terminal_cost"], 3.0)
        self.assertAlmostEqual(result["applied_total_cost"], 3.5)


if __name__ == "__main__":
    unittest.main()
