"""Plot-only, paper-oriented renderer for the Section 7.3 saved results.

This script never runs an MPC optimization.  It reads the selected-horizon
summary from a completed Section 7.3 result directory and writes a paired
per-target figure plus a compact LaTeX summary table.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from qutip import Bloch


plt.switch_backend("Agg")


def read_rows(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            parsed: dict[str, Any] = {}
            for key, value in row.items():
                if value in (None, ""):
                    parsed[key] = value
                    continue
                if value == "True":
                    parsed[key] = True
                    continue
                if value == "False":
                    parsed[key] = False
                    continue
                try:
                    parsed[key] = float(value)
                except ValueError:
                    parsed[key] = value
            rows.append(parsed)
    return rows


def paired_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    pairs: list[dict[str, Any]] = []
    for target_id in sorted({int(row["target_id"]) for row in rows}):
        current = {str(row["scheme"]): row for row in rows if int(row["target_id"]) == target_id}
        if set(current) != {"tec", "setpoint"}:
            raise ValueError(f"Target {target_id} does not contain both selected schemes.")
        pairs.append({"target_id": target_id, "tec": current["tec"], "setpoint": current["setpoint"]})
    return sorted(pairs, key=lambda item: (item["tec"]["L_min_tested"], item["target_id"]))


def paired_figure(pairs: list[dict[str, Any]], output: Path) -> None:
    colors = {"tec": "#1f77b4", "setpoint": "#ff7f0e"}
    labels = {"tec": "TEC MPQC", "setpoint": "Artificial-setpoint MPQC"}
    figure, axes = plt.subplots(1, 2, figsize=(10.7, 6.25), sharey=True, constrained_layout=True)
    positions = np.arange(1, len(pairs) + 1)
    target_labels = [str(pair["target_id"]) for pair in pairs]
    metrics = (("L_min_tested", "Smallest accepted prediction horizon $L_{\\min}$", False),
               ("solve_time_median_s", "MPQC solve time [s]", True))

    for axis, (metric, xlabel, log_scale) in zip(axes, metrics):
        tec = np.array([pair["tec"][metric] for pair in pairs], dtype=float)
        setpoint = np.array([pair["setpoint"][metric] for pair in pairs], dtype=float)
        for index, position in enumerate(positions):
            axis.plot([setpoint[index], tec[index]], [position, position], color="0.72", linewidth=0.85, zorder=1)
        axis.scatter(tec, positions, s=32, color=colors["tec"], marker="o", zorder=3, label=labels["tec"])
        axis.scatter(setpoint, positions, s=39, color=colors["setpoint"], marker="s", zorder=4, label=labels["setpoint"])
        axis.set_xlabel(xlabel, fontsize=15)
        axis.tick_params(axis="both", labelsize=11)
        axis.grid(axis="x", alpha=0.28)
        if log_scale:
            axis.set_xscale("log")
            axis.set_xlim(0.8, 70)
        else:
            axis.set_xlim(0.4, max(tec) + 1.25)
            axis.set_xticks(np.arange(1, int(max(tec)) + 1, 2))
        axis.legend(loc="lower right", fontsize=10, frameon=True)

    axes[0].set_yticks(positions, target_labels)
    axes[0].set_ylabel("Random target index (sorted by TEC $L_{\\min}$)", fontsize=15)
    axes[0].invert_yaxis()
    figure.savefig(output / "section_7_3_paired_horizon_runtime.pdf", bbox_inches="tight")
    figure.savefig(output / "section_7_3_paired_horizon_runtime.png", dpi=300, bbox_inches="tight")


def values(rows: list[dict[str, Any]], scheme: str, key: str) -> np.ndarray:
    return np.asarray([float(row[key]) for row in rows if row["scheme"] == scheme], dtype=float)


def latex_table(rows: list[dict[str, Any]], output: Path) -> None:
    lines = [
        "% Generated from selected_target_results.csv; medians and IQRs across 20 targets.",
        "\\begin{tabular}{lcc}",
        "\\toprule",
        " & TEC MPQC & Artificial-setpoint MPQC \\\\",
        "\\midrule",
    ]
    specifications = [
        ("Accepted targets", "accepted", "integer"),
        (r"$L_{\min}$", "L_min_tested", "median_iqr"),
        ("MPQC solve time [s]", "solve_time_median_s", "median_iqr"),
        (r"Maximum final infidelity", "final_infidelity_median", "maximum"),
        (r"Maximum terminal residual", "max_terminal_residual", "maximum"),
        (r"Maximum steady-state residual", "max_steady_state_residual", "maximum"),
        (r"Maximum applied input violation", "max_input_bound_violation", "maximum"),
    ]
    for label, key, style in specifications:
        formatted: list[str] = []
        for scheme in ("tec", "setpoint"):
            current = values(rows, scheme, key)
            if style == "integer":
                formatted.append(str(int(np.sum(current > 0.5))))
            elif style == "median_iqr":
                formatted.append(f"{np.median(current):.3g} [{np.quantile(current,.25):.3g}, {np.quantile(current,.75):.3g}]")
            else:
                formatted.append(f"{np.max(current):.2e}")
        lines.append(f"{label} & {formatted[0]} & {formatted[1]} \\\\")
    lines.extend(["\\bottomrule", "\\end{tabular}", ""])
    (output / "section_7_3_summary_table.tex").write_text("\n".join(lines), encoding="utf-8")


def representative_figures(trace: list[dict[str, Any]], metadata: dict[str, Any], output: Path) -> None:
    colors = {"tec": "#1f77b4", "setpoint": "#ff7f0e"}
    target = np.asarray(metadata["target_bloch_vector"], dtype=float)
    grouped = {
        scheme: sorted((row for row in trace if row["scheme"] == scheme), key=lambda row: float(row["time"]))
        for scheme in ("tec", "setpoint")
    }

    figure = plt.figure(figsize=(7.2, 6.0), constrained_layout=True)
    axis = figure.add_subplot(projection="3d")
    bloch = Bloch(fig=figure, axes=axis, view=[-36, 22])
    bloch.sphere_color = "#b8c7d9"; bloch.sphere_alpha = .14
    bloch.frame_color = "0.55"; bloch.frame_alpha = .16; bloch.frame_width = .8
    bloch.xlabel = ["", ""]; bloch.ylabel = ["", ""]; bloch.zlabel = ["", ""]
    bloch.render()
    trajectory_handles = []
    for scheme, label in (("tec", "TEC state trajectory"), ("setpoint", "Setpoint state trajectory")):
        current = grouped[scheme]
        state = np.asarray([[row["state_x"], row["state_y"], row["state_z"]] for row in current], dtype=float)
        trajectory_handles.append(axis.plot(state[:, 0], state[:, 1], state[:, 2], color=colors[scheme], linewidth=2.6, label=label)[0])
    setpoint_rows = [row for row in grouped["setpoint"] if np.isfinite(float(row["setpoint_x"]))]
    setpoints = np.asarray([[row["setpoint_x"], row["setpoint_y"], row["setpoint_z"]] for row in setpoint_rows], dtype=float)
    axis.plot(setpoints[:, 0], setpoints[:, 1], setpoints[:, 2], color=colors["setpoint"], linestyle="--", linewidth=1.1, marker="D", markersize=2.6, markevery=10, alpha=.9, label="Artificial setpoints")
    initial = np.array([0., 0., 1.])
    axis.scatter(*initial, color="black", marker="o", s=40, label="Initial state |0⟩")
    axis.scatter(*target, color="black", marker="*", s=105, label="Physical target")
    axis.set(xlim=(-1.05, 1.05), ylim=(-1.05, 1.05), zlim=(-1.05, 1.05))
    axis.set_box_aspect((1, 1, 1)); axis.view_init(elev=22, azim=246)
    # Orientation markers in the standard qubit Bloch-vector convention.
    axis.text(0.0, 0.0, 1.20, r"$|0\rangle$", fontsize=22, ha="center", va="bottom")
    axis.text(0.0, 0.0, -1.20, r"$|1\rangle$", fontsize=22, ha="center", va="top")
    axis.set_axis_off()
    axis.legend(
        trajectory_handles, ["TEC", "Setpoint"],
        loc="lower center", bbox_to_anchor=(.5, -.02), ncol=1, fontsize=18,
        frameon=True, handlelength=2.0,
    )
    figure.savefig(output / "section_7_3_representative_bloch.pdf", bbox_inches="tight")
    figure.savefig(output / "section_7_3_representative_bloch.png", dpi=300, bbox_inches="tight")

    figure, axis = plt.subplots(figsize=(6.2, 3.75), constrained_layout=True)
    current = grouped["setpoint"]
    time = np.asarray([row["time"] for row in current], dtype=float)
    physical_fidelity = np.asarray([row["physical_target_fidelity"] for row in current], dtype=float)
    tec_rows = grouped["tec"]
    tec_time = np.asarray([row["time"] for row in tec_rows], dtype=float)
    tec_fidelity = np.asarray([row["physical_target_fidelity"] for row in tec_rows], dtype=float)
    setpoint_rows = current[1:]
    setpoints = np.asarray([[row["setpoint_x"], row["setpoint_y"], row["setpoint_z"]] for row in setpoint_rows], dtype=float)
    setpoint_target_fidelity = .5 * (1.0 + setpoints @ target)
    setpoint_time = np.asarray([row["time"] for row in setpoint_rows], dtype=float) - (time[1] - time[0])
    axis.plot(tec_time, tec_fidelity, color=colors["tec"], linewidth=2.0, label="TEC/Setpoint-opt")
    axis.plot(time, physical_fidelity, color=colors["setpoint"], linewidth=2.0,
              label="_nolegend_")
    axis.plot(setpoint_time, setpoint_target_fidelity, color="#6a3d9a", linestyle="--", linewidth=1.65,
              label="Setpoint trajectory")
    axis.axhline(1.0, color="black", linestyle="--", linewidth=.9, label="Target fidelity")
    axis.set(xlabel="Time", ylabel=r"Fidelity $F$"); axis.set_ylim(-.03, 1.03)
    axis.tick_params(labelsize=16)
    axis.xaxis.label.set_size(22); axis.yaxis.label.set_size(22)
    axis.grid(alpha=.28); axis.legend(loc="lower right", fontsize=18)
    figure.savefig(output / "section_7_3_representative_fidelity.pdf", bbox_inches="tight")
    figure.savefig(output / "section_7_3_representative_fidelity.png", dpi=300, bbox_inches="tight")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="Completed Section 7.3 result directory.")
    parser.add_argument("--output", type=Path, help="Output directory; defaults to <input>/paper_figures.")
    parser.add_argument("--trace", type=Path, help="Representative trace directory created by run_s7_3_representative_trajectory.py.")
    arguments = parser.parse_args()
    source = arguments.input
    output = arguments.output or source / "paper_figures"
    output.mkdir(parents=True, exist_ok=True)
    rows = read_rows(source / "selected_target_results.csv")
    if not rows:
        raise ValueError("selected_target_results.csv is empty.")
    pairs = paired_rows(rows)
    paired_figure(pairs, output)
    latex_table(rows, output)
    if arguments.trace:
        representative_figures(
            read_rows(arguments.trace / "trajectory.csv"),
            json.loads((arguments.trace / "metadata.json").read_text(encoding="utf-8")), output,
        )
    print(f"Wrote paper-ready Section 7.3 outputs to: {output}")


if __name__ == "__main__":
    main()
