"""Regenerate Section 7.2 figures from saved run artifacts without rerunning MPC.

The current S1 configuration is dimensionless. Consequently, the horizontal
axis is labelled "Time" rather than being assigned an unintroduced Omega unit.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

plt.switch_backend("Agg")


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Plot saved Section 7.2 TEC-MPQC results without rerunning MPC."
    )
    parser.add_argument(
        "--run-dir",
        type=Path,
        required=True,
        help="Existing S1 run directory containing CSV and JSON artifacts.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="Destination for the figures; defaults to --run-dir.",
    )
    return parser.parse_args()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))



def style_axis(axis: plt.Axes) -> None:
    axis.grid(
        True,
        axis="y",       
        which="major",
        color="0.78",
        alpha=0.55,
        linewidth=0.7,
    )
    axis.tick_params(axis="both", which="major", labelsize=12)


def configure_plot_style() -> None:
    plt.rcParams.update(
        {
            "font.size": 24,
            "axes.labelsize": 24,
            "axes.titlesize": 24,
            "legend.fontsize": 24,
            "xtick.labelsize": 26,
            "ytick.labelsize": 16,
            "figure.dpi": 160,
            "savefig.dpi": 300,
            "axes.linewidth": 0.8,
        }
    )





def create_fidelity_control_value_figure(
    run_directory: Path, output_directory: Path
) -> dict[str, Any]:
    trajectory = read_rows(run_directory / "trajectory.csv")
    controls = read_rows(run_directory / "controls.csv")
    subproblems = read_rows(run_directory / "subproblems.csv")
    config = json.loads((run_directory / "config.json").read_text(encoding="utf-8"))
    if not controls:
        raise ValueError("controls.csv contains no applied controls")

    state_times = np.array([float(row["time"]) for row in trajectory])
    fidelities = np.array([float(row["fidelity"]) for row in trajectory])
    infidelities = np.maximum(1.0 - fidelities, 1e-15)
    control_times = np.array([float(row["time"]) for row in controls])
    update_times = np.array(
        [float(row["applied_start_index"]) * float(config["time"]["dt"]) for row in subproblems]
    )
    values = np.array([float(row["objective_value"]) for row in subproblems])
    control_keys = [key for key in controls[0] if key.startswith("u_")]
    lower = np.asarray(config["bounds"]["lower"], dtype=float)
    upper = np.asarray(config["bounds"]["upper"], dtype=float)

    figure, axes = plt.subplots(
        1, 3,
        figsize=(12.0, 3.4),
        constrained_layout=True,
    )

    for axis in axes:
        axis.set_xlim(0, 10)
        style_axis(axis)

    axes[0].plot(
        state_times,
        infidelities,
        color="tab:blue",
        linewidth=2.0,
        label=r"Infidelity $1-F$",
    )

    axes[0].set_ylabel(r"Infidelity $1-F$", fontsize=18)
    axes[0].set_ylim(-0.02, 1.05)
    #axes[0].legend(loc="lower right", frameon=False)
    #style_axis(axes[0], "(a)")

    for index, key in enumerate(control_keys):
        values_for_control = np.array([float(row[key]) for row in controls])
        label = (
            r"Applied MPQC control $u_t$"
            if len(control_keys) == 1
            else rf"Applied MPQC control $u_{{{index + 1},t}}$"
        )
        axes[1].step(
            control_times,
            values_for_control,
            where="post",
            linewidth=1.7,
            label=label,
        )
        axes[1].axhline(upper[index], color="black", linestyle="--", linewidth=0.9)
        axes[1].axhline(lower[index], color="black", linestyle="--", linewidth=0.9)
    axes[1].set_ylabel("MPQC control", fontsize =18)
    # style_axis(axes[1], "(b)")

    # A linear axis makes the rapid initial decrease visually explicit. The
    # theorem-validation figure retains the semilog representation used to
    # assess exponential convergence quantitatively.
    axes[2].plot(update_times, values, color="tab:orange", linewidth=2.0)
    axes[2].set_ylim(bottom=0.0)
    figure.supxlabel("Time", fontsize = 18) # axes[2].set_xlabel("Time")
    axes[2].set_ylabel(r"Optimal cost  $J^\star$", fontsize = 18)
    # style_axis(axes[2], "(c)")

    # style_axis(axes[0])
    # style_axis(axes[1])
    # style_axis(axes[2])

    for suffix in ("pdf", "png"):
        figure.savefig(output_directory / f"section_7_2_fidelity_control_value.{suffix}")
    plt.close(figure)
    return {
        "figure_pdf": str(output_directory / "section_7_2_fidelity_control_value.pdf"),
        "figure_png": str(output_directory / "section_7_2_fidelity_control_value.png"),
        "time_unit": "dimensionless",
    }


def main() -> int:
    arguments = parse_arguments()
    run_directory = arguments.run_dir.resolve()
    output_directory = (
        arguments.output_dir.resolve()
        if arguments.output_dir is not None
        else run_directory
    )
    output_directory.mkdir(parents=True, exist_ok=True)
    result = create_fidelity_control_value_figure(run_directory, output_directory)
    print(result["figure_pdf"])
    print(result["figure_png"])
    print("Time unit: dimensionless")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
