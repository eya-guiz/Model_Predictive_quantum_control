from __future__ import annotations

import unittest
from pathlib import Path

import numpy as np

from mpqc_benchmark import QubitTECBenchmark, load_config
from mpqc_benchmark.diagnostics import (
    build_hamiltonian,
    density_to_real_vector,
    exact_density_step,
    real_vector_to_density,
)


class ModelValidationTests(unittest.TestCase):
    def test_rk4_model_matches_independent_exponential_for_complex_state(self) -> None:
        root = Path(__file__).resolve().parents[1]
        config = load_config(root / "configs" / "s0_smoke.json")
        benchmark = QubitTECBenchmark(config)
        psi = np.array([1.0, 1.0j], dtype=np.complex128) / np.sqrt(2.0)
        rho = np.outer(psi, psi.conj())
        control = np.array([0.37])
        model_vector = benchmark._model_step(density_to_real_vector(rho), control)
        model_rho = real_vector_to_density(model_vector, 2)
        hamiltonian = build_hamiltonian(
            config.system.drift_axis,
            config.system.drift_strength,
            config.system.control_axes,
            control,
        )
        exact_rho, _ = exact_density_step(rho, hamiltonian, config.time.dt)
        self.assertLess(np.linalg.norm(model_rho - exact_rho, ord="fro"), 1e-9)


if __name__ == "__main__":
    unittest.main()
