# Section 7.5: static mismatch and finite-shot tomography

This runner deliberately separates two effects.

1. It designs nominal full-horizon QOC and nominal Basic-MPQC pulses for the
   two-qubit GHZ target, then applies those fixed pulses to plants with static
   coupling mismatch `J_true=J+epsilon`.  No feedback is used in this part.
2. It holds the true system at the nominal coupling and runs Basic and TEC
   MPQC with a state reconstructed at every update from nine local Pauli
   settings.  The finite-shot estimator is linear-inversion tomography followed
   by positive-semidefinite projection; its dominant eigenvector is supplied to
   the existing pure-state controller.  This is explicitly a pure-state
   feedback-estimate model, not a full mixed-state MPQC implementation.

Run a short plumbing test:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_5_static_mismatch_tomography.py --steps 20 --tomography-trials 1
```

Before the paper run, establish a fixed TEC-feasible prediction horizon for
the configured duration and bounds.  A short smoke test is not suitable for
this: for example, `L=10` is infeasible for the GHZ terminal condition at
`T=1`.  Do not present failed TEC runs as robustness data.  Once a feasible
`L` is established, set `mpqc_horizon` in
`configs/s7_5_static_mismatch_tomography.json`, then run:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_5_static_mismatch_tomography.py
```

For a temporary feasibility test, override the horizon:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_5_static_mismatch_tomography.py --mpqc-horizon 40 --tomography-trials 1
```

The runner checkpoints each completed tomography trial. Resume an interrupted
run with the same effective step count, horizon, and trial count:

```powershell
& .\.venv\Scripts\python.exe .\run_s7_5_static_mismatch_tomography.py --resume ".\results\s7_5_static_mismatch_tomography_YYYYMMDDTHHMMSS"
```

Output includes `static_mismatch_results.csv`, `tomography_results.csv`, full
per-update solver records, and both paper-ready plots.
