from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from mpqc_benchmark import QubitTECBenchmark, load_config
from mpqc_benchmark.artifacts import RunArtifacts

plt.switch_backend("Agg")


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate the theorem-consistent TEC-MPQC study for Section 7.2."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("configs/s1_tec_theorem_validation.json"),
    )
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--run-id")
    return parser.parse_args()


def exponential_fit(
    times: np.ndarray, infidelities: np.ndarray, dt: float
) -> dict[str, float | int]:
    positive = np.asarray(infidelities, dtype=float)
    mask = np.isfinite(positive) & (positive > 1e-12) & (positive < 0.95)
    fit_times = np.asarray(times, dtype=float)[mask]
    fit_values = positive[mask]
    if fit_times.size < 5:
        return {
            "exponential_fit_points": int(fit_times.size),
            "empirical_log_decay_rate_per_time": math.nan,
            "empirical_contraction_factor_per_step": math.nan,
            "exponential_fit_r_squared": math.nan,
        }
    log_values = np.log(fit_values)
    slope, intercept = np.polyfit(fit_times, log_values, 1)
    predicted = slope * fit_times + intercept
    residual_sum = float(np.sum((log_values - predicted) ** 2))
    total_sum = float(np.sum((log_values - np.mean(log_values)) ** 2))
    r_squared = 1.0 - residual_sum / total_sum if total_sum > 0.0 else math.nan
    return {
        "exponential_fit_points": int(fit_times.size),
        "empirical_log_decay_rate_per_time": float(slope),
        "empirical_contraction_factor_per_step": float(np.exp(slope * dt)),
        "exponential_fit_r_squared": r_squared,
    }


def settling_time(
    times: np.ndarray, infidelities: np.ndarray, threshold: float
) -> float:
    values = np.asarray(infidelities, dtype=float)
    for index in range(values.size):
        if np.all(values[index:] <= threshold):
            return float(times[index])
    return math.nan


def enrich_summary(
    result: dict[str, Any], config: Any
) -> dict[str, Any]:
    summary = dict(result["summary"])
    times = np.array([row["time"] for row in result["trajectory"]], dtype=float)
    infidelities = np.array(
        [row["infidelity"] for row in result["trajectory"]], dtype=float
    )
    fit = exponential_fit(times, infidelities, config.time.dt)
    terminal_tolerance = config.validation.terminal_residual_tolerance
    subproblems = result["subproblems"]
    feasible_updates = sum(
        bool(row["solver_success"])
        and float(row["terminal_residual_model"]) <= terminal_tolerance
        and float(row["terminal_residual_exact"]) <= terminal_tolerance
        for row in subproblems
    )
    decreasing_pairs = np.diff(infidelities) <= 1e-12
    summary.update(
        {
            **fit,
            "fixed_prediction_horizon": True,
            "theorem_setting_M_equals_1": config.time.apply_steps == 1,
            "recursive_feasibility_updates": feasible_updates,
            "recursive_feasibility_fraction": (
                feasible_updates / len(subproblems) if subproblems else math.nan
            ),
            "recursive_feasibility_all_updates": feasible_updates == len(subproblems),
            "infidelity_monotone_step_fraction": (
                float(np.mean(decreasing_pairs)) if decreasing_pairs.size else math.nan
            ),
            "settling_time_infidelity_1e-6": settling_time(
                times, infidelities, 1e-6
            ),
            "settling_time_infidelity_1e-8": settling_time(
                times, infidelities, 1e-8
            ),
            "settling_time_infidelity_1e-10": settling_time(
                times, infidelities, 1e-10
            ),
        }
    )
    return summary


def configure_plot_style() -> None:
    plt.rcParams.update(
        {
            "font.size": 24,
            "axes.labelsize": 24,
            "axes.titlesize": 24,
            "legend.fontsize": 24,
            "xtick.labelsize": 20,
            "ytick.labelsize": 20,
            "figure.dpi": 120,
            "savefig.dpi": 300,
            "axes.grid": True,
            "grid.alpha": 0.3,
        }
    )


def create_theorem_figure(
    result: dict[str, Any], summary: dict[str, Any], config: Any, output: Path
) -> None:
    configure_plot_style()
    trajectory = result["trajectory"]
    subproblems = result["subproblems"]
    times = np.array([row["time"] for row in trajectory], dtype=float)
    infidelities = np.maximum(
        np.array([row["infidelity"] for row in trajectory], dtype=float), 1e-16
    )
    update_times = np.array(
        [row["applied_start_index"] * config.time.dt for row in subproblems]
    )
    values = np.maximum(
        np.array([row["objective_value"] for row in subproblems], dtype=float),
        1e-16,
    )
    terminal_model = np.maximum(
        np.array([row["terminal_residual_model"] for row in subproblems]), 1e-16
    )
    terminal_exact = np.maximum(
        np.array([row["terminal_residual_exact"] for row in subproblems]), 1e-16
    )

    figure, axes = plt.subplots(2, 2, figsize=(7.2, 5.4), constrained_layout=True)
    ax = axes[0, 0]
    ax.semilogy(times, infidelities, color="tab:blue", linewidth=1.8)
    rate = float(summary["empirical_log_decay_rate_per_time"])
    if np.isfinite(rate) and rate < 0.0:
        mask = (infidelities > 1e-12) & (infidelities < 0.95)
        fit_times = times[mask]
        if fit_times.size:
            intercept = float(
                np.mean(np.log(infidelities[mask]) - rate * fit_times)
            )
            ax.semilogy(
                fit_times,
                np.exp(intercept + rate * fit_times),
                color="black",
                linestyle="--",
                linewidth=1.0,
                label="log-linear fit",
            )
            #ax.legend(loc="best")
    ax.set_xlabel("Time")
    ax.set_ylabel(r"Infidelity $1-F$")
    ax.set_title("(a) Closed-loop convergence", loc="left")

    ax = axes[0, 1]
    ax.semilogy(update_times, values, color="tab:orange", linewidth=1.8)
    ax.set_xlabel("Time")
    ax.set_ylabel(r"Optimal value $J^\star$")
    ax.set_title("(b) MPC value function", loc="left")

    ax = axes[1, 0]
    ax.semilogy(
        update_times,
        terminal_model,
        color="tab:green",
        linewidth=1.5,
        label="prediction model",
    )
    ax.semilogy(
        update_times,
        terminal_exact,
        color="tab:red",
        linewidth=1.1,
        linestyle="--",
        label="exact validation",
    )
    ax.axhline(
        config.validation.terminal_residual_tolerance,
        color="black",
        linestyle=":",
        linewidth=1.0,
        label="validation tolerance",
    )
    ax.set_xlabel("Time")
    ax.set_ylabel("Terminal residual")
    ax.set_title("(c) Recursive feasibility", loc="left")
    #ax.legend(loc="best")

    checked = [
        row
        for row in subproblems
        if np.isfinite(row["value_function_decrease"])
    ]
    ax = axes[1, 1]
    checked_times = np.array(
        [row["applied_start_index"] * config.time.dt for row in checked]
    )
    value_decrease = np.array([row["value_function_decrease"] for row in checked])
    decrease_rhs = np.array([row["lyapunov_decrease_rhs"] for row in checked])
    ax.plot(
        checked_times,
        value_decrease,
        color="tab:purple",
        linewidth=1.5,
        label=r"$J^\star_{t+1}-J^\star_t$",
    )
    ax.plot(
        checked_times,
        decrease_rhs,
        color="black",
        linewidth=1.0,
        linestyle="--",
        label=r"$-\ell(X_t,u_t)$",
    )
    ax.axhline(0.0, color="0.5", linewidth=0.8)
    ax.set_xlabel("Time")
    ax.set_ylabel("One-step change")
    ax.set_title("(d) Lyapunov decrease", loc="left")
    #ax.legend(loc="best")

    for suffix in ("pdf", "png"):
        figure.savefig(output / f"section_7_2_theorem_validation.{suffix}")
    plt.close(figure)


def create_control_figure(result: dict[str, Any], output: Path) -> None:
    configure_plot_style()
    trajectory = result["trajectory"]
    controls = result["controls"]
    state_times = np.array([row["time"] for row in trajectory])
    fidelities = np.array([row["fidelity"] for row in trajectory])
    control_times = np.array([row["time"] for row in controls])
    control_key = next(key for key in controls[0] if key.startswith("u_"))
    control_values = np.array([row[control_key] for row in controls])
    figure, axes = plt.subplots(2, 1, figsize=(6.4, 4.6), sharex=True, constrained_layout=True)
    axes[0].plot(state_times, fidelities, color="tab:blue", linewidth=1.8)
    axes[0].set_ylabel("Fidelity")
    axes[0].set_ylim(-0.02, 1.02)
    axes[0].set_title("(a) State fidelity", loc="left")
    axes[1].step(control_times, control_values, where="post", color="tab:orange")
    axes[1].axhline(1.0, color="black", linestyle=":", linewidth=0.8)
    axes[1].axhline(-1.0, color="black", linestyle=":", linewidth=0.8)
    axes[1].set_xlabel("Time")
    axes[1].set_ylabel(r"Control $u$")
    axes[1].set_title("(b) Applied control", loc="left")
    for suffix in ("pdf", "png"):
        figure.savefig(output / f"section_7_2_trajectory_control.{suffix}")
    plt.close(figure)


def write_paper_outputs(summary: dict[str, Any], output: Path) -> None:
    final_infidelity = float(summary["final_infidelity"])
    terminal_model = float(summary["max_terminal_residual_model"])
    terminal_exact = float(summary["max_terminal_residual_exact"])
    feasible_updates = int(summary["recursive_feasibility_updates"])
    mpc_updates = int(summary["mpc_updates"])
    lyapunov_satisfied = int(summary["lyapunov_updates_satisfied"])
    lyapunov_checked = int(summary["lyapunov_updates_checked"])
    contraction = float(summary["empirical_contraction_factor_per_step"])
    fit_quality = float(summary["exponential_fit_r_squared"])
    dynamics_defect = float(summary["max_dynamics_defect"])
    solve_time = float(summary["solve_time_s"])
    table = rf"""\begin{{tabular}}{{lr}}
\hline
Quantity & Value \\
\hline
Final infidelity & {final_infidelity:.3e} \\
Maximum terminal residual (model) & {terminal_model:.3e} \\
Maximum terminal residual (exact) & {terminal_exact:.3e} \\
Feasible MPQC updates & {feasible_updates}/{mpc_updates} \\
Lyapunov checks satisfied & {lyapunov_satisfied}/{lyapunov_checked} \\
Empirical contraction factor per step & {contraction:.6f} \\
Log-linear fit $R^2$ & {fit_quality:.4f} \\
Maximum dynamics defect & {dynamics_defect:.3e} \\
Total solve time [s] & {solve_time:.3f} \\
\hline
\end{{tabular}}
"""
    (output / "section_7_2_table.tex").write_text(table, encoding="utf-8")
    results_paragraph = rf"""We consider the single-qubit Hamiltonian
$H(t)=0.5\sigma_z+u(t)\sigma_x$, with $u(t)\in[-1,1]$, and the
state-stabilization task $\ket{{+}}\to\ket{{0}}$. The reference input is
$u_{{\mathrm{{ref}}}}=0$, for which the target-invariance residual is
{float(summary['target_invariance_residual']):.1e}. TEC-MPQC is applied with
$\Delta t=0.05$, fixed prediction horizon $L=40$, and $M=1$ for
{mpc_updates} closed-loop updates. All {feasible_updates} optimization problems
were feasible, and the maximum independently validated terminal residual was
{terminal_exact:.3e}. The closed-loop infidelity decreased from $0.5$ to
{final_infidelity:.3e}. A descriptive log-linear fit gives a per-step
contraction factor of {contraction:.6f} with $R^2={fit_quality:.4f}$.
Moreover, the numerical decrease condition
$J^\star(X_{{t+1}})-J^\star(X_t)\leq-\ell(X_t,u_t)$ was satisfied, up to the
prescribed numerical tolerance, at all {lyapunov_checked} consecutive update
pairs. These results illustrate the nominal convergence mechanism of
Theorem~4.1; they do not constitute an independent proof or a robustness
claim.
"""
    (output / "section_7_2_results_paragraph.tex").write_text(
        results_paragraph, encoding="utf-8"
    )
    caption = r"""Theorem-consistent TEC-MPQC stabilization of $\ket{0}$ from
$\ket{+}$. (a) Closed-loop infidelity on a logarithmic scale. (b) Optimal MPC
value function. (c) Terminal-constraint residual evaluated with both the RK4
prediction model and independent matrix-exponential propagation. The dotted
line denotes the validation tolerance. (d) One-step value-function change and
the negative applied stage cost. The prediction horizon is fixed at $L=40$,
and $M=1$."""
    (output / "section_7_2_figure_caption.tex").write_text(
        caption + "\n", encoding="utf-8"
    )
    interpretation = f"""# Section 7.2 numerical summary

- Target invariance residual under the reference input:
  {summary['target_invariance_residual']:.3e}
- Successful/feasible updates:
  {summary['recursive_feasibility_updates']}/{summary['mpc_updates']}
- Final infidelity: {final_infidelity:.3e}
- Maximum exact terminal residual: {terminal_exact:.3e}
- Lyapunov decrease checks: {lyapunov_satisfied}/{lyapunov_checked}
- Empirical per-step contraction factor: {contraction:.8f}
- Log-linear fit R-squared: {fit_quality:.6f}

The regression is descriptive numerical evidence, not a proof or an estimate of
the theorem's constants.
"""
    (output / "section_7_2_summary.md").write_text(interpretation, encoding="utf-8")


def main() -> int:
    arguments = parse_arguments()
    project_root = Path(__file__).resolve().parent
    config_path = arguments.config.resolve()
    config = load_config(config_path)
    if config.time.apply_steps != 1:
        raise ValueError("The theorem-validation study requires apply_steps=M=1")
    configured_root = Path(config.output.root)
    if arguments.output_root is not None:
        results_root = arguments.output_root.resolve()
    elif configured_root.is_absolute():
        results_root = configured_root
    else:
        results_root = (project_root / configured_root).resolve()
    complete_config = config.to_dict()
    complete_config["source_config_path"] = str(config_path)
    complete_config["resolved_output_root"] = str(results_root)
    artifacts = RunArtifacts(
        results_root=results_root,
        experiment_name=config.experiment_name,
        config=complete_config,
        repository_root=project_root.parent,
        run_id=arguments.run_id,
    )
    try:
        result = QubitTECBenchmark(config).run()
        if not bool(result["summary"].get("run_success", False)):
            raise RuntimeError(
                "TEC-MPQC run did not complete successfully: "
                f"{result['summary'].get('failure_message', 'unknown failure')}"
            )
        summary = enrich_summary(result, config)
        result["summary"] = summary
        create_theorem_figure(result, summary, config, artifacts.run_directory)
        create_control_figure(result, artifacts.run_directory)
        write_paper_outputs(summary, artifacts.run_directory)
        artifacts.write_success(
            summary=summary,
            subproblems=result["subproblems"],
            trajectory=result["trajectory"],
            controls=result["controls"],
            arrays=result["arrays"] if config.output.save_arrays else None,
            refresh_master=config.output.refresh_master_csv,
        )
    except Exception as error:
        artifacts.write_failure(error, refresh_master=config.output.refresh_master_csv)
        print(f"Study failed: {type(error).__name__}: {error}", file=sys.stderr)
        print(f"Failure record: {artifacts.run_directory}", file=sys.stderr)
        return 2

    print(f"Run directory: {artifacts.run_directory}")
    print(f"Run success: {summary['run_success']}")
    print(f"Final infidelity: {summary['final_infidelity']:.3e}")
    print(
        "Recursive feasibility: "
        f"{summary['recursive_feasibility_updates']}/{summary['mpc_updates']} updates"
    )
    print(
        "Lyapunov decrease: "
        f"{summary['lyapunov_updates_satisfied']}/"
        f"{summary['lyapunov_updates_checked']} checks"
    )
    print(
        "Empirical contraction / fit R^2: "
        f"{summary['empirical_contraction_factor_per_step']:.6f} / "
        f"{summary['exponential_fit_r_squared']:.4f}"
    )
    return 0 if summary["run_success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
