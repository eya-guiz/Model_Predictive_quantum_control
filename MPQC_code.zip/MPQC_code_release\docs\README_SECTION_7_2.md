# Section 7.2 theorem-consistent TEC-MPQC simulation

This experiment provides the numerical illustration of Theorem 4.1 requested
by the reviewer. It is separate from the original finite-time transfer example.

## Physical and controller configuration

- Hamiltonian: `H(t) = 0.5 sigma_z + u(t) sigma_x`
- Input bound: `u in [-1, 1]`
- Initial state: `|+>` (Bloch vector `[1, 0, 0]`)
- Target: `|0>` (Bloch vector `[0, 0, 1]`)
- Reference input: `u_ref = 0`
- Sampling interval: `dt = 0.05`
- Fixed prediction horizon: `L = 40`
- Applied controls per update: `M = 1`
- Closed-loop observation horizon: 200 updates (10 time units)

Only the observation horizon is long. The finite MPC prediction horizon remains
fixed at every update, consistently with the theorem.

## Run

From the `MPQC code` directory with `.venv` activated:

```powershell
python run_s1_tec_theorem_validation.py `
  --config configs\s1_tec_theorem_validation.json
```

The command creates a unique immutable directory under `results/`.

## Regenerate only the figures

This does not rerun IPOPT or CasADi. It reads `trajectory.csv`, `controls.csv`,
`subproblems.csv`, and `config.json` from an existing run:

```powershell
python plot_s1_tec_results.py `
  --run-dir results\YOUR_S1_RUN_DIRECTORY
```

It writes `section_7_2_fidelity_control_value.pdf` and `.png`, containing the
fidelity, applied control, and a linearly scaled MPC-value/Lyapunov-function
panel. The separate theorem-validation figure retains semilogarithmic panels
for assessing exponential convergence quantitatively. The current model uses
dimensionless time, so the figure deliberately uses the label `Time` without
an unintroduced `Omega^{-1}` unit.

## Paper-ready outputs

- `section_7_2_theorem_validation.pdf` and `.png`: four-panel theorem figure
- `section_7_2_trajectory_control.pdf` and `.png`: fidelity and applied control
- `section_7_2_table.tex`: compact numerical table
- `section_7_2_results_paragraph.tex`: generated results paragraph
- `section_7_2_figure_caption.tex`: generated figure caption
- `section_7_2_summary.md`: short interpretation with the proof caveat
- `summary.csv`, `subproblems.csv`, `trajectory.csv`, and `controls.csv`: evidence
- `config.json`, `environment.json`, and `arrays.npz`: reproducibility artifacts

The log-linear regression is descriptive. It illustrates exponential-type
decay but is not presented as a proof or as an estimate of the constants in the
theorem.
