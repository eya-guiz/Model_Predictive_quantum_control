# Model Predictive Quantum Control: reproducibility code

This repository contains the Python code and configurations used for the
numerical studies in *Model predictive quantum control: A modular approach
for efficient and robust quantum optimal control*.

## Installation

Python 3.11 or later is recommended. Create and activate a virtual environment,
then install the dependencies:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
```

The experiments use CasADi/IPOPT through the standard CasADi Python package.

## Repository structure

- `scripts/`: executable simulation, benchmark, and plot scripts.
- `configs/`: complete JSON configurations for each numerical experiment.
- `mpqc_benchmark/`: shared models, diagnostics, artifact writing, and
  configuration handling.
- `tests/`: lightweight validation tests for shared functionality.
- `docs/`: experiment-specific notes.

All scripts write a timestamped directory under `results/`. Each run directory
contains its exact configuration, machine-readable CSV summaries, per-update
diagnostics, and generated paper figures where applicable.

## Reproducing the paper experiments

Run these commands from the repository root.

```powershell
# Section 7.1: Basic MPQC, IPOPT versus analytic GRAPE/L-BFGS-B
python .\scripts\run_s7_1_equatorial_target_sweep.py

# Section 7.2: theorem-consistent TEC-MPQC stabilization, |0> -> |+>
python .\scripts\run_s1_tec_theorem_validation.py `
  --config .\configs\s1_tec_zero_to_plus_theorem_validation.json

# Regenerate the compact three-panel Section 7.2 figure after a run
python .\scripts\plot_s1_tec_results.py --run-dir .\results\<RUN_DIRECTORY>

# Section 7.3: TEC versus artificial-setpoint MPQC
python .\scripts\run_s7_3_random_target_horizon_scan.py

# Section 7.4: three-qubit GHZ, Basic MPQC versus full-horizon QOC
python .\scripts\run_s7_4_ghz_qoc_mpqc_pareto.py `
  --config .\configs\s7_4_ghz_qoc_mpqc_J1p5.json

# Appendix: full-horizon N sweep
python .\scripts\run_appendix_n_sweep_ghz.py

# Section 7.5: finite-shot tomography and closed-loop Basic MPQC
python .\scripts\run_s7_5_basic_tomography_budget.py
```

The default Section 7.4 and Section 7.5 configurations use repeated trials
and can take substantial time. Edit only a copied configuration when making
exploratory changes, and retain the original configuration files for the
reported results.

## Numerical conventions

We set $\hbar=1$ and normalize all Hamiltonian coefficients and control
amplitudes by a characteristic angular frequency $\Omega$. Time is therefore
reported in units of $\Omega^{-1}$; all numerical quantities in the
configurations are dimensionless.

## Reproducibility data

Generated result directories are intentionally excluded from this source-code
release. They should be archived separately in a persistent data repository
(for example Zenodo) together with the paper version used for submission.

## License and citation

Add a `LICENSE` file and the final manuscript citation or DOI before publishing
the repository publicly.
