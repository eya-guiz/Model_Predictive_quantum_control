from __future__ import annotations

import unittest
from pathlib import Path

from mpqc_benchmark.config import load_config


class ConfigurationTests(unittest.TestCase):
    def test_smoke_configuration_is_complete_and_valid(self) -> None:
        root = Path(__file__).resolve().parents[1]
        config = load_config(root / "configs" / "s0_smoke.json")
        self.assertEqual(config.control_count, 1)
        self.assertAlmostEqual(config.duration, 0.2)
        self.assertEqual(config.to_dict()["derived"]["prediction_time"], 0.2)

    def test_theorem_validation_configuration_uses_required_setting(self) -> None:
        root = Path(__file__).resolve().parents[1]
        config = load_config(root / "configs" / "s1_tec_theorem_validation.json")
        self.assertEqual(config.time.apply_steps, 1)
        self.assertEqual(config.time.prediction_horizon, 40)
        self.assertEqual(config.system.initial_bloch_vector, (1.0, 0.0, 0.0))
        self.assertEqual(config.system.target_bloch_vector, (0.0, 0.0, 1.0))


if __name__ == "__main__":
    unittest.main()
