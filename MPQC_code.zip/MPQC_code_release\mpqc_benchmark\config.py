from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class SystemConfig:
    dimension: int
    drift_axis: str
    drift_strength: float
    control_axes: tuple[str, ...]
    initial_basis_index: int
    target_basis_index: int
    initial_bloch_vector: tuple[float, float, float] | None = None
    target_bloch_vector: tuple[float, float, float] | None = None


@dataclass(frozen=True)
class TimeConfig:
    dt: float
    simulation_steps: int
    prediction_horizon: int
    apply_steps: int
    rk4_substeps: int


@dataclass(frozen=True)
class CostConfig:
    state_weight: float
    control_weight: float
    terminal_weight: float
    input_reference: tuple[float, ...]
    integrate_stage_cost: bool


@dataclass(frozen=True)
class BoundsConfig:
    lower: tuple[float, ...]
    upper: tuple[float, ...]


@dataclass(frozen=True)
class SolverConfig:
    plugin: str
    tolerance: float
    constraint_violation_tolerance: float
    acceptable_tolerance: float
    max_iterations: int
    linear_solver: str
    print_level: int
    require_success: bool
    terminal_constraint_tolerance: float


@dataclass(frozen=True)
class InitializationConfig:
    strategy: str
    amplitude: tuple[float, ...]


@dataclass(frozen=True)
class ValidationConfig:
    terminal_residual_tolerance: float
    dynamics_defect_tolerance: float
    input_violation_tolerance: float
    unitarity_tolerance: float
    lyapunov_decrease_tolerance: float


@dataclass(frozen=True)
class OutputConfig:
    root: str
    save_arrays: bool
    refresh_master_csv: bool


@dataclass(frozen=True)
class BenchmarkConfig:
    schema_version: int
    experiment_name: str
    run_label: str
    seed: int
    system: SystemConfig
    time: TimeConfig
    cost: CostConfig
    bounds: BoundsConfig
    solver: SolverConfig
    initialization: InitializationConfig
    validation: ValidationConfig
    output: OutputConfig

    @property
    def control_count(self) -> int:
        return len(self.system.control_axes)

    @property
    def duration(self) -> float:
        return self.time.dt * self.time.simulation_steps

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["derived"] = {
            "control_count": self.control_count,
            "duration": self.duration,
            "prediction_time": self.time.dt * self.time.prediction_horizon,
        }
        return result

    def validate(self) -> None:
        if self.schema_version != 1:
            raise ValueError(f"Unsupported schema_version={self.schema_version}; expected 1")
        if self.system.dimension != 2:
            raise ValueError(
                "The S0 reference implementation currently supports one qubit "
                "(dimension=2)"
            )
        allowed_axes = {"x", "y", "z"}
        axes = (self.system.drift_axis, *self.system.control_axes)
        if any(axis.lower() not in allowed_axes for axis in axes):
            raise ValueError(f"Axes must be selected from {sorted(allowed_axes)}")
        if len(set(axis.lower() for axis in self.system.control_axes)) != self.control_count:
            raise ValueError("control_axes must not contain duplicates")
        if not 0 <= self.system.initial_basis_index < self.system.dimension:
            raise ValueError("initial_basis_index is outside the Hilbert space")
        if not 0 <= self.system.target_basis_index < self.system.dimension:
            raise ValueError("target_basis_index is outside the Hilbert space")
        for name, vector in (
            ("initial_bloch_vector", self.system.initial_bloch_vector),
            ("target_bloch_vector", self.system.target_bloch_vector),
        ):
            if vector is not None:
                if len(vector) != 3:
                    raise ValueError(f"{name} must contain three real values")
                norm = sum(float(component) ** 2 for component in vector) ** 0.5
                if abs(norm - 1.0) > 1e-10:
                    raise ValueError(
                        f"{name} must describe a pure state with Euclidean norm one"
                    )
        if self.time.dt <= 0.0:
            raise ValueError("dt must be positive")
        if min(
            self.time.simulation_steps,
            self.time.prediction_horizon,
            self.time.apply_steps,
            self.time.rk4_substeps,
        ) <= 0:
            raise ValueError("All time-step counts must be positive")
        if self.time.apply_steps > self.time.prediction_horizon:
            raise ValueError("apply_steps cannot exceed prediction_horizon")
        expected = self.control_count
        vector_fields = {
            "cost.input_reference": self.cost.input_reference,
            "bounds.lower": self.bounds.lower,
            "bounds.upper": self.bounds.upper,
            "initialization.amplitude": self.initialization.amplitude,
        }
        for name, value in vector_fields.items():
            if len(value) != expected:
                raise ValueError(f"{name} must contain {expected} values")
        if any(lo >= hi for lo, hi in zip(self.bounds.lower, self.bounds.upper)):
            raise ValueError("Every lower input bound must be smaller than its upper bound")
        if self.initialization.strategy not in {"sine", "zeros", "uniform_random"}:
            raise ValueError("initialization.strategy must be sine, zeros, or uniform_random")
        if (
            self.cost.state_weight < 0
            or self.cost.control_weight < 0
            or self.cost.terminal_weight < 0
        ):
            raise ValueError("Cost weights must be non-negative")
        if self.solver.max_iterations <= 0:
            raise ValueError("solver.max_iterations must be positive")
        if self.solver.terminal_constraint_tolerance <= 0.0:
            raise ValueError("solver.terminal_constraint_tolerance must be positive")
        if self.validation.lyapunov_decrease_tolerance < 0.0:
            raise ValueError("validation.lyapunov_decrease_tolerance must be non-negative")


def _tuple_values(section: dict[str, Any], *keys: str) -> dict[str, Any]:
    converted = dict(section)
    for key in keys:
        converted[key] = tuple(converted[key])
    return converted


def load_config(path: str | Path) -> BenchmarkConfig:
    source = Path(path)
    with source.open("r", encoding="utf-8") as stream:
        raw = json.load(stream)

    system_values = _tuple_values(raw["system"], "control_axes")
    for optional_vector in ("initial_bloch_vector", "target_bloch_vector"):
        if system_values.get(optional_vector) is not None:
            system_values[optional_vector] = tuple(system_values[optional_vector])

    config = BenchmarkConfig(
        schema_version=int(raw["schema_version"]),
        experiment_name=str(raw["experiment_name"]),
        run_label=str(raw.get("run_label", "")),
        seed=int(raw["seed"]),
        system=SystemConfig(**system_values),
        time=TimeConfig(**raw["time"]),
        cost=CostConfig(**_tuple_values(raw["cost"], "input_reference")),
        bounds=BoundsConfig(**_tuple_values(raw["bounds"], "lower", "upper")),
        solver=SolverConfig(**raw["solver"]),
        initialization=InitializationConfig(
            **_tuple_values(raw["initialization"], "amplitude")
        ),
        validation=ValidationConfig(**raw["validation"]),
        output=OutputConfig(**raw["output"]),
    )
    config.validate()
    return config
