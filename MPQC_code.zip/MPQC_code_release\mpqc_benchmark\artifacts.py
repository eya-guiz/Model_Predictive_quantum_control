from __future__ import annotations

import csv
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np


def canonical_json_hash(value: dict[str, Any]) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _atomic_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary_name = tempfile.mkstemp(prefix=path.name, suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        # OneDrive, Explorer preview, and spreadsheet applications can hold a
        # transient read lock while the checkpoint is being replaced. Retrying
        # preserves atomic writes without silently falling back to an unsafe
        # in-place overwrite.
        for attempt in range(8):
            try:
                os.replace(temporary_name, path)
                break
            except PermissionError:
                if attempt == 7:
                    raise
                time.sleep(0.25 * (attempt + 1))
    except Exception:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise


def write_json(path: Path, value: dict[str, Any]) -> None:
    _atomic_text(path, json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True) + "\n")


def write_csv(
    path: Path,
    rows: Iterable[dict[str, Any]],
    fieldnames: list[str] | None = None,
) -> None:
    materialized = list(rows)
    if fieldnames is None:
        fieldnames = []
        seen: set[str] = set()
        for row in materialized:
            for key in row:
                if key not in seen:
                    fieldnames.append(key)
                    seen.add(key)
    output: list[str] = []
    from io import StringIO

    buffer = StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(materialized)
    output.append(buffer.getvalue())
    _atomic_text(path, "".join(output))


def _git_metadata(repository_root: Path) -> dict[str, Any]:
    def invoke(*arguments: str) -> str | None:
        try:
            completed = subprocess.run(
                ["git", *arguments],
                cwd=repository_root,
                check=False,
                capture_output=True,
                text=True,
                timeout=5,
            )
        except (FileNotFoundError, subprocess.SubprocessError):
            return None
        if completed.returncode != 0:
            return None
        return completed.stdout.strip()

    commit = invoke("rev-parse", "HEAD")
    status = invoke("status", "--short")
    if commit is None:
        git_directory = repository_root / ".git"
        head_path = git_directory / "HEAD"
        try:
            head = head_path.read_text(encoding="utf-8").strip()
            if head.startswith("ref: "):
                reference = head.removeprefix("ref: ")
                reference_path = git_directory / reference
                if reference_path.exists():
                    commit = reference_path.read_text(encoding="utf-8").strip()
                else:
                    packed_refs = git_directory / "packed-refs"
                    if packed_refs.exists():
                        for line in packed_refs.read_text(encoding="utf-8").splitlines():
                            if line and not line.startswith(("#", "^")):
                                candidate, name = line.split(" ", maxsplit=1)
                                if name == reference:
                                    commit = candidate
                                    break
            elif head:
                commit = head
        except (OSError, ValueError):
            commit = None
    return {
        "commit": commit,
        "dirty": None if status is None else bool(status),
        "status_short": status,
    }


def environment_metadata(repository_root: Path) -> dict[str, Any]:
    dependency_names = ["numpy", "scipy", "casadi", "pandas", "pyarrow", "qutip"]
    dependencies: dict[str, str | None] = {}
    for name in dependency_names:
        try:
            dependencies[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            dependencies[name] = None
    return {
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "python_executable": sys.executable,
        "python_version": sys.version,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "machine": platform.machine(),
        "logical_cpu_count": os.cpu_count(),
        "thread_environment": {
            name: os.environ.get(name)
            for name in (
                "OMP_NUM_THREADS",
                "MKL_NUM_THREADS",
                "OPENBLAS_NUM_THREADS",
                "NUMEXPR_NUM_THREADS",
            )
        },
        "dependencies": dependencies,
        "git": _git_metadata(repository_root),
    }


def refresh_master_csv(results_root: Path) -> Path:
    rows: list[dict[str, Any]] = []
    for summary_path in sorted(results_root.glob("*/summary.csv")):
        with summary_path.open("r", encoding="utf-8", newline="") as stream:
            reader = csv.DictReader(stream)
            row = next(reader, None)
            if row is not None:
                rows.append(dict(row))
    destination = results_root / "runs.csv"
    write_csv(destination, rows)
    return destination


class RunArtifacts:
    def __init__(
        self,
        results_root: Path,
        experiment_name: str,
        config: dict[str, Any],
        repository_root: Path,
        run_id: str | None = None,
    ) -> None:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        self.config_hash = canonical_json_hash(config)
        safe_experiment = "".join(
            character if character.isalnum() or character in "-_" else "-"
            for character in experiment_name
        ).strip("-")
        self.run_id = run_id or f"{safe_experiment}_{timestamp}_{self.config_hash[:10]}"
        self.results_root = results_root
        self.run_directory = results_root / self.run_id
        if self.run_directory.exists():
            raise FileExistsError(f"Run directory already exists: {self.run_directory}")
        self.run_directory.mkdir(parents=True)
        resolved_config = dict(config)
        resolved_config["run_id"] = self.run_id
        resolved_config["config_sha256"] = self.config_hash
        write_json(self.run_directory / "config.json", resolved_config)
        write_json(
            self.run_directory / "environment.json",
            environment_metadata(repository_root),
        )

    def write_success(
        self,
        summary: dict[str, Any],
        subproblems: list[dict[str, Any]],
        trajectory: list[dict[str, Any]],
        controls: list[dict[str, Any]],
        arrays: dict[str, np.ndarray] | None,
        refresh_master: bool,
    ) -> None:
        row = {"run_id": self.run_id, "config_sha256": self.config_hash, **summary}
        write_csv(self.run_directory / "summary.csv", [row])
        write_csv(self.run_directory / "subproblems.csv", subproblems)
        write_csv(self.run_directory / "trajectory.csv", trajectory)
        write_csv(self.run_directory / "controls.csv", controls)
        if arrays is not None:
            destination = self.run_directory / "arrays.npz"
            handle, temporary_name = tempfile.mkstemp(
                prefix="arrays", suffix=".tmp", dir=self.run_directory
            )
            try:
                with os.fdopen(handle, "wb") as stream:
                    np.savez_compressed(stream, **arrays)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temporary_name, destination)
            except Exception:
                try:
                    os.unlink(temporary_name)
                except FileNotFoundError:
                    pass
                raise
        if refresh_master:
            refresh_master_csv(self.results_root)

    def write_failure(self, error: BaseException, refresh_master: bool) -> None:
        summary = {
            "run_id": self.run_id,
            "config_sha256": self.config_hash,
            "run_success": False,
            "failure_type": type(error).__name__,
            "failure_message": str(error),
        }
        write_csv(self.run_directory / "summary.csv", [summary])
        if refresh_master:
            refresh_master_csv(self.results_root)
